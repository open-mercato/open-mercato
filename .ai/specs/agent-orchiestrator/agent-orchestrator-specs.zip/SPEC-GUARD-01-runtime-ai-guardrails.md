# SPEC-GUARD-01: Runtime AI Guardrails

> **Status:** Draft · **Owner:** Patryk Lewczuk (Comerito) · **Updated:** 2026-06-16
> **Module:** `@open-mercato/agent-orchestrator` · **subdomain:** `guardrails` · **Depends:** `ai_assistant`, `business_rules`; extends `2026-06-04-ai-input-moderation-and-safety-identifiers`

## TLDR

Real-time, blocking safety checks on agent **inputs and outputs** — distinct from evals (which measure after the fact) and from `business_rules` (deterministic entity logic). Covers prompt-injection, PII, grounding, and output-schema enforcement. Critical for a regulated, document-ingesting domain (insurance) where claim attachments are attacker-controllable.

## Problem statement

`business_rules` GUARD validates entity/transition data, not LLM I/O. OM has an input-moderation spec but no output guardrails, prompt-injection defense, or grounding/schema enforcement for agent runs. An agent acting on a poisoned uploaded document is currently undefended.

## What OM already provides (reuse)

- `ai-input-moderation-and-safety-identifiers` (input moderation baseline, safety identifiers).
- `ai_assistant` mutation-policy + tool allowlists (action gating); field-level encryption (PII at rest).
- `attachments` + `ai-agent-attachment-processing` (the untrusted-document surface to defend).

## UMES extension points used

- Guardrail hook on the `INVOKE_AGENT` activity (pre-call on context, post-call on output) — `SPEC-AGENTINT-01`.
- `business_rules` ACTION rules to escalate/notify on guardrail trips.

## Data models

```typescript
@Entity() class GuardrailCheck {
  id; organizationId; agentRunId;
  @Enum() phase;        // input | output
  @Enum() kind;         // prompt_injection | pii | grounding | schema | moderation | tool_scope
  @Enum() result;       // pass | warn | block
  @Json() evidence;
  at;
}
```
Guardrail **sets** (which checks apply to which capability) are versioned config (YAML-in-repo synced to DB, matching the rule-pack pattern).

## Checks

- **Prompt-injection / untrusted content:** treat retrieved docs/attachments as data, not instructions; detect instruction-injection patterns; isolate untrusted spans. **Block on output that attempts unauthorized tool/action use.**
- **PII:** detect/redact in summaries and outbound payloads; full payloads stay in the encrypted artifact store.
- **Grounding:** for factual proposals, verify claims trace to provided context (cite-or-abstain); low grounding → `warn`/`block` per set.
- **Output schema:** validate against the capability's Zod proposal contract; malformed → `block` + retry/repair.
- **Tool-scope:** enforce the agent's tool allowlist (reuse `ai_assistant`).

## Behaviour

- `block` → the `INVOKE_AGENT` activity fails the run with a typed reason; workflow routes to retry/escalate/`USER_TASK` (no silent pass-through).
- `warn` → proceeds but flags the proposal (surfaces in cockpit + becomes an eval signal).
- Every check writes a `GuardrailCheck` and attaches `guardResults` to the `Proposal` (`SPEC-AGENTINT-01`).

## API contracts

- `GuardrailService.checkInput(runCtx)` / `.checkOutput(runCtx, output)` → `GuardrailVerdict`.
- Events: `guardrail.tripped` (consumed by cockpit + notifications).

## Phases

1. Output-schema + tool-scope enforcement (cheapest, highest value).
2. PII detection/redaction on outbound + summaries.
3. Prompt-injection / untrusted-content isolation for attachment-derived context.
4. Grounding (cite-or-abstain) for factual capabilities.

## Acceptance

- An agent output violating its proposal schema is `block`ed and never reaches disposition.
- A claim attachment containing an injected instruction does not cause an unauthorized tool/action; the attempt is `block`ed and logged.
- PII never appears in a stored proposal summary; full payload remains in the encrypted store.
