# SPEC-COCKPIT-01: Agent Operations UI

> **Status:** Draft · **Owner:** Patryk Lewczuk (Comerito) · **Updated:** 2026-06-16
> **Module:** `@open-mercato/agent-orchestrator` · **subdomain:** `cockpit` · **Depends:** `workflows` (monitor + My Tasks), `dashboards`, `perspectives`, `inbox_ops`, `SPEC-AGENTINT-01`, `SPEC-TRACE-01`

## TLDR

The Admin / Operator / Engineer UI. Rather than a new app, it **extends** OM's existing workflow monitoring dashboard, "My Tasks" queue, `dashboards`, and `perspectives` with agent-specific surfaces: the operator caseload (four-verb), the proposal disposition card with agent I/O, and the engineer trace inspector + eval panel. Reference prototype: `om-agent-cockpit-v3.html`.

## Problem statement

The agent-specific operator/engineer surfaces don't exist, but most of the substrate (task queue, monitoring, dashboards, perspectives) does. We need the agent overlays, not a fresh cockpit.

## What OM already provides (reuse)

- `workflows` **monitoring dashboard** (running instances, drill-down) → admin fleet view base.
- `workflows` **"My Tasks"** queue + assignment/claim/SLA → operator caseload base.
- `dashboards` (KPI tiles), `perspectives` (role-scoped views → Admin/Operator/Engineer personas), `inbox_ops`.
- `SPEC-TRACE-01` read API (traces, runs, eval, metrics), `SPEC-AGENTINT-01` proposal disposition API.

## UMES extension points used

- Widget injection into workflow monitor + My Tasks (agent attribution, proposal cards, I/O drawer).
- `perspectives` definitions for Admin / Operator / Engineer scoping.

## Surfaces

- **Admin (fleet):** extend the workflow monitor with agent KPIs — auto-completion %, operator-to-process ratio, exception rate, queue depth, cost, per-agent override rate. Drill to root cause.
- **Operator (caseload):** extend "My Tasks" into the four-verb caseload (**Decide / Answer / Do / Know**), scoped to assigned processes, summary strip + segments (Needs you / Waiting / Running). Each `USER_TASK` keeps full case context.
- **Proposal disposition card:** the agent's proposal + confidence + guard results + the inline **I/O drawer** (input/output/tools from `SPEC-TRACE-01`), with Approve / Edit / Reject → `SPEC-AGENTINT-01` dispose API (Edit/Reject writes a Correction).
- **Engineer (trace):** the trace list + full **trace inspector** (span waterfall, context-routing panel, reasoning, tool calls, output, eval assertions, model comparison) over `SPEC-TRACE-01`. "Open full trace" handoff from a process step.
- **Cross-persona handoff:** supervisor sees a questionable proposal → opens the trace → hands to engineering.

## API contracts

- Reads from `SPEC-TRACE-01` (`/runs`, `/runs/:id`, `/agents/:id/metrics`) and `workflows` (instances, tasks).
- Writes via `SPEC-AGENTINT-01` (`/proposals/:id/dispose`) and `workflows` task completion.

## Phases

1. `perspectives` for the three roles + agent KPI widgets on the workflow monitor (Admin).
2. Four-verb caseload overlay on "My Tasks" + proposal disposition card + I/O drawer (Operator).
3. Trace list + trace inspector + eval panel (Engineer).
4. Cross-persona handoff + anti-rubber-stamp signals (approve-unchanged rate, sampled re-review).

## Acceptance

- An operator sees only assigned processes, grouped by verb, and can dispose a proposal (Approve/Edit/Reject) which advances the underlying workflow.
- An engineer can open any agent run's full trace with eval results and model comparison.
- The UI reuses workflow My Tasks/monitoring as its base rather than duplicating queue/state logic.
