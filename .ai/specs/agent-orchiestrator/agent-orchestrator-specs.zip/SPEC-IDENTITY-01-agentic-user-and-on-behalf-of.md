# SPEC-IDENTITY-01: Agentic User — Principal, Attribution & Authentication

> **Status:** Draft · **Owner:** Patryk Lewczuk (Comerito) · **Updated:** 2026-06-16
> **Module:** `@open-mercato/agent-orchestrator` · **subdomain:** `identity` · **Depends:** `auth`, `audit_logs`, `api_keys`, `SPEC-AGENTINT-01`; consumed by `SPEC-DISPATCH-01`, `SPEC-TRACE-01`

## TLDR

Makes agents **first-class principals** so every agent action is registered, authorized, and audited *identically to a human's* — through OM's existing Command/CRUD/ACL/audit pipeline — and records a verifiable **on-behalf-of** chain from the agent back to the human (or system) that invoked it. Agents are not "locked out of login": humans authenticate interactively, agents authenticate via a **non-interactive standard credential flow** (OAuth client-credentials now; `auth.md`/ID-JAG self-registration later). The interactive password/SSO path simply isn't exposed to `kind=agent` — a property, not a special block.

## Problem statement

Agent actions today would either be attributed to the invoking human (wrong — hides the agent) or to a generic system actor (wrong — loses accountability). There is no agent principal, no human→agent attribution chain, and no standard way for external agents to obtain scoped, revocable credentials. For a high-risk regulated domain this breaks auditability and AI Act Art. 12/14 traceability.

## What OM already provides (reuse — this is why it's cheap)

- **`auth`**: single `User` entity with **nullable `passwordHash`** (passwordless principals already supported), `Role` + `roles/acl` (RBAC), JWT sessions, precedent for distinct principal tables (`users` vs `customer_users`).
- **`audit_logs.ActionLog`**: already records `actorUserId`, **`sourceKey`** (action origin), `context_json`, `parentResource*` (chaining), full before/after snapshots — and is written **automatically** by the Command / CRUD-factory layer from the request→auth context. Attribution is already pervasive and automatic.
- **`api_keys`** + `packages/shared/lib/auth/jwt.ts`: token/credential primitives to build scoped agent credentials on.

The hard part (threading actor identity into every write + audit) exists. This spec adds a principal *kind*, an on-behalf-of field, and the credential flow.

## UMES extension points used

- `INVOKE_AGENT` (`SPEC-AGENTINT-01`) sets the execution context's actor + on-behalf-of.
- `audit_logs` source-key registry: add `agent`. `auth` login flow: gate `kind` out of interactive auth.
- ACL features per agent capability (least privilege).

## Data models

```typescript
// EXTEND auth.User
kind: 'human' | 'agent' | 'service'   // default 'human'; agents are passwordless User rows

// EXTEND audit_logs.ActionLog
onBehalfOfUserId: uuid | null          // the originating human (null = system/auto); indexed
// + add 'agent' to the ActionLogSourceKey enum

// NEW — links an agent User to its definition + credential mode + scopes
@Entity() class AgentPrincipal {
  id; organizationId; userId;          // the agent's User (kind='agent')
  agentDefinitionId;                   // FK → orchestration.AgentDefinition
  roleId;                              // scoped Role (least privilege)
  @Enum() credentialMode;              // internal | oauth_client | authmd
  enabled; createdAt;
}

// NEW — the on-behalf-of delegation record for EXTERNAL agents (mirrors auth.md per (iss,sub,aud))
@Entity() class DelegationGrant {
  id; organizationId; agentUserId; onBehalfOfUserId;
  issuer; subject; audience;           // OIDC/ID-JAG identity assertion
  @Json() scopes; issuedAt; expiresAt; revokedAt?;
}
```

## Authentication model (two standard flows, one principal model)

- **Humans** → existing interactive JWT session + 2FA. Unchanged.
- **Internal agents** (in-process, via `INVOKE_AGENT`) → no network auth. The activity sets execution context `{ actorUserId: agentUserId, onBehalfOfUserId: invokerId | null, sourceKey: 'agent' }`. Existing audit + ACL then apply automatically.
- **External / A2A / BYO agents** → non-interactive standard credentials:
  - **Now:** OAuth **client-credentials** issuing scoped, revocable tokens to an `AgentPrincipal` (built on `api_keys` + JWT), with a `DelegationGrant` binding the agent to the on-behalf-of human.
  - **Later:** `auth.md` discovery + Protected Resource Metadata (`/.well-known`) + `/agent/auth` verifying a provider **ID-JAG** against its JWKS → issues the scoped token + `DelegationGrant`. The ID-JAG *is* the verifiable, revocable on-behalf-of proof. `auth.md` composes OAuth/OIDC, so the durable bet is those standards; `auth.md` is the self-registration layer added when many external agents must onboard.

`auth.md` complements A2A: the Agent Card declares *which* schemes a remote agent supports; `auth.md` is *how* it registers and gets the delegated token.

## The no-bypass invariant (load-bearing)

Audit completeness depends on agents never writing outside the Command/CRUD path (a raw `EntityManager` write would be unattributed). Enforce: **all agent mutations route through Commands/CRUD**, via `ai_assistant` tool allowlist + mutation-policy (raw-write tools disallowed) and `SPEC-GUARD-01` tool-scope checks. Ship a test asserting no `kind='agent'` actor ever appears outside the audited path.

## API contracts

- Internal: `ExecutionContext.runAs({ agentUserId, onBehalfOfUserId })` wrapper used by `INVOKE_AGENT`.
- External (now): `POST /api/agent-identity/token` (OAuth client-credentials) → scoped token + `DelegationGrant`.
- External (later): `GET /.well-known/oauth-protected-resource`, `GET /auth.md`, `POST /agent/auth` (ID-JAG verify → token).
- Revocation: `POST /api/agent-identity/grants/:id/revoke`.
- Audit query: `GET /api/audit/by-instigator/:humanUserId` (all actions a human caused directly or via agents, joined on `onBehalfOfUserId`).

## Phases

1. `User.kind` + `AgentPrincipal` provisioning (agent User + scoped Role) — internal agents fully attributed.
2. `ActionLog.onBehalfOfUserId` + `agent` source key + context propagation in `INVOKE_AGENT` (and through dispatch/trace) + audit UI chain ("Agent X on behalf of Y").
3. External agents: OAuth client-credentials scoped tokens + `DelegationGrant` + the no-bypass enforcement + test.
4. `auth.md` / ID-JAG self-registration (`/.well-known` + `/agent/auth`) for external-agent onboarding at scale.

## Acceptance

- Every agent action writes an `ActionLog` with `actorUserId` = the agent principal and, when human-invoked, `onBehalfOfUserId` = the human — through the same Command/CRUD/ACL path as a human action.
- Agents cannot use the interactive login flow; they authenticate only via non-interactive standard credentials.
- A single query returns everything a given human caused directly and via agents.
- No `kind='agent'` actor appears outside the audited Command path (enforced by test).
- External-agent tokens are scoped and revocable; revoking a `DelegationGrant` stops further action immediately.

## Effort

Small-to-Medium (~2–3 weeks for phases 1–3), because actor-context threading + automatic audit already exist. Phase 4 (`auth.md`) is additive and gated on needing external-agent self-onboarding.
