# SPEC-CONTEXT-01: Context & Knowledge Plane

> **Status:** Draft · **Owner:** Patryk Lewczuk (Comerito) · **Updated:** 2026-06-16
> **Module:** `@open-mercato/agent-orchestrator` · **subdomain:** `context` · **Depends:** `query_index`, `search`, `attachments`, `SPEC-AGENTINT-01`; extends `2026-04-27-ai-agent-attachment-processing-and-context`

## TLDR

Decides *what an agent sees*. Implements Task-Driven Context Routing (TDCR) — assembling a minimal, relevant, governed context bundle per agent run from OM data, documents, and retrieval — and records what was routed vs. pruned (for the trace inspector and audit). Agents are only as good as their context; this is the input side of quality.

## Problem statement

`INVOKE_AGENT` needs context, but there's no governed assembly layer: which entities, which documents, which retrieved knowledge, with what token budget, redacted how, and recorded how. OM has the retrieval substrate (`query_index`, vector `search`, `attachments`) but not the agent-facing assembly + provenance.

## What OM already provides (reuse)

- `query_index` + `search` (vector/semantic retrieval), `storage-s3` artifacts.
- `attachments` + `ai-agent-attachment-processing` (document intake + extraction).
- `entities` / custom fields (the structured business data), field-level encryption.

## UMES extension points used

- Context resolver invoked by the `INVOKE_AGENT` activity (`SPEC-AGENTINT-01`).
- Pluggable **context modules** (per domain) declaring what each capability may retrieve.

## Data models

```typescript
@Entity() class ContextBundle {
  id; organizationId; agentRunId;
  @Json() routedModules;   // [{ key, tokens, source }]
  @Json() prunedModules;   // [{ key, reason }]
  tokenBudget; tokensUsed;
  @Json() sources;         // provenance: entity ids, doc ids, retrieval hits (→ lineage)
  createdAt;
}
```

## Capabilities

- **TDCR assembly:** given a capability + task, select the minimal context modules (structured records, policy docs, prior cases, retrieved snippets) under a token budget; prune the rest; record both (powers the trace inspector's "context assembled" panel and the override-rate diagnosis).
- **Retrieval/grounding source:** wrap `query_index`/`search`; return cited snippets so `SPEC-GUARD-01` can verify grounding.
- **Document ingest (§ingest):** extend `attachments`/`ai-agent-attachment-processing` for claims (OCR, classification, field extraction); extracted facts carry provenance.
- **Lineage (§lineage):** every fact in a bundle links to its source (entity/doc/retrieval), so a disposition can be traced to its evidence — required for contestability (`SPEC-COMPLY-01`).
- **Redaction:** apply field-encryption/PII rules so agents receive least-privilege context.

## API contracts

- `ContextResolver.assemble({ capability, processId, stepId, budget })` → `ContextBundle` (+ payload ref).
- `ContextResolver.retrieve(query, scope)` → cited snippets.

## Phases

1. Context module registry + TDCR assembly over structured entities (+ provenance).
2. Retrieval source over `query_index`/`search` with citations.
3. Document ingest/extraction for claims with lineage.
4. Redaction/least-privilege + token-budget enforcement.

## Acceptance

- An `INVOKE_AGENT` run produces a `ContextBundle` recording routed vs. pruned modules and token usage, visible in the trace inspector.
- Every retrieved snippet is citable; ungrounded factual proposals are catchable by `SPEC-GUARD-01`.
- Each extracted claim fact links to its source document (lineage).
