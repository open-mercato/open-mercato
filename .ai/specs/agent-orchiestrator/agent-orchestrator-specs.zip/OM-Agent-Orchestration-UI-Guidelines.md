# Agent Orchestration Layer — UI Guidelines for Open Mercato

> Scope: screens + data model for managing agents that cooperate with humans on long-running processes, at a scale of thousands of processes/week with multiple agents per process. Runtime: pluggable external agent runtimes (Azure AI Foundry is one example) + Open Mercato (orchestration / system of record / operator cockpit).
>
> A working interactive prototype of these ideas exists: `om-agent-cockpit-v3.html` (Admin / Operator / Engineer perspectives, insurance-claims themed).

---

## 1. The one decision that shapes everything

At thousands of processes/week you **cannot** use the chat paradigm as the spine. One human babysitting one conversation does not scale, and replacing operational dashboards with a chatbot is a known anti-pattern.

The correct paradigm is **ambient + exception-based**:
- The system runs autonomously by default.
- It surfaces to a human **only** when a process needs a decision (notify / question / review / task).
- The human's primary surface is a **prioritized work surface**, not a chat window.

The metric you are designing against is **operator-to-process ratio** — how many concurrent processes one human can safely supervise. The binding constraint is *human review capacity*, not agent compute. Industry rule of thumb today: ~2–3 processes per operator with no operator surface, 10–20+ (and well beyond, with good triage) with a well-designed queue + alerting. Every screen decision should be judged by whether it raises that ratio.

The high-leverage work is **negative work**: filtering the 117 normal items so the human only sees the 3 exceptions. Build the UI to *hide* things, not to show everything.

This maps cleanly onto the core principle: **LLM proposes, OM disposes.** The (pluggable) agent runtime is the engine; OM is the cockpit. Every agent proposal becomes a *typed OM record with a disposition*, and the UI is fundamentally a **disposition surface**.

---

## 2. Perspectives — different actors need different surfaces

The orchestration layer is not one UI. It is a set of **role-scoped views over a shared data model**. Four actors, four jobs:

| Actor | Scope | Core question | Home surface |
|---|---|---|---|
| **Admin / platform** | All processes, agents, tenants | "Is the fleet healthy? Where's the systemic root cause?" | Fleet overview → drill down |
| **Operator / case worker** | Only *their* assigned caseload | "Of my cases, which need me, and why?" | My caseload (process-centric) |
| **Agent engineer / AgentOps** | Agents, traces, evals | "Is this agent good? Why did it do that?" | Traces → trace inspector |
| **Auditor / compliance** | Decisions + overrides (read-only) | "Was human oversight real and logged?" | Audit log |

Key implementation point: **same entities, RBAC-scoped queries, role-specific default views.** The admin "Inbox" (global triage across everyone's work) and the operator "caseload" (my processes) are the *same* `Process` / `HumanTask` data, filtered and framed differently — not separate systems. The persona switch in the prototype demonstrates this: one data layer, three cockpits.

### 2.1 Admin / platform — the fleet lens
Aggregate health, then drill to root cause. This is monitoring + governance, not daily case work. Owns the fleet dashboard, the global process list, the agent registry, and audit. (Detailed in §4.1, §4.4, §4.7, §4.8.)

### 2.2 Operator / case worker — the caseload lens
The inbox-centric, item-by-item view is fundamentally an **admin/triage** construct. A case worker thinks in **whole processes**, because the judgment they make usually needs the full case context, not an isolated question. So the operator home is a **caseload scoped to them**, organized first by *what each process needs from them*. (Detailed in §3 and §4.2.)

### 2.3 Agent engineer / AgentOps — the trace lens
Wants to understand *why* an agent did what it did, and whether it is good enough to trust more. Lives in traces, tool I/O, reasoning, and eval results. (Detailed in §4.5–§4.6.)

### 2.4 Auditor / compliance — the record lens
Read-only. Cares that every gate was a real decision before the action fired, and that everything is logged and retained. (Detailed in §4.8.)

---

## 3. The work model — four verbs

Whatever the persona, the things that need a human reduce to four verbs. This is the operator's mental model and the organizing axis of the caseload:

- **Decide** — an agent proposed an action; you dispose (the HITL gate). Approve / edit / reject.
- **Answer** — an agent is blocked and asks you a question. Provide input to unblock it.
- **Do** — a human work step the *process itself* assigns to a person (call the claimant, verify a document, physical inspection). **Not** agent-triggered — it is a normal step in the workflow that happens to be human work.
- **Know** — notify / FYI; acknowledge.

`Decide` / `Answer` / `Know` map to the three interrupt types raised *by an agent mid-execution* (review / question / notify). **`Do` is categorically different**: it is a human step placed by the `ProcessDefinition`, with its own SLA and assignment rules, raised because the workflow reached a human step — not because an agent got stuck.

Design implication: keep all four in one caseload (one place for "what's mine today"), but **model the kind explicitly** so `Do` can diverge later — different SLAs, skills-based routing, scheduling — without restructuring.

---

## 4. Screen inventory

Two mental models stack: **altitude** (fleet → caseload → process → step → trace) and **persona** (who is this altitude for). Each screen below names its primary persona.

### 4.1 Fleet / Operations dashboard — *admin*
Aggregate health of the whole system, never per-process detail.
- Throughput (started / completed / failed per day-week).
- **Queue depth** + oldest-waiting item (the leading indicator of trouble).
- SLA breaches and **stuck / stalled** processes.
- Exception rate (% needing a human) and auto-completion rate.
- **Operator-to-process ratio** as a headline tile.
- Cost (tokens / $) by process type and by agent.
- Where humans stepped in (which gates fire most) + per-agent override rates.

Charts + alert tiles. A monitoring screen, not a work screen.

### 4.2 My caseload — *operator* (the operator's home)
Scoped to the operator's assigned processes. Opens with a **summary strip** (e.g. "104 assigned · 9 need you · 14 waiting · 78 running · 3 closed today"), then the processes that need action **grouped by verb** (Decide / Answer / Do), each group sub-counted.

Each case row keeps the whole case in view: claim id, type, **current stage**, **agents on it**, the **specific ask**, **SLA**. Secondary filters: *Needs you* (default), *Waiting* (on third party / customer), *Running* (agents working, no action), *All*.

This is the operator equivalent of the admin inbox, but process-centric and "my work" framed. Triage-first: sort by priority × SLA age.

### 4.3 Inbox / global work queue — *admin*
The cross-team triage queue of all `HumanTask` items. Same verb model, filterable by type, assignable/claimable (avoid two people grabbing one item), bulk actions, keyboard-first. Each item is **self-contained** — enough context to decide without opening the process in the common case; deep-link for the hard ones.

### 4.4 Process list — *admin* (ERP-style entity view)
All processes, searchable / filterable / segmentable.
- Columns: status, stage, owner, assigned agents, age, SLA, last activity, cost.
- **Saved segments** ("my team's claims", "stuck > 24h", "high-value", "fraud flagged") — at thousands/week this is how humans navigate. First-class.
- Bulk operations and CSV export.

### 4.5 Process detail / run view — *operator + admin* (the cockpit for one process)
Where a human understands and steers a single long-running, multi-agent process.
- **State machine** across the top — current stage, done, waiting, next.
- **Unified attributed timeline** of everything that happened (which agent did what, when). For ops use, one timeline with attribution beats per-agent swimlanes; offer a collapsible per-agent view when several agents run concurrently.
- Visualize the **perception / adjudication split** directly: agent *proposals* on one lane, OM *dispositions* on the other, with handoffs crossing between them. The payout-gate firing should be legible as a single read top-to-bottom.
- **Active proposals** awaiting decision, inline (approve / edit / reject / redirect).
- **Intervention controls**: pause, take over, reassign to another agent, inject guidance, roll back to a checkpoint.
- **Inline agent I/O inspector** (see §4.6a).
- A scoped **"ask about this process"** chat — secondary affordance, not the spine.

### 4.6 Agent input / output + trace — *engineer* (with a lightweight slice for everyone)

**(a) Inline I/O inspector** — available from any step on the process timeline, for operators and admins too. A drawer showing that step's **input** (what it received), **output** (what it produced), **tools called**, and confidence / latency / cost. Answers "why did it propose this" without leaving the case.

**(b) Full trace inspector** — the AgentOps deep dive, a dedicated workspace for one agent run:
- **Span waterfall** — sub-steps on a time axis (`context.assemble → llm.plan → tool calls → llm.synthesize → output.validate`), colored by type, with per-span latency. Surfaces the cost center.
- **Context assembled** — which context modules were routed in vs pruned. Surface **Task-Driven Context Routing** explicitly ("routed 4 of 14 modules · pruned 9.1k tokens") so the routing decision is auditable.
- **Reasoning** — the intermediate chain, with the gate step highlighted.
- **Tool calls** — each expandable to full request + response JSON, latency, status.
- **Output payload** — the typed record OM stores.
- **Eval assertions** — Inspect-AI-style pass/fail checks per run (`coverage_clause_cited`, `estimate_within_tolerance`, `rationale_no_pii`, `output_schema_valid` …) with a score, and **"Add run to eval set"** — the correction → regression loop made first-class.
- **Model comparison** — same input, prod model vs candidate, side by side: decision, confidence, cost, latency, eval score. This is the exact shape of the Claude-Code-vs-Codex benchmark decision: a candidate may be cheaper / faster but fail a safety assertion → **not promotable**.

**Cross-persona handoff (important):** a supervisor who sees a questionable proposal in Process detail opens the step's I/O drawer → **"Open full trace"** → lands in the engineer's trace inspector for that run. The realistic escalation path from "this looks wrong" to root cause.

### 4.7 Agent registry / catalog — *admin + engineer*
The agents themselves: definitions, versions, tools, permissions, and **per-agent performance** (success rate, **override rate**, avg cost, SLA hit rate). Override rate is the single best "is this agent trustworthy yet" signal — surface it prominently. Pair it with an **autonomy level** per agent (Auto / Review / Gated) that you widen as the override rate drops.

### 4.8 Governance / audit — *auditor* (read-only)
Immutable log + compliance views. **For the insurance use case this is not optional** — claims processing is high-risk under the EU AI Act, which mandates human oversight at all times (Art. 14) and automatic event logging for post-market monitoring (Art. 12); GPAI obligations apply from Aug 2026. Build: who approved what and when, full correction history, retention + access controls designed in from the start. The HITL gate must be a *real decision gate before the action fires*, not an after-the-fact log review.

---

## 5. Domain model (model these as first-class OM entities)

Make these MikroORM entities so they inherit list views, filtering, RBAC, custom fields, and multi-tenant scoping for free.

| Entity | Purpose | Notes |
|---|---|---|
| **Process** (Run) | The long-running instance | Owns a state machine; canonical record. Maps to a runtime thread/run. |
| **ProcessDefinition** | The template / workflow type | Versioned. Defines stages, SLAs, which steps gate, and which steps are human (`Do`). |
| **Stage / Step** | Unit of work inside a process | Owner = agent or human. Sequenced or DAG. |
| **AgentDefinition** | An agent's identity, tools, permissions | Versioned; performance metrics + autonomy level attach here. |
| **AgentSession** | A concrete agent instance bound to a process | The "who is working on this right now". |
| **Proposal** (Action) | Something an agent wants to do | Payload + confidence + **disposition** (pending / approved / edited / rejected). The core HITL object. |
| **HumanTask** | A work item requiring a human | **kind ∈ {review→Decide, question→Answer, notify→Know, task→Do}**. SLA, assignee, status. `task` items are placed by the ProcessDefinition; the others are agent-raised interrupts. |
| **Handoff** | Transfer of control | agent→agent, agent→human, human→agent. Rendered on the timeline. |
| **AgentRun** | One agent invocation within a Step | Model, version, tokens, cost, latency, status. The unit the trace inspector opens. |
| **Span** | A sub-operation within an AgentRun | LLM call / tool call / system op — the waterfall rows (OpenTelemetry GenAI-style). |
| **ToolCall** | A tool invocation | Request + response + latency + status (a Span subtype). |
| **EvalResult** | Assertion outcomes for an AgentRun | Pass/fail checks + score; links a `Correction` to a regression case. |
| **Event / TraceSpan** | Immutable audit log | Every decision and override. Compliance-grade. |
| **Policy / Guardrail** | What triggers a gate | Irreversible action, cost > X, low confidence, regulated decision. |
| **Correction** | A logged human override + reasoning | Feeds the eval harness as a future test case. |

**`Proposal` and `HumanTask` are the heart of the system** — everything else is supporting cast. Get those two right first. `AgentRun` / `Span` / `EvalResult` are the engineer-lens additions that make traces and the eval loop first-class.

---

## 6. Cross-cutting design principles

1. **Role-scoped, one data model.** Personas are filtered + framed views over the same entities, not separate apps. RBAC drives both visibility and what each role may dispose.
2. **Exception-first, not browse-first.** Default views show what needs attention; browsing everything is secondary.
3. **Process-centric for operators.** A case worker acts on whole processes, not context-free inbox items. Keep the case in view.
4. **Separate plan from execution.** Agents reason and *propose* freely; the approval boundary sits in front of any side-effecting / irreversible action. This is "LLM proposes, OM disposes" as a UI boundary.
5. **I/O is always inspectable.** Any agent step's input, output, and tools can be opened. Transparency is a product feature, not a debug afterthought.
6. **Async by default.** Humans respond on their own schedule. Every `HumanTask` has a timeout → auto-escalate / auto-default so nothing hangs forever.
7. **Ambient notifications.** Push *Know* / urgent items to where people already are (Slack / email / in-app), with deep links back. Don't make people poll.
8. **Close the loop.** Every override becomes a `Correction` → an `EvalResult` case. The correction stream wires directly into the eval harness (Inspect AI / SWE-bench-style).
9. **Make trust visible and gradable.** Confidence + override rates + autonomy levels let you widen autonomy per agent over time — "review everything" → "review exceptions only".
10. **One timeline, attributed.** Multi-agent collaboration reads as a single attributed narrative; reserve graph/swimlane views for debugging.
11. **Chat is a tool, not the interface.** A scoped assistant inside a process is fine; chat as the primary operational surface is the trap.

---

## 7. Open Mercato implementation notes

- **Reuse what you have.** Process list + detail = standard OM entity CRUD conventions. State machine = the 9-stage pattern from HackOn App. Real-time = the SSE leaderboard pattern. The genuinely *new* UI is the **operator caseload**, the **attributed run timeline**, and the **trace inspector** — concentrate effort there.
- **Runtime ↔ OM sync (runtime-agnostic).** Runtime threads/runs map to OM `Process` / `Step` / `AgentRun` through a **runtime adapter**; sync via webhooks (preferred) or polling. OM holds the canonical record + disposition; the runtime holds the reasoning trace. Keep the boundary clean so OM stays the system of record. The trace inspector reads spans/tool-calls from the run record (mirror what's needed for audit into OM; deep-link to the runtime for the rest). The runtime is pluggable — Foundry, Bedrock, OpenAI, Vertex, in-house — selected per agent, not hard-wired.
- **Multi-tenant + RBAC from day one.** Caseload, inbox, segments must be org-scoped; RBAC governs which proposal types a role may dispose (a junior dispatches, only a senior approves a payout).
- **Custom fields.** Use OM's custom-field system so process types carry domain attributes (claim amount, policy number) without schema churn.
- **Surface Task-Driven Context Routing.** The trace's "context assembled" panel is where TDCR becomes visible and auditable — routed vs pruned modules per run.
- **Supervisor Sidecar fit.** The Supervisor Sidecar pattern maps to a system-level triage agent deciding which processes surface to humans; its decisions are themselves auditable proposals.

---

## 8. Suggested build sequence (MVP → scale)

**MVP (prove the operator-to-process ratio):**
1. `Process` + state machine + runtime sync (via a runtime adapter).
2. `Proposal` + `HumanTask` (with the four-verb `kind`) + the Decide gate.
3. **Operator caseload** grouped by verb — the screen that earns its keep.
4. **Process detail timeline** with attribution + inline approve / edit / reject + the **inline I/O drawer**.

**V2 (trust + the engineer loop):**
5. `AgentRun` / `Span` / `ToolCall` + the **trace inspector** (waterfall, context, reasoning, tools, output).
6. `EvalResult` + eval assertions panel + `Correction` → eval-set export.
7. Per-agent performance, override rate, and autonomy levels in the registry.
8. Ambient notifications (Slack / email) + SLA timeouts / escalation.

**V3 (scale + govern):**
9. Admin fleet dashboard + global inbox + process list with saved segments + bulk actions.
10. Model-comparison view (prod vs candidate) tied to the benchmark harness.
11. Full audit / compliance views (EU AI Act-aligned).
12. Progressive autonomy controls (widen the gate per agent as override rate drops).

---

## 9. Anti-patterns to avoid

- Chat window as the main operational surface.
- One-size-fits-all UI — forcing operators through an admin fleet view, or admins through a single-case view.
- Giving operators a global, item-by-item inbox instead of their own process-centric caseload.
- Conflating an agent-raised interrupt (`Decide` / `Answer`) with a process-assigned human step (`Do`) — they have different SLAs and routing.
- A dashboard that shows *everything* instead of surfacing exceptions.
- Synchronous approval gates that block the operator's whole screen.
- Per-process review at thousands/week (design for *not* reviewing most of them).
- Hiding agent I/O behind a separate debug tool — make it one click from the timeline.
- Treating the audit log as an afterthought (in a regulated domain it's a primary surface).
- Letting two people act on the same `HumanTask` (no claim/lock).
