# SPEC-LIFECYCLE-01: Agent Deployment, Budgets & Regression Gating

> **Status:** Draft · **Owner:** Patryk Lewczuk (Comerito) · **Updated:** 2026-06-16
> **Module:** `@open-mercato/agent-orchestrator` · **subdomain:** `lifecycle` · **Depends:** `feature_toggles`, `ai_assistant`, `SPEC-TRACE-01`, `eval-runner`

## TLDR

How agents and their config change safely over time: shadow/canary rollout, gradual autonomy widening, per-tenant/process cost budgets, model routing, and **regression gating** — new agent/model versions must pass the eval set (built from production corrections) before promotion. Closes the "ratio mirage" and "silent degradation" risks from the evaluation.

## Problem statement

`ai_assistant` has per-agent runtime config (models, mutation-policy, loop-override) but no controlled rollout, no autonomy ramp tied to override rate, no enforced cost budgets, and no gate that blocks promotion on eval regressions. Changes go straight to prod.

## What OM already provides (reuse)

- `feature_toggles` (per-org flags → canary/gradual rollout).
- `ai_assistant` per-agent models + mutation-policy + loop-override (runtime levers).
- `SPEC-TRACE-01` (`EvalCase` set, override/eval-pass metrics per agent).
- `eval-runner` (the Inspect AI scorer + `x_om` task format).

## UMES extension points used

- `feature_toggles` gates on capability→binding selection (`SPEC-DISPATCH-01` router).
- CI hook consuming `eval-runner` over the `SPEC-TRACE-01` `EvalCase` export.

## Data models

```typescript
@Entity() class AgentRelease {
  id; organizationId; agentDefinitionId; version; model;
  @Enum() stage;        // shadow | canary | active | retired
  rolloutPct;           // canary %
  @Enum() autonomy;     // gated | review | auto  (widens as override rate drops)
  @Json() evalGate;     // required pass score + eval-set version
  promotedBy; createdAt;
}
@Entity() class Budget {
  id; organizationId; scope;     // tenant | processType | agent
  windowTokens; windowCostMinor; currency;
  @Enum() onExceed;     // warn | gate | block
}
```

## Capabilities

- **Shadow mode:** run a candidate version alongside prod on the same inputs, no side effects; compare via `SPEC-TRACE-01` model-comparison (the view already exists).
- **Canary / gradual rollout:** `feature_toggles`-gated % of traffic to a new version per tenant.
- **Gradual autonomy:** `autonomy` level per release widens (gated → review → auto) as the agent's override rate drops below thresholds; surfaced in the cockpit registry.
- **Cost budgets:** enforce token/$ caps per tenant/process/agent; `onExceed` warns, gates to human, or blocks (reuses `ai_assistant` loop controls as the runtime hook).
- **Model routing:** select model per task (cheap vs capable) under budget + capability constraints.
- **Regression gating:** CI runs `eval-runner` against the `EvalCase` set (production corrections + golden runs); promotion to `active` blocked unless the candidate meets `evalGate` and introduces no safety-assertion regressions.

## API contracts

- `POST /api/agent-lifecycle/releases/:id/promote` (enforces eval gate).
- `GET /api/agent-lifecycle/budgets?scope` · budget-exceeded event → notifications.
- CI: `eval-runner run --cases <EvalCase export> --gate <evalGate>`.

## Phases

1. `AgentRelease` + shadow mode + model-comparison wiring.
2. Canary (`feature_toggles`) + gradual-autonomy ramp from override rate.
3. Cost budgets + model routing.
4. Regression-gated promotion in CI over the eval set.

## Acceptance

- A candidate version runs in shadow and is comparable to prod on identical inputs.
- A new version cannot be promoted to `active` if it regresses a safety assertion in the eval set.
- An agent's autonomy widens automatically only when its override rate is under threshold.
- A process exceeding its token budget warns/gates/blocks per policy.
