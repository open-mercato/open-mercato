# SPEC-DISPATCH-01: Agent Task Dispatch & Connectivity

> **Status:** Draft · **Owner:** Patryk Lewczuk (Comerito) · **Updated:** 2026-06-16
> **Module:** `@open-mercato/agent-orchestrator` · **subdomain:** `dispatch` · **Depends:** `workflows`, `packages/queue`, `api_keys`, `SPEC-AGENTINT-01`, `SPEC-TRACE-01`

## TLDR

The connectivity layer that gets a unit of agent work to a capable agent — **internal** (OM-hosted), **pull** (firewalled / bring-your-own-compute), or **A2A push** (callable external/partner agents on any runtime) — behind one `AgentTask` contract. Invoked by the `INVOKE_AGENT` activity (`SPEC-AGENTINT-01`); results hand off to `SPEC-TRACE-01`. The queue is *transport over typed task records*, not the source of truth. Notification is advisory; the lease is authoritative. **Runtime-agnostic:** a binding names its runtime (`internal | a2a | foundry | bedrock | openai | vertex | custom`) and the dispatcher selects the matching **runtime adapter** — no runtime is hard-wired.

**Position:** `workflows` decides work is needed → `INVOKE_AGENT` creates an `AgentTask` → **dispatch** routes/leases/transports it → agent runs → result becomes an `AgentRun`/`Proposal`. Dispatch does **not** sequence work (that's the workflow), run agents, or store traces.

**Protocol stance:** adopt **A2A** (Agent2Agent, Linux Foundation, Apache-2.0) as the external wire format — not invented. A2A standardizes capability discovery (Agent Card), task delegation, and artifact return, and is natively integrated by several runtimes (Azure AI Foundry, AWS Bedrock AgentCore, Google Vertex) — so the A2A adapter covers them with no bespoke code; **provider adapters** wrap non-A2A runtimes (OpenAI, custom). MCP (agent→tools) is out of scope here.

## Problem statement

The orchestration layer must dispatch to a heterogeneous fleet: OM-hosted agents, firewalled/BYO agents that can only **pull**, and callable external agents reachable via a standard protocol. There's no uniform abstraction to queue, capability-route, lease, survive long-running tasks + worker death + human-input pauses, and keep every task auditable and tenant-isolated.

## What OM already provides (reuse)

- `workflows` async-activity queue + `WAIT_FOR_SIGNAL` pause/resume — the **internal** dispatch path and the park/resume mechanism.
- `packages/queue` (Redis/BullMQ) + `packages/scheduler` — queue + lease-sweeper substrate.
- `api_keys` (external worker auth), `webhooks` outbound-dispatch (callback delivery), `storage-s3` (payload-by-reference), optimistic locking, multi-tenancy.

## UMES extension points used

- Custom `INVOKE_AGENT` workflow activity calls `DispatchService.enqueue` (`SPEC-AGENTINT-01`).
- ACL features: `agent_dispatch.task.view`, `agent_dispatch.worker`, `agent_dispatch.binding.manage`, `agent_dispatch.a2a.inbound`.

## Data models

```typescript
@Entity() class AgentTask {
  id; organizationId; processId; stepId; parentTaskId?;
  requiredCapability;                 // e.g. "damage.estimate"
  @Enum() status;                     // queued|claimed|running|input_required|completed|failed|cancelled|dead_letter
  priority; idempotencyKey;           // unique — dedupe at-least-once
  payloadArtifactKey?; payloadSummary?; contextRef?;   // payload by reference (storage-s3)
  slaMs?; deadlineAt?;
  assignedBindingId?; @Enum() transport?;              // internal|pull|a2a (resolved at routing)
  currentLeaseId?; attempts; maxAttempts;
  @Enum() origin;                     // orchestration | inbound_a2a
  externalTaskId?;                    // A2A task id (in/out)
  resultRunId?; failureReason?;       // FK → agent-trace.AgentRun
  createdAt; updatedAt; claimedAt?; completedAt?;
}
@Entity() class AgentBinding {        // capability registry
  id; organizationId; agentDefinitionId; displayName;
  @Json() capabilities;               // ["coverage.check", ...]
  @Enum() transportMode;              // internal|pull|a2a
  @Enum() runtime;                    // internal|a2a|foundry|bedrock|openai|vertex|custom — selects the adapter
  agentCardUrl?; authCredentialRef?;  // a2a discovery + secret ref (never the secret)
  concurrencyLimit; slaMs?; enabled;
  @Enum() healthStatus; lastSeenAt?;
}
@Entity() class TaskLease { id; organizationId; taskId; bindingId; workerId; leasedAt; expiresAt; heartbeatAt?; @Enum() status; } // active|released|expired|completed
@Entity() class TaskEvent { id; organizationId; taskId; fromStatus?; toStatus; actor; @Json() detail?; at; } // append-only
```

## Lifecycle

```
queued ─route/claim▶ claimed ─start▶ running ─┬─ completed
   ▲                                          ├─ failed
   └── lease expired (attempts++; ≥max ⇒ dead_letter)   └─ input_required ─answer▶ running
any active ─cancel▶ cancelled ;  dead_letter ▶ surfaces in caseload for triage
```
- `input_required` maps to a `USER_TASK` (Decide/Answer) in `workflows`; A2A's `input-required`/`auth-required` map here for external agents.
- Sweeper re-queues tasks whose lease expired without heartbeat; stale results for expired leases are rejected.
- Every transition writes a `TaskEvent`.

## Transport adapters (one interface, three impls)

- **internal** — enqueue to the `workflows`/`packages/queue` worker; result reported to agent-trace.
- **pull** — task published to a capability-scoped queue; firewalled/BYO workers `claim`/`heartbeat`/`result` over HTTP (they reach out — no inbound connectivity to them needed).
- **a2a push** — OM as A2A client: resolve Agent Card, delegate task, receive artifacts via push-notification webhook (resilient for long-running), map A2A states → `AgentTask` states.
- **a2a server** — OM publishes `/.well-known/agent-card.json`; inbound A2A task → `AgentTask` (`origin=inbound_a2a`) → run via internal/pull → return artifacts. Makes OM a node in the mesh.

**Runtime adapters** sit behind the push transports: `a2a` for any A2A-compliant runtime (Foundry, Bedrock, Vertex …) and thin `provider` adapters for non-A2A runtimes (OpenAI, custom). Each provider adapter maps the runtime's invoke + trace API to the `AgentTask`/`AgentRun` contract and normalizes spans to OM's model (target: OTel GenAI). Adding a runtime = adding one adapter; nothing else changes.

## API contracts

- Worker (scoped token): `POST /claim` (long-poll), `POST /tasks/:id/heartbeat`, `POST /tasks/:id/result`, `POST /tasks/:id/input`.
- A2A: `GET /.well-known/agent-card.json`, `POST /a2a/tasks` (inbound), `POST /a2a/callbacks/:id` (client push intake).
- Admin/read (`makeCrudRoute`): `/tasks`, `/tasks/:id`, `/bindings`, `/metrics` (queue depth, per-capability backlog, per-binding concurrency/health).
- Internal: `DispatchService.enqueue(task)` (called by `INVOKE_AGENT`).
- Events: `agent_task.created|claimed|running|input_required|completed|failed|dead_lettered`, `agent_binding.health_changed`.

## Security & constraints

- External agents authenticate as **agent principals** via standard non-interactive credentials (OAuth client-credentials now, `auth.md`/ID-JAG later) per `SPEC-IDENTITY-01` — not bespoke tokens; scoped per capability + tenant, revocable. **Payload by reference** with time-limited scoped URLs — a worker never sees more than its task envelope.
- A2A auth negotiated via Agent Card schemes; `auth.md` is the complementary registration/delegation layer. Every external action is attributed to the agent principal with an on-behalf-of `DelegationGrant` (`SPEC-IDENTITY-01`).
- At-least-once delivery + `idempotencyKey` + idempotent result writes (side-effect execution still gates through OM per "LLM proposes, OM disposes").
- Long-running: lease + heartbeat/extension; A2A via push-notification callbacks, not held connections. Dead-letter never silently drops.

## Open questions

1. Queue backend: **Postgres `SKIP LOCKED`** (keeps `AgentTask` the single source of truth, no new infra) vs BullMQ (already in `packages/queue`) vs Temporal (subsumes lease/retry, heavy dep). Lean Postgres `SKIP LOCKED` for v1.
2. Capability ownership: `AgentDefinition` declares *intended* capabilities; `AgentBinding` declares *deployed/reachable*. Confirm boundary.
3. A2A TS SDK maturity (client + server) at target version.

## Phases

1. `AgentTask` + `TaskEvent` + state machine + `DispatchService`.
2. `AgentBinding` registry + `TaskRouter` (capability match, concurrency, priority).
3. Internal adapter + result → agent-trace ingestion.
4. Pull adapter: claim/heartbeat/result + `TaskLease` + sweeper + scoped tokens.
5. A2A client (Agent Card, delegation, artifact mapping).
6. A2A server (OM Agent Card, inbound → `AgentTask`).
7. HITL bridge (`input_required` ↔ `USER_TASK`), dead-letter → caseload, payload-by-reference, fairness, health.

**Critical path (internal + external pull — the original ask):** phases 1→2→3→4. A2A (5/6) layers external callable agents on without changing the task contract.

## Acceptance

- Any registered agent (internal/pull/a2a) claims and completes a task through one contract.
- An external A2A agent integrates via its Agent Card with no bespoke connector code.
- A task whose worker dies is re-dispatched after lease expiry; stale results are rejected.
- A task needing a human transitions to `input_required`, surfaces as a `USER_TASK`, and resumes on response.
- An external worker can never access another tenant's task or payload.
