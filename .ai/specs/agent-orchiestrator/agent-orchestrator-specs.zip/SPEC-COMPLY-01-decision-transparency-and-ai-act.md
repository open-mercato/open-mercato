# SPEC-COMPLY-01: Decision Transparency, GDPR & AI Act Conformity

> **Status:** Draft · **Owner:** Patryk Lewczuk (Comerito) · **Updated:** 2026-06-16
> **Module:** `@open-mercato/agent-orchestrator` · **subdomain:** `compliance` · **Depends:** `SPEC-TRACE-01`, `SPEC-CONTEXT-01`, `portal`, `customer_accounts`, `audit_logs`

## TLDR

The affected-person and regulator side, which the internal cockpit does not cover. Provides a claimant-facing **explanation + contest/appeal** surface, GDPR data-subject rights, bias/fairness monitoring, and the EU AI Act conformity programme for a high-risk system (claims adjudication). Cannot be retrofitted late.

## Problem statement

Every surface designed so far serves operators/engineers. A claimant subject to an automated/assisted decision has rights (GDPR Art. 22 — meaningful information + contest; AI Act Art. 13/14/86 — transparency + human oversight + right to explanation). High-risk insurance also requires bias monitoring, technical documentation, post-market monitoring, and serious-incident reporting. None of this exists yet.

## What OM already provides (reuse)

- `portal` + `customer_accounts` (the self-service surface for claimants).
- `audit_logs` (immutable record, export), `telemetry-and-otel` (post-market monitoring substrate).
- `SPEC-TRACE-01` (the decision record + reasoning + correction history), `SPEC-CONTEXT-01` lineage (evidence per fact).
- Field-level encryption (PII protection).

## UMES extension points used

- `portal` pages for explanation + contest; `business_rules` ACTION rule to open a contest case (a new workflow).
- `audit_logs` exporters for conformity packs.

## Data models

```typescript
@Entity() class DecisionRecord {     // claimant-facing, derived from Proposal+disposition
  id; organizationId; processId; subjectId;
  outcome; plainExplanation;         // human-comprehensible reason (not the engineer trace)
  @Json() factorsUsed;               // top factors + their evidence (from lineage)
  humanInvolved; reviewerRole;
  contestableUntil; createdAt;
}
@Entity() class ContestCase {
  id; organizationId; decisionRecordId; subjectId;
  @Enum() status;                    // open | under_review | upheld | overturned
  grounds; resolution; createdAt;
}
@Entity() class FairnessMetric {
  id; organizationId; capability; window;
  @Json() byCohort;                  // outcome/approval rates by protected attribute (privacy-safe)
  flagged; createdAt;
}
```

## Capabilities

- **Plain-language explanation:** generate a claimant-comprehensible reason from the disposition + `factorsUsed` + lineage (distinct from the engineer trace). Stored as a `DecisionRecord`.
- **Contest / appeal:** a `portal` flow that opens a `ContestCase` → a review workflow with a mandatory human; overturns write a `Correction` (→ eval set).
- **Human-involvement disclosure:** record whether a human meaningfully reviewed (anti-rubber-stamp; ties to AI Act Art. 14 and the cockpit's sampled-review signals).
- **GDPR rights:** DSAR export (reuse `audit_logs` exporters), erasure with audit-preserving tombstones (reuse the artifact-store erasure pattern from `SPEC-TRACE-01`), consent/lawful-basis flags.
- **Bias/fairness monitoring:** periodic `FairnessMetric` rollups by cohort; thresholds flag for review.
- **Conformity programme:** technical-documentation generator (system/model cards from registry + TRACE), post-market monitoring dashboard (over `telemetry-and-otel`), serious-incident reporting workflow.

## API contracts

- `GET /portal/decisions/:id` (claimant explanation) · `POST /portal/decisions/:id/contest`.
- `GET /api/compliance/dsar/:subjectId` · `POST /api/compliance/erasure/:subjectId`.
- `GET /api/compliance/fairness?capability&window`.

## Phases

1. `DecisionRecord` + claimant explanation surface (Art. 22 minimum).
2. Contest/appeal workflow + human-involvement disclosure.
3. GDPR DSAR/erasure/consent.
4. Bias/fairness monitoring + conformity documentation + incident reporting.

## Acceptance

- A claimant can view a plain-language reason for their outcome and open a contest that routes to a human-reviewed workflow.
- An overturned contest writes a `Correction` and feeds the eval set.
- Fairness metrics by cohort are computable and flag threshold breaches.
- DSAR export and audit-preserving erasure both function.
