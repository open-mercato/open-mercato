# SPEC-TRACE-01: Agent Trace, Evaluation & Correction Capture

> **Status:** Draft · **Owner:** Patryk Lewczuk (Comerito) · **Updated:** 2026-06-16
> **Module:** `@open-mercato/agent-orchestrator` · **subdomain:** `trace` · **Depends:** `workflows`, `audit_logs`, `storage-s3`, `eval-runner`, `SPEC-DISPATCH-01`, `SPEC-AGENTINT-01`

## TLDR

The runtime trace + eval + correction plane — the "learning loop". Captures every production agent run (`AgentRun` → `Span` → `ToolCall`), evaluates it against assertions, records human **corrections**, and promotes corrections + golden runs into a regression **eval set** consumed by `eval-runner`. This is the highest-leverage, most-durable piece of the orchestration layer.

**Scope vs `eval-runner` (do not merge):** `eval-runner` (SPEC-00..18) benchmarks *coding* agents offline to pick the best one. **This** captures *production business* agents online and feeds regression cases back, in the same `x_om`/SWE-bench-style format `eval-runner` already consumes. It does not re-implement the Inspect AI scorer — it reuses it via export.

## Problem statement

`workflows` event sourcing audits the *process*; it does not record agent-level detail (spans, tokens, cost, confidence, tool I/O), evaluate runs, or capture overrides as regression tests. Without this, the trace inspector has nothing to read, agent degradation is invisible, overrides evaporate, and EU AI Act Art. 12 logging is unmet.

## What OM already provides (reuse)

- `workflows` event store (process-level audit — complemented, not duplicated), `audit_logs` (immutable, export, retention).
- `storage-s3` artifact store (large payloads by reference), `telemetry-and-otel` (metrics substrate).
- `eval-runner` (Inspect AI scorer + `x_om` task format — the consumer of the eval set).

## UMES extension points used

- Runtime-agnostic ingestion webhook + result handoff from `SPEC-DISPATCH-01` (runtime adapters normalize each runtime's trace to the model below; target: OTel GenAI semantic conventions).
- `Proposal` shared with `SPEC-AGENTINT-01`; `EvalCase` export consumed by `eval-runner`; metrics feed `SPEC-LIFECYCLE-01` gates and `SPEC-COCKPIT-01`.
- ACL features: `agent_trace.view`, `agent_trace.correct`, `agent_eval.manage`, `agent_eval.export`.

## Data models

```typescript
@Entity() class AgentRun {
  id; organizationId; processId; stepId; proposalId?;
  agentDefinitionId; agentVersion; model; runtime; externalRunId;   // (runtime, externalRunId) unique — idempotent
  @Enum() status;                     // running|ok|error|cancelled
  confidence?; inputTokens?; outputTokens?; costMinor?; currency; latencyMs?;
  evalScore?; evalPassed?;
  @Json() contextRouting?;            // TDCR routed vs pruned (SPEC-CONTEXT-01)
  outputArtifactKey?; humanConfirmedAt?;
  createdAt; updatedAt;
}
@Entity() class AgentSpan { id; organizationId; agentRunId; parentSpanId?; sequence; name; @Enum() kind; startedAt; endedAt?; durationMs?; @Enum() status; @Json() attributes?; } // kind: llm|tool|system
@Entity() class AgentToolCall { id; organizationId; spanId; agentRunId; toolName; @Json() requestSummary?; responseSummary?; requestArtifactKey?; responseArtifactKey?; @Enum() status; latencyMs?; errorMessage?; }
@Entity() class EvalAssertion { id; organizationId; key; title; description; appliesTo; @Enum() type; @Enum() severity; @Json() config; version; enabled; } // type: deterministic|llm_judge ; severity: gate|warn
@Entity() class EvalResult { id; organizationId; agentRunId; assertionId; assertionKey; passed; score?; @Json() evidence?; evaluatedAt; }
@Entity() class AgentCorrection { id; organizationId; processId; stepId; agentRunId?; proposalId; correctedByUserId; @Enum() action; @Json() proposedValue; correctedValue; reason; evalCaseId?; createdAt; } // append-only; action: edit|reject|override|answer
@Entity() class EvalCase { id; organizationId; @Enum() sourceType; sourceId; agentDefinitionId; processType; @Json() input; expected; @Json() assertions?; @Enum() status; approvedByUserId?; createdAt; } // sourceType: correction|golden_run ; status: draft|approved|archived
```
`Span`/`ToolCall` large payloads (prompts, full req/resp, output) live in `storage-s3` by key; rows hold small summaries.

## Assertions & flywheel

- **Two tiers.** Runtime guardrail-style assertions = deterministic, fast (schema, threshold, PII) and may `gate`. Offline scoring = `llm_judge` rubric, reuses the `eval-runner` Inspect scorer, sampled, never blocks production.
- **Flywheel:** human override → `AgentCorrection` (mandatory reason) → auto `draft` `EvalCase(input, expected=correctedValue)` → engineer approves → `EvalCaseExporter` (`x_om`) → `eval-runner` regresses future versions (`SPEC-LIFECYCLE-01` gate).
- **Anti-rubber-stamp:** track approve-unchanged rate, sample auto-approved runs for re-review, surface `warn`s even on human-approved runs (AI Act Art. 14; feeds `SPEC-COCKPIT-01`).

## API contracts

- `POST /api/agent-trace/ingest` — runtime/dispatch webhook, HMAC-verified, idempotent by `(runtime, externalRunId)`.
- Read (`makeCrudRoute`): `GET /runs` (filter overridden|low-confidence|eval-fail|agent|window), `GET /runs/:id` (spans, tool calls, context routing, eval, artifact links), `GET /agents/:id/metrics`.
- `POST /corrections` (from disposition flow), `POST /eval-cases/:id/approve`, `GET /eval-cases/export` (`x_om`).
- Events: `agent_run.ingested|evaluated`, `proposal.corrected`, `eval_case.created|approved`.

## Constraints

- **Volume:** ~9M spans/yr at thousands/wk; partition `agent_span` by `createdAt`, tier retention (hot N days → archive). `EvalResult`/`Correction`/`EvalCase` are low-volume, high-value → retain ≥ 6 yr, append-only (AI Act Art. 12).
- **PII:** sensitive payloads encrypted in the artifact store; summaries redacted; erasure via tombstones preserving the audit row.
- **Idempotency:** out-of-order spans tolerated (sequence + parent id rebuild the tree); upsert on `(runtime, externalRunId)`.

## Phases

1. Entities + migrations + Zod (`AgentRun`/`Span`/`ToolCall`).
2. `TraceIngestionService` + `/ingest` + `storage-s3` offloading + idempotency.
3. Read API for the trace inspector + list (`SPEC-COCKPIT-01`).
4. `EvalAssertion`/`EvalResult` + deterministic `EvalRuntimeService`.
5. `AgentCorrection` (append-only) + `CorrectionService` + disposition hook (`SPEC-AGENTINT-01`).
6. `EvalCase` auto-draft + `EvalCaseExporter` (`x_om`).
7. `llm_judge` async tier (Inspect bridge) + sampling.
8. Trust metrics rollups + anti-rubber-stamp signals + retention/partitioning.

**Critical path for the flywheel:** 1 → 2 → 5 → 6 (ingestion + corrections + export is the minimum that makes the loop spin).

## Acceptance

- Every production run is queryable within ≤ 5s (p95) with spans, tool I/O, context routing, and eval results.
- Every human override writes an `AgentCorrection` with non-empty reason and auto-drafts an `EvalCase`.
- Approved eval cases export in `x_om` format and run through `eval-runner`.
- Per-agent override rate and eval pass rate are computable over any window.
- `Correction`/`EvalResult`/`EvalCase` are append-only and retained ≥ 6 years.
