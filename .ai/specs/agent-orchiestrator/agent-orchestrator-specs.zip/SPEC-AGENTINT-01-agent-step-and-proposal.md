# SPEC-AGENTINT-01: Agent Step & Proposal/Disposition Convention

> **Status:** Draft · **Owner:** Patryk Lewczuk (Comerito) · **Updated:** 2026-06-16
> **Module:** `@open-mercato/agent-orchestrator` · **subdomain:** `orchestration` · **Depends:** `workflows`, `business_rules`, `SPEC-DISPATCH-01`, `SPEC-TRACE-01`, `SPEC-CONTEXT-01`, `SPEC-GUARD-01`

## TLDR

The keystone that wires agents into OM's workflow engine. Adds an `INVOKE_AGENT` workflow activity, a typed **Proposal** that an agent produces, and the convention by which `business_rules` **disposes** of that proposal (auto-approve or raise a `USER_TASK`). This is the concrete implementation of "LLM proposes, OM disposes."

## Problem statement

`workflows` controls flow and `business_rules` gates transitions, but neither knows how to call an agent, represent its output as a reviewable proposal, or route that proposal to auto-approval vs. a human. Without this glue, agents can't participate in orchestrated processes.

## What OM already provides (reuse)

- `workflows` custom async activity + step-handler extension points (`workflows/extending`), `WAIT_FOR_SIGNAL` pause/resume, context store.
- `business_rules` GUARD (`pre_transition`) + VALIDATION (trigger approval) rule types.
- `ai_assistant` mutation-policy + approval cards + tool allowlists (internal-agent authz baseline).
- `auth`/ACL features, `api_keys` (external auth), optimistic locking.

## UMES extension points used

- Register `INVOKE_AGENT` in the workflow activity registry; register an `agent-proposal` step handler.
- `business_rules` rule pack for proposal disposition (entityType `workflow:*:proposal`).
- ACL features: `agent.invoke`, `agent.proposal.dispose`.

## Data models

```typescript
// Proposal: an agent's reviewable output (shared with SPEC-TRACE-01)
@Entity() class Proposal {
  id; organizationId; processId; stepId;
  agentRunId;                       // FK → agent-trace.AgentRun
  capability;                       // which agent capability produced it
  @Json() payload;                  // the proposed action/decision (typed per capability)
  confidence;                       // 0..1
  @Enum() disposition;              // pending | auto_approved | approved | edited | rejected
  dispositionBy;                    // userId | 'rule:<id>' | null
  dispositionReason;                // required on edit/reject (→ Correction, SPEC-TRACE-01)
  @Json() guardResults;             // from SPEC-GUARD-01
  createdAt; updatedAt;
}
```
Proposal payload schemas are per-capability Zod contracts in `contracts/proposals/`.

## Flow

1. Workflow reaches an `INVOKE_AGENT` step. Activity assembles context (`SPEC-CONTEXT-01`), creates an `AgentTask` (`SPEC-DISPATCH-01`), returns `QUEUED`; workflow parks.
2. Agent runs (internal/pull/A2A). Output passes `SPEC-GUARD-01` guardrails. Result captured as `AgentRun` + `Proposal` (`SPEC-TRACE-01`).
3. A signal resumes the workflow with `proposal` in context.
4. **Disposition:** a `business_rules` rule pack evaluates the proposal:
   - VALIDATION: e.g. `confidence ≥ 0.8 AND fraud < 0.4 AND payout ≤ 10000` → `auto_approved`, transition proceeds.
   - else → raise a `USER_TASK` (the Decide/Answer/Do/Know verb), workflow parks until a human disposes.
5. On human disposition: `approved` → proceed; `edited`/`rejected` → write a `Correction` (`SPEC-TRACE-01`) and route per the rule (retry agent, escalate, alternate branch).
6. Approved side effects execute via standard `workflows` activities (CALL_API/UPDATE_ENTITY/webhooks/payment gateways) — the effector layer, unchanged.

## Agent authorization (§authz)

Each agent capability maps to an ACL feature set; the `INVOKE_AGENT` activity runs under a scoped, on-behalf-of principal. An agent may only *propose* actions within its grant; **execution** of a disposed proposal runs under OM's own authority after the gate — agents never hold execute rights directly. External agents authenticate via `api_keys`/A2A and are capability-scoped (`SPEC-DISPATCH-01 §9`).

## Arbitration (§arbitration)

When two agents produce conflicting proposals for the same step (e.g. two damage estimates), a `business_rules` arbitration rule selects (highest confidence / policy precedence) or raises a `USER_TASK`. Recorded as a disposition event.

## API contracts

- `INVOKE_AGENT` activity config: `{ capability, contextRef, async: true, guardrailSet, timeoutMs }`.
- Resume signal: `agent.proposal.ready` `{ processId, stepId, proposalId }`.
- `POST /api/agent-orchestration/proposals/:id/dispose` `{ disposition, payload?, reason? }` (used by the cockpit; also callable by rules).

## Phases

1. `INVOKE_AGENT` activity + `Proposal` entity + park/resume signal (internal agents only).
2. Disposition rule pack + `USER_TASK` raise/resume + Correction write.
3. Agent authz (on-behalf-of principal, capability→ACL).
4. Arbitration rule + multi-proposal handling.

## Acceptance

- A workflow with an `INVOKE_AGENT` step runs an internal agent, produces a `Proposal`, and a VALIDATION rule auto-approves it under threshold; over threshold it raises a `USER_TASK` that, when completed, resumes the workflow.
- An `edited`/`rejected` disposition writes a `Correction`.
- An agent cannot execute a side effect directly; only a disposed proposal triggers the effector activity.
