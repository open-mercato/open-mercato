---
title: Add auto-qa-scenarios and auto-sec-report skills
status: complete
---

# Execution Plan — `om-auto-qa-scenarios` and `om-auto-sec-report` skills

## Goal

Add two autonomous reporting skills to `.ai/skills/` that take a PR range
(date, PR number floor, or default "last 7 days") and deliver a human-readable
report as a docs-only PR against `develop`. Both skills reuse the
`om-auto-create-pr` workflow for branch/worktree/commit/PR discipline and leave
resumable progress via `om-auto-continue-pr` when the run cannot finish in one
pass.

## Scope

- `.ai/skills/om-auto-qa-scenarios/SKILL.md` — QA-tester-facing report that
  groups merged PRs by practical testing routes (P0/P1/P2), tells QA where
  to click, what to verify, and what can go wrong.
- `.ai/skills/om-auto-sec-report/SKILL.md` — Security-engineer-facing report
  that maps each merged PR against OWASP Top 10 categories, calls out
  security-fix PRs, and proposes where the same fix should also be applied.
- Both reports land under `.ai/analysis/` with a dated filename and both a
  markdown and an HTML rendering.
- Update `.ai/skills/README.md` to list the two new skills.

## Non-goals

- Do not change the existing `om-auto-create-pr` / `om-auto-continue-pr` /
  `om-auto-review-pr` skills. The new skills reuse them by reference.
- Do not run any real analysis in this PR. This PR only adds the skill
  definitions; actual analysis runs will be triggered later by the user.
- Do not touch packages, apps, or generated files.

## External References

None. The reference report format at
<https://github.com/open-mercato/open-mercato/pull/1527/files> was consulted
for structure (Executive Summary → Recommended Order → Grouped Areas →
Appendix). We adopt the section shape and reject the exact filename
convention so we can use `.ai/analysis/` with a dated `auto-qa-scenarios-*`
/ `auto-sec-report-*` slug.

## Implementation Plan

### Phase 1 — Skill authoring

- Draft `auto-qa-scenarios/SKILL.md` covering argument parsing (date / PR
  floor / default last week), data gathering with `gh`, grouping heuristics,
  the exact markdown report sections, the HTML rendering rule, the
  `om-auto-create-pr` handoff, and the `om-auto-continue-pr` resume contract.
- Draft `auto-sec-report/SKILL.md` with the same shape but focused on OWASP
  Top 10 2021 categories, PR-level security-fix detection, and
  cross-codebase "apply the same fix elsewhere" audit prompts.

### Phase 2 — Wiring

- Add both skills to `.ai/skills/README.md`'s "Available Skills" table with
  one-line descriptions matching the SKILL.md frontmatter.

### Phase 3 — PR delivery

- Commit the plan first, then the skill files.
- Push `feat/auto-qa-and-sec-report-skills` and open a PR against `develop`.
- Do not merge. Apply the `review`, `documentation`, and `skip-qa` labels
  (docs-only change; no customer-facing behavior).

## Risks

- Skill descriptions must be precise enough that agents auto-select them
  without accidentally firing on unrelated PR-reporting requests. Mitigation:
  keep the trigger words narrow ("QA scenarios", "QA report for PRs",
  "security audit", "OWASP", "om-auto-sec-report").
- Reports can run long. SKILL.md must cap the per-PR narrative and push raw
  inventory to an appendix so the artifact stays usable.

## Progress

> Convention: `- [ ]` pending, `- [x]` done. Append ` — <commit sha>` when a
> step lands. Do not rename step titles.

### Phase 1: Skill authoring

- [x] 1.1 Write `auto-qa-scenarios/SKILL.md` — d140deec3
- [x] 1.2 Write `auto-sec-report/SKILL.md` — d140deec3

### Phase 2: Wiring

- [x] 2.1 Register both skills in `.ai/skills/README.md` — d140deec3

### Phase 3: PR delivery

- [x] 3.1 Push branch and open PR against `develop` (do not merge) — PR #1542

### Phase 4: Revision — split sec-report into single-unit + driver

- [x] 4.1 Add `om-auto-sec-report-pr` single-unit skill covering PR / spec / branch inputs with paranoid deep vectors and "Next steps — go deeper"
- [x] 4.2 Add `references/deep-attack-vectors.md` paranoid checklist bundled with `om-auto-sec-report-pr`
- [x] 4.3 Refactor `om-auto-sec-report` to loop `om-auto-sec-report-pr` in sub-unit mode and aggregate per-unit fragments
- [x] 4.4 Update README.md skills index: new row for `om-auto-sec-report-pr`, updated row for driver `om-auto-sec-report`, folder added to structure tree

### Phase 5: CI stabilization

- [x] Post-review fix: restore `YARN_ENABLE_IMMUTABLE_INSTALLS=0` and add `YARN_ENABLE_HARDENED_MODE=0` to the scaffolded standalone-app install steps — resolves YN0028 (lockfile would be modified) triggered by Yarn 4.12 auto-enabling hardened mode on public PR workflows — 2f113173e
