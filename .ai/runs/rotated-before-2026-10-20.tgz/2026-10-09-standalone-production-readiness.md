# Standalone production-readiness guidance

Source doc: `.ai/specs/2026-07-24-standalone-ai-development-harness.md`
Issue: #6956

## Goal

Publish one provider-neutral, TLS-first production-readiness checklist and make fresh standalone agents route go-live reviews to the same safe guidance, with failure-first harness coverage.

## Scope

- Add the canonical deployment documentation page and link provider-specific runbooks to it.
- Add a compact standalone root route plus one emitted deployment guide, preserving the standalone instruction budget and both generator paths.
- Add the next contiguous read-only harness case with fail-before/pass-after evidence and synchronize every governed count/spec surface.
- Complete the knowledge-change manifest, focused create-app checks, fresh-scaffold validation, and required harness release proof.

## Non-goals

- No live deployment, infrastructure provisioning, credential access, or environment-value inspection.
- No runtime security-default, CLI, database, API, or required-environment-variable contract changes.
- No provider-specific defaults moved into the shared checklist.

## Implementation Plan

### Phase 1: Failure-first harness contract

1. Add the next contiguous read-only production-readiness routing case and a focused test that fails against the unchanged knowledge owner, recording only sanitized evidence.
2. Synchronize the case schema, validator counts, related-case links, and catalog documentation required for the added case.

### Phase 2: Canonical documentation and emitted guidance

1. Add the TLS-first provider-neutral production-readiness page, register it in the Deployment sidebar, and replace duplicated shared advice in VPS/Railway pages with canonical links.
2. Add `.ai/guides/production-deployment.md` to the standalone agentic source and route deployment/go-live requests from both standalone root instruction sources without reading live `.env` values.
3. Extend copy, ownership, and instruction-budget tests so both generator paths emit the same guide and root rule.

### Phase 3: Harness synchronization and knowledge proof

1. Update the governing harness spec and every count/release surface, then prove the new case passes after the owner change.
2. Generate and validate the knowledge-change manifest from the pre-change base, including the affected certified lane and fresh packed standalone scaffold checks.

### Phase 4: Final validation and review

1. Run documentation tests, focused create-app tests, agent budget checks, deterministic harness validation, the required contained release lane, and the configured validation gate; resolve failures without weakening checks.
2. Run code review/autofix, verify issue/PR linkage and labels, and publish sanitized evidence plus collision notes for concurrently open harness-catalog PRs.

## Risks

- Open PRs #6892 and #6688 also claim the current next harness ID. Use the next contiguous ID on the actual base and rebase/renumber if either lands before this PR.
- The knowledge-contract gate intentionally fails closed if fail-before evidence, source ownership, count surfaces, fresh-scaffold proof, or the release lane is incomplete.
- The full harness release lane may be unavailable because of runner capacity or containment prerequisites; report an environment blocker rather than weakening the gate.

## Evidence

- Failure-first focused test (local runner): `node --import tsx --test packages/create-app/src/lib/agent-production-deployment-guidance.test.ts` failed 1/2 before the owner change with the semantic assertion `missing routed production deployment guide`; the OMH-238 catalog contract itself passed.
- Post-change local focused gate: production routing/safety, shared emission/ownership, and instruction-budget tests passed 13/13; CLI agentic ownership passed 18/18.
- Documentation gate after merging and tightening the canonical page: `yarn workspace open-mercato-docs test` built the Docusaurus site and passed 23/23 tests.
- The generated knowledge-change manifest passed its controller-owned base/head contract, including the required `routing` lane and OMH-238.
- A freshly packed standalone scaffold passed OMH-238 deterministically and with a live Claude runner (1/1 in each lane).
- After recalibrating the six stale installed-skill byte ceilings from their measured pinned footprints, the complete deterministic catalog passed 238/238 cases. The release foundation also passed all four configured controller validations (`generate`, `typecheck`, `lint`, and `build`).
- A full contained Claude release attempt ran for 9h29m and produced sanitized aggregate report `2026-10-09T19-09-18-235Z-release-suite.json` (SHA-256 `6dcb2d7fa111938b116748b14ca5f7ab4675c0bb81617d87c1b7cbe4f243a2bd`, mode `0600`). It completed 95/238 primary routing cases before the provider OAuth session expired and could not refresh; 4/95 completed live routing cases passed and 91 exposed pre-existing context-contract mismatches. Every subsequent writable agent invocation stopped immediately with the same provider-environment failure, so no writable result or judge artifact was claimed. This is an external live-evaluator blocker, not passing release evidence; OMH-238's focused deterministic and live Claude lanes remain green.
- Repository gates used the local runner: package builds, generation, i18n sync/usage checks, typechecking, the application build, isolated CLI tests (2,001/2,001), and the create-app suite passed. After merging the latest `develop`, the create-app suite still passes 897/897 with 4 skipped, documentation passes 23/23, the agent-instruction budget ratchet passes, and the upstream-corrected progress suite passes 102/102 in isolation.

## Progress

> Convention: `- [ ]` pending, `- [x]` done. Append ` — <commit sha>` when a step lands. Do not rename step titles.

### Phase 1: Failure-first harness contract

- [x] 1.1 Add the production-readiness case and focused fail-before test — f7930ddca
- [x] 1.2 Synchronize case schema, validators, relations, and catalog docs — c77da7c06

### Phase 2: Canonical documentation and emitted guidance

- [x] 2.1 Add canonical docs and provider-runbook links — 594e100b2
- [x] 2.2 Add the emitted deployment guide and root routing rule — fd7e12d1f
- [x] 2.3 Extend generator, ownership, and budget coverage — fd7e12d1f

### Phase 3: Harness synchronization and knowledge proof

- [x] 3.1 Synchronize the governing spec/count surfaces and pass the new case — c77da7c06, fd7e12d1f, 35fde9759, b08b5f235
- [x] 3.2 Generate and validate the knowledge-change manifest and certified lane — b08b5f235

### Phase 4: Final validation and review

- [x] 4.1 Run the required documentation, create-app, harness, release, and repository gates — 5b2b3e461
- [x] 4.2 Complete review/autofix and publish sanitized evidence — 2e5cf2ea8

### Phase 5: October 21 PR follow-up

- [x] 5.1 Merge current develop, preserve upstream harness cases, and reconcile production coverage as OMH-240 — 71c9fa4b8
- [x] 5.2 Document the readiness scanner in the canonical production checklist — 10290f032
- [x] 5.3 Validate the merged documentation and harness surfaces, review, and publish the existing PR — 333f55024

## October 21 follow-up evidence

- Merged `origin/develop` at `e9bdaac5f` as `71c9fa4b8`, preserving upstream OMH-238 (Customers calendar) and OMH-239 (module tooling) and moving production readiness to OMH-240. Existing historical evidence above refers to the original OMH-238 identity and the then-current 238-case catalog.
- Added the scanner repository link to the canonical production-readiness page in `10290f032`, accurately distinguishing read-only local review from deployed-environment checks. No scanner package installation is suggested.
- Runner: local. Immutable dependency installation completed with warnings (optional `better-sqlite3` native build failed); focused production/catalog/schema/count checks pass 15/15, source-link inventory regeneration/check passes, and agent-instruction budgets pass.
- Package build, generation, second package build, i18n synchronization/usage, and typechecking pass. Final documentation build/tests pass 23/23. The create-app suite passes 911/911 with 4 skipped. The final focused production/catalog/schema/count/context-budget checks pass 16/16. The full repository test gate passes all 48 tasks with temporary-directory variables outside the checkout, and the production application build passes. The isolated environment-resolution test also passes 10/10.
- Published the prepared updates to PR #7125 without rewriting history. GitHub reports the head mergeable; published-head CI remains a separate merge gate.
- Independent scoped code review approved the merged changes and scanner wording with no findings. Follow-up `10aee0de2` preserves the tighter upstream compatibility budgets, adjusting only OMH-057 by one 4-KiB increment for the added root-routing text; its exact-context budget regression passes.

Final local verification for the follow-up:

| Configured command | Result |
| --- | --- |
| `yarn build:packages` | Pass |
| `yarn generate` | Pass |
| `yarn build:packages` (after generation) | Pass |
| `yarn i18n:check-sync` | Pass |
| `yarn i18n:check-usage` | Pass |
| `yarn typecheck` | Pass |
| `yarn test` | Pass: 48/48 tasks |
| `yarn build:app` | Pass |

Template parity, source-link inventory parity, instruction budgets, docs 23/23, focused contracts 16/16, and create-app 911 passed / 4 skipped also pass. The original live-release limitation above is unchanged; this follow-up does not claim a fresh live harness release. Phase 5.3 is complete. [Final published-head review evidence](https://github.com/open-mercato/open-mercato/pull/7125#pullrequestreview-5599205936) records the clean code verdict, all configured gate results, and the distinction between local verification and pending CI. The review is a GitHub COMMENT because the authenticated user is also the PR author; no formal self-approval is claimed.
