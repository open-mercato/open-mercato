import { Page, PageBody } from '@open-mercato/ui/backend/Page'
import BooksTable from '@/modules/library/components/BooksTable'

export default function LibraryBooksPage() {
  return (
    <Page>
      <PageBody>
        <BooksTable />
      </PageBody>
    </Page>
  )
}
