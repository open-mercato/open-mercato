export const metadata = {
  requireAuth: true,
  requireFeatures: ['library.view'],
  pageTitle: 'Books',
  pageTitleKey: 'library.books.page.title',
  pageGroup: 'Library',
  pageGroupKey: 'library.nav.group',
  pageOrder: 200,
  icon: 'book-open',
  breadcrumb: [
    { label: 'Books', labelKey: 'library.books.page.title' },
  ],
}
