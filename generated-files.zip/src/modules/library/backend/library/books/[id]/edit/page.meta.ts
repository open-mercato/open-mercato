export const metadata = {
  requireAuth: true,
  requireFeatures: ['library.books.manage'],
  pageTitle: 'Edit book',
  pageTitleKey: 'library.books.edit.title',
  pageGroup: 'Library',
  pageGroupKey: 'library.nav.group',
  breadcrumb: [
    { label: 'Books', labelKey: 'library.books.page.title', href: '/backend/library/books' },
    { label: 'Edit', labelKey: 'library.books.edit.title' },
  ],
}
