import { Page, PageBody } from '@open-mercato/ui/backend/Page'
import { BookEditForm } from '@/modules/library/components/BookForm'

export default function EditBookPage({ params }: { params?: { id?: string } }) {
  const id = params?.id
  if (!id) return null

  return (
    <Page>
      <PageBody>
        <BookEditForm id={id} />
      </PageBody>
    </Page>
  )
}
