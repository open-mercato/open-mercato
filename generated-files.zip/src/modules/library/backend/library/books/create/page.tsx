import { Page, PageBody } from '@open-mercato/ui/backend/Page'
import { BookCreateForm } from '@/modules/library/components/BookForm'

export default function CreateBookPage() {
  return (
    <Page>
      <PageBody>
        <BookCreateForm />
      </PageBody>
    </Page>
  )
}
