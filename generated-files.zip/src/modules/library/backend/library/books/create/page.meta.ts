export const metadata = {
  requireAuth: true,
  requireFeatures: ['library.books.manage'],
  pageTitle: 'Add book',
  pageTitleKey: 'library.books.create.title',
  pageGroup: 'Library',
  pageGroupKey: 'library.nav.group',
  pageOrder: 201,
  icon: 'plus',
  breadcrumb: [
    { label: 'Books', labelKey: 'library.books.page.title', href: '/backend/library/books' },
    { label: 'Add book', labelKey: 'library.books.create.title' },
  ],
}
