export const features = [
  { id: 'library.backend', title: 'Access library backend', module: 'library' },
  { id: 'library.view', title: 'View library books and loans', module: 'library' },
  {
    id: 'library.books.manage',
    title: 'Manage library books',
    module: 'library',
    dependsOn: ['library.view'],
  },
  {
    id: 'library.loans.manage',
    title: 'Manage library loans',
    module: 'library',
    dependsOn: ['library.view'],
  },
]

export default features
