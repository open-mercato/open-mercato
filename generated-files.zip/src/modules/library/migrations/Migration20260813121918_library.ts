import { Migration } from '@mikro-orm/migrations';

export class Migration20260813121918_library extends Migration {

  override name = 'Migration20260813121918';

  override up(): void | Promise<void> {
    this.addSql(`create table "library_books" ("id" uuid not null default gen_random_uuid(), "tenant_id" uuid not null, "organization_id" uuid not null, "title" text not null, "author" text not null, "isbn" text null, "publisher" text null, "published_year" int null, "description" text null, "total_copies" int not null default 1, "created_at" timestamptz not null, "updated_at" timestamptz not null, primary key ("id"));`);
    this.addSql(`alter table "library_books" add constraint "library_books_organization_id_isbn_unique" unique ("organization_id", "isbn");`);
  }

}
