import {
  crudFormExtensionHost,
  dataTableExtensionHost,
  defineModuleExtensionPoints,
} from '@open-mercato/shared/modules/widgets/extension-points'

/**
 * Extension hosts the library module exposes so later UMES extensions (custom
 * fields, injection widgets, column additions) work without changes. Each host
 * is consumed by its declared source file via `extensionPoints.hosts.<key>`.
 */
export const extensionPoints = defineModuleExtensionPoints({
  moduleId: 'library',
  hosts: {
    booksTable: dataTableExtensionHost({
      tableId: 'library.books.list',
      source: 'components/BooksTable.tsx',
    }),
    bookForm: crudFormExtensionHost({
      entityId: 'library:book',
      spotId: 'crud-form:library.book',
      source: 'components/BookForm.tsx',
    }),
  },
})

export default extensionPoints
