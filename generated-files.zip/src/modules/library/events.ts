import { createModuleEvents } from '@open-mercato/shared/modules/events'

/**
 * Library module events.
 *
 * Book lifecycle events are emitted post-commit by the book commands. Loan
 * events (`library.loan.checked_out` / `library.loan.returned`) are declared up
 * front so the registry is stable; their producers land in Phase 2.
 * `clientBroadcast` enables real-time UI refresh via the DOM Event Bridge.
 */
const events = [
  { id: 'library.book.created', label: 'Book Created', entity: 'book', category: 'crud', clientBroadcast: true },
  { id: 'library.book.updated', label: 'Book Updated', entity: 'book', category: 'crud', clientBroadcast: true },
  { id: 'library.book.deleted', label: 'Book Deleted', entity: 'book', category: 'crud', clientBroadcast: true },
  { id: 'library.loan.checked_out', label: 'Loan Checked Out', entity: 'loan', category: 'lifecycle', clientBroadcast: true },
  { id: 'library.loan.returned', label: 'Loan Returned', entity: 'loan', category: 'lifecycle', clientBroadcast: true },
] as const

export const eventsConfig = createModuleEvents({
  moduleId: 'library',
  events,
})

export const emitLibraryEvent = eventsConfig.emit

export type LibraryEventId = (typeof events)[number]['id']

export default eventsConfig
