import { Entity, Index, PrimaryKey, Property, Unique } from '@mikro-orm/decorators/legacy';

/**
 * A lendable title in the library catalog.
 *
 * Copies are modelled as an integer `total_copies` count rather than individual
 * `BookCopy` rows: v1 has no per-copy barcode workflow, and availability is a
 * transactional invariant computed against active `library_loans` (Phase 2).
 *
 * Scope (`tenant_id` / `organization_id`) is derived from the authenticated
 * session on every read and write — never from request payloads. The composite
 * unique index on `(organization_id, isbn)` enforces ISBN uniqueness per
 * organization where an ISBN is present; PostgreSQL treats multiple `NULL`
 * ISBNs as distinct, so a blank ISBN never collides.
 *
 * Books are hard-deleted (no `deleted_at`): the delete command blocks any book
 * that still has loan history (added in Phase 2), so a deletable book carries no
 * historical references and nothing is lost by removing the row.
 */
@Entity({ tableName: 'library_books' })
@Unique({ properties: ['organizationId', 'isbn'] })
export class Book {
  @PrimaryKey({ type: 'uuid', defaultRaw: 'gen_random_uuid()' })
  id!: string

  @Property({ name: 'tenant_id', type: 'uuid' })
  tenantId!: string

  @Property({ name: 'organization_id', type: 'uuid' })
  organizationId!: string

  @Property({ type: 'text' })
  title!: string

  @Property({ type: 'text' })
  author!: string

  @Property({ type: 'text', nullable: true })
  isbn?: string | null

  @Property({ type: 'text', nullable: true })
  publisher?: string | null

  @Property({ name: 'published_year', type: 'integer', nullable: true })
  publishedYear?: number | null

  @Property({ type: 'text', nullable: true })
  description?: string | null

  @Property({ name: 'total_copies', type: 'integer', default: 1 })
  totalCopies: number = 1

  @Property({ name: 'created_at', type: Date, onCreate: () => new Date() })
  createdAt: Date = new Date()

  @Property({ name: 'updated_at', type: Date, onCreate: () => new Date(), onUpdate: () => new Date() })
  updatedAt: Date = new Date()
}

/**
 * A single checkout event: one copy of a {@link Book} lent to one borrower.
 *
 * The borrower is an existing customer record referenced by ID only — no
 * cross-module ORM relation. `borrower_display_name` / `borrower_email` are a
 * point-in-time snapshot captured at checkout and never synced back, so a
 * customer edit or delete leaves the loan readable as a historical record.
 *
 * `returned_at` is `null` while the copy is out and is stamped exactly once by
 * the return command. Loan status (active / overdue / returned) is derived at
 * read time from `due_at`, `returned_at`, and the clock — there is no stored
 * status column to drift. A loan is never edited or deleted; an accidental
 * checkout is corrected by returning it with a staff note.
 */
@Entity({ tableName: 'library_loans' })
@Index({ properties: ['bookId'] })
@Index({ properties: ['borrowerCustomerId'] })
@Index({ properties: ['organizationId', 'returnedAt'] })
export class Loan {
  @PrimaryKey({ type: 'uuid', defaultRaw: 'gen_random_uuid()' })
  id!: string

  @Property({ name: 'tenant_id', type: 'uuid' })
  tenantId!: string

  @Property({ name: 'organization_id', type: 'uuid' })
  organizationId!: string

  @Property({ name: 'book_id', type: 'uuid' })
  bookId!: string

  @Property({ name: 'borrower_customer_id', type: 'uuid' })
  borrowerCustomerId!: string

  @Property({ name: 'borrower_display_name', type: 'text' })
  borrowerDisplayName!: string

  @Property({ name: 'borrower_email', type: 'text', nullable: true })
  borrowerEmail?: string | null

  @Property({ name: 'loaned_at', type: Date })
  loanedAt!: Date

  @Property({ name: 'due_at', type: Date })
  dueAt!: Date

  @Property({ name: 'returned_at', type: Date, nullable: true })
  returnedAt?: Date | null

  @Property({ type: 'text', nullable: true })
  notes?: string | null

  @Property({ name: 'created_at', type: Date, onCreate: () => new Date() })
  createdAt: Date = new Date()

  @Property({ name: 'updated_at', type: Date, onCreate: () => new Date(), onUpdate: () => new Date() })
  updatedAt: Date = new Date()
}
