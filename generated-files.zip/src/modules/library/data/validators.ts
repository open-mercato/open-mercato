import { z } from 'zod'

const MAX_YEAR = new Date().getFullYear() + 1

/**
 * Normalizes an ISBN by stripping hyphens and spaces. A blank result becomes
 * `null` so it never participates in the per-organization unique index. Storage
 * and the uniqueness check both run through this so a hyphenated entry and a
 * bare entry cannot diverge.
 */
export function normalizeIsbn(value: string | null | undefined): string | null {
  if (!value) return null
  const trimmed = value.trim()
  if (!trimmed) return null
  return trimmed.replace(/[-\s]/g, '')
}

/**
 * ISBN-10 / ISBN-13 shape, optional. Hyphens and spaces are accepted; ISBN-10
 * may end with a check digit of `X`. Validation runs against the normalized
 * form. A blank value is stored as `null`.
 */
export const isbnSchema = z
  .string()
  .trim()
  .max(20)
  .optional()
  .refine((value) => {
    if (!value) return true
    const normalized = value.replace(/[-\s]/g, '')
    return /^\d{13}$/.test(normalized) || /^\d{9}[\dX]$/.test(normalized)
  }, 'ISBN must be a valid ISBN-10 or ISBN-13')

export const bookCreateSchema = z.object({
  id: z.string().uuid().optional(),
  title: z.string().trim().min(1).max(300),
  author: z.string().trim().min(1).max(300),
  isbn: isbnSchema,
  publisher: z.string().trim().max(300).optional(),
  publishedYear: z.number().int().min(0).max(MAX_YEAR).optional(),
  description: z.string().max(10000).optional(),
  totalCopies: z.number().int().min(0).max(1_000_000).default(1),
})

export const bookUpdateSchema = z.object({
  id: z.string().uuid(),
  title: z.string().trim().min(1).max(300).optional(),
  author: z.string().trim().min(1).max(300).optional(),
  isbn: isbnSchema,
  publisher: z.string().trim().max(300).optional(),
  publishedYear: z.number().int().min(0).max(MAX_YEAR).optional(),
  description: z.string().max(10000).optional(),
  totalCopies: z.number().int().min(0).max(1_000_000).optional(),
  /** Optional expected `updated_at` for command-level optimistic locking. */
  expected_updated_at: z.string().min(1).optional(),
})

export const bookListQuerySchema = z
  .object({
    id: z.string().uuid().optional(),
    ids: z.string().optional(),
    search: z.string().optional(),
    isbn: z.string().optional(),
    page: z.coerce.number().min(1).default(1),
    pageSize: z.coerce.number().min(1).max(100).default(50),
    sortField: z.string().optional().default('title'),
    sortDir: z.enum(['asc', 'desc']).optional().default('asc'),
  })
  .passthrough()

export const loanCheckoutSchema = z.object({
  bookId: z.string().uuid(),
  customerId: z.string().uuid(),
  dueAt: z
    .string()
    .min(1)
    .refine((value) => !Number.isNaN(new Date(value).getTime()), 'dueAt must be a valid ISO date'),
  notes: z.string().max(10000).optional(),
})

export const loanReturnSchema = z.object({
  id: z.string().uuid(),
  notes: z.string().max(10000).optional(),
  expected_updated_at: z.string().min(1).optional(),
})

export const loanStatusSchema = z.enum(['all', 'active', 'overdue', 'returned'])

export const loanListQuerySchema = z
  .object({
    id: z.string().uuid().optional(),
    bookId: z.string().uuid().optional(),
    borrowerCustomerId: z.string().uuid().optional(),
    status: loanStatusSchema.optional().default('all'),
    search: z.string().optional(),
    page: z.coerce.number().min(1).default(1),
    pageSize: z.coerce.number().min(1).max(100).default(50),
    sortField: z.string().optional().default('loaned_at'),
    sortDir: z.enum(['asc', 'desc']).optional().default('desc'),
  })
  .passthrough()

export type BookCreateInput = z.infer<typeof bookCreateSchema>
export type BookUpdateInput = z.infer<typeof bookUpdateSchema>
export type BookListQuery = z.infer<typeof bookListQuerySchema>
export type LoanCheckoutInput = z.infer<typeof loanCheckoutSchema>
export type LoanReturnInput = z.infer<typeof loanReturnSchema>
export type LoanListQuery = z.infer<typeof loanListQuerySchema>
export type LoanStatus = z.infer<typeof loanStatusSchema>
