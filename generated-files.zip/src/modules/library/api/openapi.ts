import { z, type ZodTypeAny } from 'zod'
import type { OpenApiRouteDoc } from '@open-mercato/shared/lib/openapi'
import {
  createCrudOpenApiFactory,
  createPagedListResponseSchema as createSharedPagedListResponseSchema,
  type CrudOpenApiOptions,
} from '@open-mercato/shared/lib/openapi/crud'

export const libraryTag = 'Library'

export const libraryErrorSchema = z.object({
  error: z.string(),
}).passthrough()

export const libraryOkSchema = z.object({
  ok: z.literal(true),
})

export const libraryCreatedSchema = z.object({
  id: z.string().uuid(),
})

export const bookOptionSchema = z.object({
  value: z.string().uuid(),
  label: z.string(),
  availableCopies: z.number().int(),
})

export const bookOptionsResponseSchema = z.object({
  items: z.array(bookOptionSchema),
})

export const bookListItemSchema = z
  .object({
    id: z.string(),
    title: z.string(),
    author: z.string(),
    isbn: z.string().nullable(),
    publisher: z.string().nullable(),
    publishedYear: z.number().int().nullable(),
    description: z.string().nullable(),
    totalCopies: z.number().int(),
    availableCopies: z.number().int(),
    tenantId: z.string().nullable(),
    organizationId: z.string().nullable(),
    updatedAt: z.string().nullable(),
  })
  .passthrough()

export function createLibraryPagedListResponseSchema(itemSchema: ZodTypeAny) {
  return createSharedPagedListResponseSchema(itemSchema, { paginationMetaOptional: true })
}

const buildLibraryCrudOpenApi = createCrudOpenApiFactory({
  defaultTag: libraryTag,
  defaultCreateResponseSchema: libraryCreatedSchema,
  defaultOkResponseSchema: libraryOkSchema,
  makeListDescription: ({ pluralLower }) =>
    `Returns a paginated collection of ${pluralLower} in the current organization scope.`,
})

export function createLibraryCrudOpenApi(options: CrudOpenApiOptions): OpenApiRouteDoc {
  return buildLibraryCrudOpenApi(options)
}
