import { NextResponse } from 'next/server'
import { z } from 'zod'
import { getAuthFromRequest } from '@open-mercato/shared/lib/auth/server'
import { createRequestContainer } from '@open-mercato/shared/lib/di/container'
import type { CommandBus } from '@open-mercato/shared/lib/commands'
import { readJsonSafe } from '@open-mercato/shared/lib/http/readJsonSafe'
import { isCrudHttpError } from '@open-mercato/shared/lib/crud/errors'
import type { OpenApiRouteDoc } from '@open-mercato/shared/lib/openapi'
import { libraryOkSchema } from '../../../openapi'

export const metadata = {
  POST: { requireAuth: true, requireFeatures: ['library.loans.manage'] },
}

type RouteContext = {
  params: Promise<{ id: string }> | { id: string }
}

const bodySchema = z.object({
  notes: z.string().max(10000).optional(),
  expected_updated_at: z.string().min(1).optional(),
})

export async function POST(req: Request, context: RouteContext): Promise<Response> {
  const { id } = await context.params
  if (!z.string().uuid().safeParse(id).success) {
    return NextResponse.json({ error: 'Invalid loan id' }, { status: 400 })
  }

  const auth = await getAuthFromRequest(req)
  if (!auth?.sub || !auth?.tenantId) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const raw = await readJsonSafe<unknown>(req, {})
  const parsed = bodySchema.safeParse(raw)
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 })
  }

  const container = await createRequestContainer()
  const commandBus = container.resolve('commandBus') as CommandBus

  try {
    await commandBus.execute('library.loans.return', {
      input: { id, ...parsed.data },
      ctx: {
        container,
        auth: auth as never,
        organizationScope: null,
        selectedOrganizationId: (auth as { orgId?: string | null }).orgId ?? null,
        organizationIds: (auth as { orgId?: string | null }).orgId
          ? [(auth as { orgId?: string | null }).orgId as string]
          : null,
      },
    })
  } catch (error) {
    if (isCrudHttpError(error)) {
      return NextResponse.json(error.body, { status: error.status })
    }
    return NextResponse.json({ error: 'Failed to return loan' }, { status: 500 })
  }

  return NextResponse.json({ ok: true })
}

export const openApi: OpenApiRouteDoc = {
  tag: 'Library',
  summary: 'Return a loan',
  methods: {
    POST: {
      summary: 'Mark a loan returned',
      description:
        'Stamps `returned_at` on a loan. Returns 409 if the loan is already returned. Send `expected_updated_at` for optimistic locking.',
      tags: ['Library'],
      request: { schema: bodySchema },
      responses: [
        { status: 200, description: 'Loan returned.', schema: libraryOkSchema },
      ],
      errors: [
        { status: 400, description: 'Invalid request body or loan id' },
        { status: 401, description: 'Authentication required' },
        { status: 403, description: 'Forbidden' },
        { status: 404, description: 'Loan not found' },
        { status: 409, description: 'Loan already returned, or version conflict' },
      ],
    },
  },
}
