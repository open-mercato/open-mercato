import { z } from 'zod'
import type { EntityManager, FilterQuery } from '@mikro-orm/core'
import { makeCrudRoute } from '@open-mercato/shared/lib/crud/factory'
import { escapeLikePattern } from '@open-mercato/shared/lib/db/escapeLikePattern'
import type { Where, WhereValue } from '@open-mercato/shared/lib/query/types'
import type { OpenApiRouteDoc } from '@open-mercato/shared/lib/openapi'
import { Book, Loan } from '../../data/entities'
import { loanListQuerySchema, type LoanListQuery } from '../../data/validators'
import type { LoanListItem, LoanStatus } from '../../types'
import { libraryCreatedSchema, libraryOkSchema } from '../openapi'

const id = 'id'
const book_id = 'book_id'
const borrower_customer_id = 'borrower_customer_id'
const borrower_display_name = 'borrower_display_name'
const borrower_email = 'borrower_email'
const loaned_at = 'loaned_at'
const due_at = 'due_at'
const returned_at = 'returned_at'
const notes = 'notes'
const tenant_id = 'tenant_id'
const organization_id = 'organization_id'
const created_at = 'created_at'
const updated_at = 'updated_at'

const listFields = [
  id,
  book_id,
  borrower_customer_id,
  borrower_display_name,
  borrower_email,
  loaned_at,
  due_at,
  returned_at,
  notes,
  tenant_id,
  organization_id,
  created_at,
  updated_at,
]

const sortFieldMap: Record<string, string> = {
  id,
  book_id,
  borrower_display_name,
  loaned_at,
  due_at,
  returned_at,
  created_at,
  updated_at,
  updatedAt: updated_at,
  bookId: book_id,
  dueAt: due_at,
  loanedAt: loaned_at,
}

type LoanRow = {
  id: string
  book_id: string
  borrower_customer_id: string
  borrower_display_name: string
  borrower_email: string | null
  loaned_at: Date | string
  due_at: Date | string
  returned_at: Date | string | null
  notes: string | null
  tenant_id: string | null
  organization_id: string | null
  updated_at: Date | string | null
}

function toIsoTimestamp(value: unknown): string | null {
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value.toISOString()
  if (typeof value === 'string' || typeof value === 'number') {
    const parsed = new Date(value)
    return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString()
  }
  return null
}

function deriveStatus(returnedAt: string | null, dueAt: string): LoanStatus {
  if (returnedAt) return 'returned'
  return new Date(dueAt).getTime() < Date.now() ? 'overdue' : 'active'
}

const rawBodySchema = z.object({}).passthrough()

export const { metadata, GET, POST } = makeCrudRoute({
  metadata: {
    GET: { requireAuth: true, requireFeatures: ['library.view'] },
    POST: { requireAuth: true, requireFeatures: ['library.loans.manage'] },
  },
  orm: {
    entity: Loan,
    idField: 'id',
    orgField: 'organizationId',
    tenantField: 'tenantId',
  },
  list: {
    schema: loanListQuerySchema,
    entityId: 'library:loan',
    fields: listFields,
    sortFieldMap,
    buildFilters: (q: LoanListQuery): Where<LoanRow> => {
      const filters: Where<LoanRow> = {}
      const F = filters as Record<string, WhereValue>
      const now = new Date()
      if (q.id) F.id = q.id
      if (q.bookId) F.book_id = q.bookId
      if (q.borrowerCustomerId) F.borrower_customer_id = q.borrowerCustomerId
      if (q.search) {
        F.borrower_display_name = { $ilike: `%${escapeLikePattern(q.search)}%` }
      }
      if (q.status === 'active') {
        F.returned_at = null
        F.due_at = { $gte: now }
      } else if (q.status === 'overdue') {
        F.returned_at = null
        F.due_at = { $lt: now }
      } else if (q.status === 'returned') {
        F.returned_at = { $ne: null }
      }
      return filters
    },
    transformItem: (item: LoanRow): LoanListItem => {
      const returnedIso = item.returned_at ? toIsoTimestamp(item.returned_at) : null
      const dueIso = toIsoTimestamp(item.due_at) ?? new Date().toISOString()
      return {
        id: String(item.id),
        bookId: String(item.book_id),
        bookTitle: '',
        borrowerCustomerId: String(item.borrower_customer_id),
        borrowerDisplayName: String(item.borrower_display_name),
        borrowerEmail: item.borrower_email ?? null,
        loanedAt: toIsoTimestamp(item.loaned_at) ?? new Date().toISOString(),
        dueAt: dueIso,
        returnedAt: returnedIso,
        notes: item.notes ?? null,
        status: deriveStatus(returnedIso, dueIso),
        tenantId: item.tenant_id ?? null,
        organizationId: item.organization_id ?? null,
        updatedAt: toIsoTimestamp(item.updated_at),
      }
    },
  },
  hooks: {
    // Enrich each loan with its book title in a single in-module lookup. Book and
    // loan live in the same module, so this is an intra-module ID reference (the
    // book id is already on the row), never a cross-module ORM relation.
    afterList: async (res, ctx) => {
      const items = ((res as { items?: LoanListItem[] })?.items ?? []) as LoanListItem[]
      if (!items.length) return
      const em = ctx.container.resolve('em') as EntityManager
      const bookIds = [...new Set(items.map((item) => item.bookId))]
      const books = await em.find(
        Book,
        { id: { $in: bookIds } } as FilterQuery<Book>,
        { fields: ['id', 'title'] as unknown as never },
      )
      const titleById = new Map<string, string>()
      for (const book of books) titleById.set(String(book.id), String(book.title))
      for (const item of items) {
        item.bookTitle = titleById.get(item.bookId) ?? item.bookId
      }
    },
  },
  actions: {
    create: {
      commandId: 'library.loans.checkout',
      schema: rawBodySchema,
      mapInput: ({ parsed }) => parsed,
      response: ({ result }) => ({ id: String(result.id) }),
      status: 201,
    },
  },
})

const loanCheckoutDocSchema = z.object({
  bookId: z.string().uuid(),
  customerId: z.string().uuid(),
  dueAt: z.string(),
  notes: z.string().optional(),
})

export const openApi: OpenApiRouteDoc = {
  tag: 'Library',
  summary: 'Library loans',
  methods: {
    GET: {
      summary: 'List loans',
      description:
        'Returns a paginated list of loans with derived status (active / overdue / returned), scoped to the current organization.',
      tags: ['Library'],
      responses: [
        { status: 200, description: 'Paginated loans.' },
      ],
      errors: [
        { status: 401, description: 'Authentication required' },
        { status: 403, description: 'Forbidden' },
      ],
    },
    POST: {
      summary: 'Check out a book',
      description:
        'Checks an available copy out to a customer. Availability is re-checked inside the checkout transaction; the request fails with 409 when no copy is available.',
      tags: ['Library'],
      request: { schema: loanCheckoutDocSchema },
      responses: [
        { status: 201, description: 'Loan created.', schema: libraryCreatedSchema },
      ],
      errors: [
        { status: 400, description: 'Book or customer not found in scope, or bad due date' },
        { status: 403, description: 'Forbidden' },
        { status: 409, description: 'No copies available', schema: libraryOkSchema },
      ],
    },
  },
}
