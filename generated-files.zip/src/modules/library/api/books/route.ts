import { z } from 'zod'
import type { EntityManager, FilterQuery } from '@mikro-orm/core'
import { makeCrudRoute } from '@open-mercato/shared/lib/crud/factory'
import { escapeLikePattern } from '@open-mercato/shared/lib/db/escapeLikePattern'
import type { Where, WhereValue } from '@open-mercato/shared/lib/query/types'
import type { OpenApiRouteDoc } from '@open-mercato/shared/lib/openapi'
import { Book, Loan } from '../../data/entities'
import { bookListQuerySchema, type BookListQuery } from '../../data/validators'
import { bookCrudEvents, ENTITY_ID } from '../../commands/books'
import type { BookListItem } from '../../types'
import {
  bookListItemSchema as bookListItemDocSchema,
  createLibraryCrudOpenApi,
  createLibraryPagedListResponseSchema,
  libraryCreatedSchema,
  libraryOkSchema,
} from '../openapi'

const id = 'id'
const title = 'title'
const author = 'author'
const isbn = 'isbn'
const publisher = 'publisher'
const published_year = 'published_year'
const description = 'description'
const total_copies = 'total_copies'
const tenant_id = 'tenant_id'
const organization_id = 'organization_id'
const created_at = 'created_at'
const updated_at = 'updated_at'

const listFields = [
  id,
  title,
  author,
  isbn,
  publisher,
  published_year,
  description,
  total_copies,
  tenant_id,
  organization_id,
  created_at,
  updated_at,
]

const sortFieldMap: Record<string, string> = {
  id,
  title,
  author,
  isbn,
  publisher,
  published_year: published_year,
  publishedYear: published_year,
  total_copies: total_copies,
  totalCopies: total_copies,
  created_at,
  updated_at,
  updatedAt: updated_at,
}

type BookRow = {
  id: string
  title: string
  author: string
  isbn: string | null
  publisher: string | null
  published_year: number | null
  description: string | null
  total_copies: number
  tenant_id: string | null
  organization_id: string | null
  created_at: Date | string
  updated_at: Date | string | null
}

function toIsoTimestamp(value: unknown): string | null {
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value.toISOString()
  if (typeof value === 'string' || typeof value === 'number') {
    const parsed = new Date(value)
    return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString()
  }
  return null
}

const rawBodySchema = z.object({}).passthrough()

export const { metadata, GET, POST, PUT, DELETE } = makeCrudRoute({
  metadata: {
    GET: { requireAuth: true, requireFeatures: ['library.view'] },
    POST: { requireAuth: true, requireFeatures: ['library.books.manage'] },
    PUT: { requireAuth: true, requireFeatures: ['library.books.manage'] },
    DELETE: { requireAuth: true, requireFeatures: ['library.books.manage'] },
  },
  orm: {
    entity: Book,
    idField: 'id',
    orgField: 'organizationId',
    tenantField: 'tenantId',
  },
  events: { module: 'library', entity: 'book', persistent: true },
  hooks: {
    // Compute real availability in a single query rather than per row: count
    // active loans (returned_at IS NULL) for the books on this page and
    // subtract from total_copies. Runs after the list is built and transformed.
    afterList: async (res, ctx) => {
      const items = ((res as { items?: BookListItem[] })?.items ?? []) as BookListItem[]
      if (!items.length) return
      const tenantId = ctx.auth?.tenantId ?? null
      const organizationId = ctx.selectedOrganizationId ?? ctx.auth?.orgId ?? null
      if (!tenantId || !organizationId) return
      const em = ctx.container.resolve('em') as EntityManager
      const bookIds = items.map((item) => item.id)
      const activeLoans = await em.find(
        Loan,
        { bookId: { $in: bookIds }, tenantId, organizationId, returnedAt: null } as FilterQuery<Loan>,
        { fields: ['bookId'] as unknown as never },
      )
      const activeByBook = new Map<string, number>()
      for (const loan of activeLoans) {
        activeByBook.set(loan.bookId, (activeByBook.get(loan.bookId) ?? 0) + 1)
      }
      for (const item of items) {
        item.availableCopies = Math.max(0, item.totalCopies - (activeByBook.get(item.id) ?? 0))
      }
    },
  },
  list: {
    schema: bookListQuerySchema,
    entityId: ENTITY_ID,
    fields: listFields,
    sortFieldMap,
    buildFilters: (q: BookListQuery): Where<BookRow> => {
      const filters: Where<BookRow> = {}
      const F = filters as Record<string, WhereValue>
      if (q.id) F.id = q.id
      if (q.ids) {
        const ids = q.ids
          .split(',')
          .map((value) => value.trim())
          .filter((value) => value.length > 0)
        if (ids.length > 0) F.id = { $in: ids }
      }
      if (q.isbn) F.isbn = { $ilike: `%${escapeLikePattern(q.isbn)}%` }
      if (q.search) {
        const term = `%${escapeLikePattern(q.search)}%`
        F.$or = [{ title: { $ilike: term } }, { author: { $ilike: term } }, { isbn: { $ilike: term } }]
      }
      return filters
    },
    transformItem: (item: BookRow): BookListItem => ({
      id: String(item.id),
      title: String(item.title),
      author: String(item.author),
      isbn: item.isbn ?? null,
      publisher: item.publisher ?? null,
      publishedYear: item.published_year ?? null,
      description: item.description ?? null,
      totalCopies: item.total_copies,
      // With no loans present availability equals the copy count; Phase 2
      // subtracts the in-scope active-loan count for each book.
      availableCopies: item.total_copies,
      tenantId: item.tenant_id ?? null,
      organizationId: item.organization_id ?? null,
      updatedAt: toIsoTimestamp(item.updated_at),
    }),
  },
  actions: {
    create: {
      commandId: 'library.books.create',
      schema: rawBodySchema,
      mapInput: ({ parsed }) => parsed,
      response: ({ result }) => ({ id: String(result.id) }),
      status: 201,
    },
    update: {
      commandId: 'library.books.update',
      schema: rawBodySchema,
      mapInput: ({ parsed }) => parsed,
      response: () => ({ ok: true as const }),
    },
    delete: {
      commandId: 'library.books.delete',
      response: () => ({ ok: true as const }),
    },
  },
})

export const openApi: OpenApiRouteDoc = createLibraryCrudOpenApi({
  resourceName: 'Book',
  pluralName: 'Books',
  querySchema: bookListQuerySchema,
  listResponseSchema: createLibraryPagedListResponseSchema(bookListItemDocSchema),
  create: {
    schema: rawBodySchema,
    description: 'Creates a book record in the library catalog. ISBN must be unique per organization when present.',
    responseSchema: libraryCreatedSchema,
  },
  update: {
    schema: rawBodySchema,
    description: 'Updates an existing book record by id. Send `expected_updated_at` for optimistic locking.',
    responseSchema: libraryOkSchema,
  },
  del: {
    description: 'Deletes a book by id. A book with any loan history cannot be deleted.',
    responseSchema: libraryOkSchema,
  },
})
