import { NextResponse } from 'next/server'
import type { FilterQuery } from '@mikro-orm/core'
import { getAuthFromCookies } from '@open-mercato/shared/lib/auth/server'
import { createRequestContainer } from '@open-mercato/shared/lib/di/container'
import type { EntityManager } from '@mikro-orm/postgresql'
import { escapeLikePattern } from '@open-mercato/shared/lib/db/escapeLikePattern'
import { Book, Loan } from '../../../../data/entities'
import type { OpenApiRouteDoc } from '@open-mercato/shared/lib/openapi'

export const metadata = {
  GET: { requireAuth: true, requireFeatures: ['library.view'] },
}

export async function GET(request: Request): Promise<Response> {
  const auth = await getAuthFromCookies()
  if (!auth?.tenantId || !auth?.orgId) {
    return NextResponse.json({ items: [] }, { status: 200 })
  }
  const tenantId = auth.tenantId
  const organizationId = auth.orgId

  const url = new URL(request.url)
  const q = (url.searchParams.get('q') ?? '').trim()
  const limit = Math.min(Math.max(Number(url.searchParams.get('pageSize') ?? '20') || 20, 1), 50)

  const { resolve } = await createRequestContainer()
  const em = resolve<EntityManager>('em')

  const bookWhere: FilterQuery<Book> = {
    tenantId,
    organizationId,
    ...(q ? { $or: [{ title: { $ilike: `%${escapeLikePattern(q)}%` } }, { author: { $ilike: `%${escapeLikePattern(q)}%` } }] } : {}),
  } as FilterQuery<Book>

  const books = await em.find(Book, bookWhere, { orderBy: { title: 'asc' }, limit, fields: ['id', 'title', 'author', 'totalCopies'] as unknown as never })

  if (books.length === 0) {
    return NextResponse.json({ items: [] })
  }

  const bookIds = books.map((book) => String(book.id))
  const activeLoans = await em.find(
    Loan,
    { bookId: { $in: bookIds }, tenantId, organizationId, returnedAt: null } as FilterQuery<Loan>,
    { fields: ['bookId'] as unknown as never },
  )
  const activeByBook = new Map<string, number>()
  for (const loan of activeLoans) {
    activeByBook.set(loan.bookId, (activeByBook.get(loan.bookId) ?? 0) + 1)
  }

  const items = books.map((book) => {
    const available = Math.max(0, book.totalCopies - (activeByBook.get(String(book.id)) ?? 0))
    return {
      value: String(book.id),
      label: available > 0 ? `${book.title} — ${book.author}` : `${book.title} — ${book.author} (0 available)`,
      availableCopies: available,
    }
  })

  return NextResponse.json({ items })
}

void bookOptionSchema

export const openApi: OpenApiRouteDoc = {
  tag: 'Library',
  summary: 'Book options for checkout',
  methods: {
    GET: {
      summary: 'List books as checkout options',
      description:
        'Returns books in scope as `{ value, label, availableCopies }` options for the checkout book picker. Books with zero available copies are labelled accordingly.',
      tags: ['Library'],
      responses: [
        { status: 200, description: 'Book options.' },
        { status: 401, description: 'Authentication required' },
        { status: 403, description: 'Forbidden' },
      ],
    },
  },
}
