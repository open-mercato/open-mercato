import type { ModuleSetupConfig } from '@open-mercato/shared/modules/setup'

/**
 * Library module setup.
 *
 * The module is purely additive — no custom-entity definitions, schedulers, or
 * demo seeds are needed for v1. Staff gain access through the default role
 * feature grants below; every read and write still derives `tenantId` /
 * `organizationId` from the authenticated session and fails closed without it.
 */
export const setup: ModuleSetupConfig = {
  defaultRoleFeatures: {
    superadmin: ['library.*'],
    admin: ['library.*'],
    employee: ['library.*'],
  },
}

export default setup
