import type { ModuleInfo } from '@open-mercato/shared/modules/registry'

export const metadata: ModuleInfo = {
  name: 'library',
  title: 'Library',
  version: '0.1.0',
  description: 'Books catalog and lending for backend staff.',
  author: 'Open Mercato Team',
  license: 'MIT',
}
