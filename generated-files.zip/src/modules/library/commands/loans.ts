import type { CommandHandler, CommandRuntimeContext } from '@open-mercato/shared/lib/commands'
import { registerCommand } from '@open-mercato/shared/lib/commands'
import { requireId } from '@open-mercato/shared/lib/commands/helpers'
import { badRequest, conflict, notFound } from '@open-mercato/shared/lib/crud/errors'
import { assertOptimisticLock } from '@open-mercato/shared/lib/crud/optimistic-lock-command'
import type { EntityManager, FilterQuery, RequiredEntityData } from '@mikro-orm/core'
import type { DataEngine } from '@open-mercato/shared/lib/data/engine'
import type { QueryEngine } from '@open-mercato/shared/lib/query/types'
import { resolveTranslations } from '@open-mercato/shared/lib/i18n/server'
import { E } from '@/.mercato/generated/entities.ids.generated'
import { display_name, id as idField, primary_email } from '@/.mercato/generated/entities/customer_entity'
import { Book, Loan } from '../data/entities'
import { loanCheckoutSchema, loanReturnSchema } from '../data/validators'
import { emitLibraryEvent } from '../events'

type Scope = { tenantId: string; organizationId: string }

export const LOAN_ENTITY_ID = 'library:loan' as const

type CustomerLookup = { id: string; display_name: string | null; primary_email: string | null }

function ensureScope(ctx: CommandRuntimeContext): Scope {
  const tenantId = ctx.auth?.tenantId ?? null
  if (!tenantId) throw badRequest('Tenant context is required')
  const organizationId = ctx.selectedOrganizationId ?? ctx.auth?.orgId ?? null
  if (!organizationId) throw badRequest('Organization context is required')
  return { tenantId, organizationId }
}

function loanScopeFilter(id: string, scope: Scope): FilterQuery<Loan> {
  return { id, tenantId: scope.tenantId, organizationId: scope.organizationId } as FilterQuery<Loan>
}

function resolveEm(ctx: CommandRuntimeContext): EntityManager {
  return ctx.container.resolve('em') as EntityManager
}

function resolveDataEngine(ctx: CommandRuntimeContext): DataEngine {
  return ctx.container.resolve('dataEngine') as DataEngine
}

async function lookupCustomer(ctx: CommandRuntimeContext, customerId: string, scope: Scope): Promise<CustomerLookup | null> {
  const queryEngine = ctx.container.resolve('queryEngine') as QueryEngine
  const res = await queryEngine.query<CustomerLookup>(E.customers.customer_entity, {
    tenantId: scope.tenantId,
    organizationId: scope.organizationId,
    fields: [idField, display_name, primary_email],
    filters: [{ field: 'id', op: 'in', value: [customerId] }],
  })
  return res.items[0] ?? null
}

/**
 * Checkout is the operation that can double-lend the last copy under
 * concurrency, so the availability check and the loan insert run inside one
 * `em.transactional` callback. A second concurrent checkout that reads the
 * same active-loan count before the first commits is serialized by the
 * transaction; the loser re-counts after the winner's commit and sees one fewer
 * available copy, failing closed with a 409.
 */
const checkoutLoanCommand: CommandHandler<Record<string, unknown>, Loan> = {
  id: 'library.loans.checkout',
  async execute(rawInput, ctx) {
    const parsed = loanCheckoutSchema.parse(rawInput)
    const scope = ensureScope(ctx)
    const em = resolveEm(ctx)

    const customer = await lookupCustomer(ctx, parsed.customerId, scope)
    if (!customer) throw badRequest('Selected customer was not found in this organization')

    const book = await em.findOne(Book, {
      id: parsed.bookId,
      tenantId: scope.tenantId,
      organizationId: scope.organizationId,
    } as FilterQuery<Book>)
    if (!book) throw badRequest('Selected book was not found in this organization')

    const dueAt = new Date(parsed.dueAt)
    const loanedAt = new Date()
    if (dueAt.getTime() <= loanedAt.getTime()) {
      throw badRequest('Due date must be after the checkout time')
    }

    const borrowerDisplayName = customer.display_name?.trim() || customer.primary_email?.trim() || parsed.customerId
    const borrowerEmail = customer.primary_email ?? null

    const loan = await em.transactional(async (trxEm) => {
      const activeCount = await trxEm.count(Loan, {
        bookId: parsed.bookId,
        tenantId: scope.tenantId,
        organizationId: scope.organizationId,
        returnedAt: null,
      } as FilterQuery<Loan>)
      if (book.totalCopies - activeCount <= 0) {
        throw conflict('No copies of this book are currently available')
      }
      const created = trxEm.create(
        Loan,
        {
          bookId: parsed.bookId,
          borrowerCustomerId: parsed.customerId,
          borrowerDisplayName,
          borrowerEmail,
          loanedAt,
          dueAt,
          returnedAt: null,
          notes: parsed.notes ?? null,
          tenantId: scope.tenantId,
          organizationId: scope.organizationId,
        } as unknown as RequiredEntityData<Loan>,
      )
      trxEm.persist(created)
      return created
    })

    await emitLibraryEvent('library.loan.checked_out', {
      id: String(loan.id),
      tenantId: scope.tenantId,
      organizationId: scope.organizationId,
      bookId: parsed.bookId,
      borrowerCustomerId: parsed.customerId,
      borrowerDisplayName,
      dueAt: dueAt.toISOString(),
      loanedAt: loanedAt.toISOString(),
    })

    return loan
  },
  buildLog: async ({ result }) => {
    const { translate } = await resolveTranslations()
    return {
      actionLabel: translate('library.audit.loans.checkout', 'Check out loan'),
      resourceKind: 'library.loan',
      resourceId: String(result.id),
      tenantId: result.tenantId,
      organizationId: result.organizationId,
    }
  },
}

const returnLoanCommand: CommandHandler<Record<string, unknown>, Loan> = {
  id: 'library.loans.return',
  async execute(rawInput, ctx) {
    const parsed = loanReturnSchema.parse(rawInput)
    const scope = ensureScope(ctx)
    const de = resolveDataEngine(ctx)
    const em = resolveEm(ctx)

    const existing = await em.findOne(Loan, loanScopeFilter(parsed.id, scope))
    if (!existing) throw notFound('Loan not found')
    assertOptimisticLock({
      resourceKind: LOAN_ENTITY_ID,
      resourceId: parsed.id,
      expected: parsed.expected_updated_at,
      current: existing.updatedAt,
    })
    if (existing.returnedAt) {
      throw conflict('This loan has already been returned')
    }

    const updated = await de.updateOrmEntity({
      entity: Loan,
      where: loanScopeFilter(parsed.id, scope),
      apply: (loan) => {
        loan.returnedAt = new Date()
        if (parsed.notes !== undefined) loan.notes = parsed.notes
      },
    })
    if (!updated) throw notFound('Loan not found')

    await emitLibraryEvent('library.loan.returned', {
      id: String(updated.id),
      tenantId: scope.tenantId,
      organizationId: scope.organizationId,
      bookId: updated.bookId,
      borrowerCustomerId: updated.borrowerCustomerId,
      returnedAt: updated.returnedAt ? new Date(updated.returnedAt).toISOString() : null,
    })

    return updated
  },
  buildLog: async ({ result }) => {
    const { translate } = await resolveTranslations()
    return {
      actionLabel: translate('library.audit.loans.return', 'Return loan'),
      resourceKind: 'library.loan',
      resourceId: String(result.id),
      tenantId: result.tenantId,
      organizationId: result.organizationId,
    }
  },
}

registerCommand(checkoutLoanCommand)
registerCommand(returnLoanCommand)
