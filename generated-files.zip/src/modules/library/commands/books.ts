import type { CommandHandler, CommandRuntimeContext } from '@open-mercato/shared/lib/commands'
import { registerCommand } from '@open-mercato/shared/lib/commands'
import { buildChanges, emitCrudSideEffects, requireId } from '@open-mercato/shared/lib/commands/helpers'
import type { CrudEventsConfig } from '@open-mercato/shared/lib/crud/types'
import { badRequest, conflict, notFound } from '@open-mercato/shared/lib/crud/errors'
import { assertOptimisticLock } from '@open-mercato/shared/lib/crud/optimistic-lock-command'
import type { EntityManager, FilterQuery } from '@mikro-orm/postgresql'
import type { DataEngine } from '@open-mercato/shared/lib/data/engine'
import { resolveTranslations } from '@open-mercato/shared/lib/i18n/server'
import { Book, Loan } from '../data/entities'
import { bookCreateSchema, bookUpdateSchema, normalizeIsbn } from '../data/validators'

export const ENTITY_ID = 'library:book' as const

type Scope = { tenantId: string; organizationId: string }

type SerializedBook = {
  id: string
  title: string
  author: string
  isbn: string | null
  publisher: string | null
  publishedYear: number | null
  description: string | null
  totalCopies: number
  tenantId: string
  organizationId: string
}

function serializeBook(book: Book): SerializedBook {
  return {
    id: String(book.id),
    title: String(book.title),
    author: String(book.author),
    isbn: book.isbn ?? null,
    publisher: book.publisher ?? null,
    publishedYear: book.publishedYear ?? null,
    description: book.description ?? null,
    totalCopies: book.totalCopies,
    tenantId: String(book.tenantId),
    organizationId: String(book.organizationId),
  }
}

export const bookCrudEvents: CrudEventsConfig<Book> = {
  module: 'library',
  entity: 'book',
  persistent: true,
  buildPayload: (ctx) => ({
    id: ctx.identifiers.id,
    tenantId: ctx.identifiers.tenantId,
    organizationId: ctx.identifiers.organizationId,
    title: ctx.entity?.title ?? null,
    author: ctx.entity?.author ?? null,
    isbn: ctx.entity?.isbn ?? null,
  }),
}

function ensureScope(ctx: CommandRuntimeContext): Scope {
  const tenantId = ctx.auth?.tenantId ?? null
  if (!tenantId) throw badRequest('Tenant context is required')
  const organizationId = ctx.selectedOrganizationId ?? ctx.auth?.orgId ?? null
  if (!organizationId) throw badRequest('Organization context is required')
  return { tenantId, organizationId }
}

function bookScopeFilter(id: string, scope: Scope): FilterQuery<Book> {
  return { id, tenantId: scope.tenantId, organizationId: scope.organizationId } as FilterQuery<Book>
}

async function assertIsbnAvailable(em: EntityManager, isbn: string, scope: Scope, exceptId?: string): Promise<void> {
  const dup = await em.findOne(Book, {
    isbn,
    tenantId: scope.tenantId,
    organizationId: scope.organizationId,
  } as FilterQuery<Book>)
  if (dup && dup.id !== exceptId) {
    throw conflict('A book with this ISBN already exists in this organization')
  }
}

function resolveDataEngine(ctx: CommandRuntimeContext): DataEngine {
  return ctx.container.resolve('dataEngine') as DataEngine
}

function resolveEm(ctx: CommandRuntimeContext): EntityManager {
  return ctx.container.resolve('em') as EntityManager
}

const createBookCommand: CommandHandler<Record<string, unknown>, Book> = {
  id: 'library.books.create',
  async execute(rawInput, ctx) {
    const parsed = bookCreateSchema.parse(rawInput)
    const scope = ensureScope(ctx)
    const em = resolveEm(ctx)
    const de = resolveDataEngine(ctx)
    const isbn = normalizeIsbn(parsed.isbn)
    if (isbn) await assertIsbnAvailable(em, isbn, scope)

    const book = await de.createOrmEntity({
      entity: Book,
      data: {
        ...(parsed.id ? { id: parsed.id } : {}),
        title: parsed.title,
        author: parsed.author,
        isbn,
        publisher: parsed.publisher ?? null,
        publishedYear: parsed.publishedYear ?? null,
        description: parsed.description ?? null,
        totalCopies: parsed.totalCopies,
        tenantId: scope.tenantId,
        organizationId: scope.organizationId,
      },
    })

    await emitCrudSideEffects({
      dataEngine: de,
      action: 'created',
      entity: book,
      identifiers: { id: String(book.id), tenantId: scope.tenantId, organizationId: scope.organizationId },
      events: bookCrudEvents,
    })

    return book
  },
  buildLog: async ({ result }) => {
    const { translate } = await resolveTranslations()
    return {
      actionLabel: translate('library.audit.books.create', 'Create book'),
      resourceKind: 'library.book',
      resourceId: String(result.id),
      tenantId: result.tenantId,
      organizationId: result.organizationId,
      snapshotAfter: serializeBook(result),
    }
  },
}

const updateBookCommand: CommandHandler<Record<string, unknown>, Book> = {
  id: 'library.books.update',
  async prepare(rawInput, ctx) {
    const parsed = bookUpdateSchema.parse(rawInput)
    const scope = ensureScope(ctx)
    const em = resolveEm(ctx)
    const existing = await em.findOne(Book, bookScopeFilter(parsed.id, scope))
    if (!existing) throw notFound('Book not found')
    assertOptimisticLock({
      resourceKind: ENTITY_ID,
      resourceId: parsed.id,
      expected: parsed.expected_updated_at,
      current: existing.updatedAt,
    })
    return { before: serializeBook(existing) }
  },
  async execute(rawInput, ctx) {
    const parsed = bookUpdateSchema.parse(rawInput)
    const scope = ensureScope(ctx)
    const em = resolveEm(ctx)
    const de = resolveDataEngine(ctx)

    const isbnProvided = parsed.isbn !== undefined
    const newIsbn = isbnProvided ? normalizeIsbn(parsed.isbn) : undefined

    const existing = await em.findOne(Book, bookScopeFilter(parsed.id, scope))
    if (!existing) throw notFound('Book not found')
    if (newIsbn && newIsbn !== normalizeIsbn(existing.isbn)) {
      await assertIsbnAvailable(em, newIsbn, scope, parsed.id)
    }

    const updated = await de.updateOrmEntity({
      entity: Book,
      where: bookScopeFilter(parsed.id, scope),
      apply: (book) => {
        if (parsed.title !== undefined) book.title = parsed.title
        if (parsed.author !== undefined) book.author = parsed.author
        if (isbnProvided) book.isbn = newIsbn ?? null
        if (parsed.publisher !== undefined) book.publisher = parsed.publisher ?? null
        if (parsed.publishedYear !== undefined) book.publishedYear = parsed.publishedYear
        if (parsed.description !== undefined) book.description = parsed.description ?? null
        if (parsed.totalCopies !== undefined) book.totalCopies = parsed.totalCopies
      },
    })
    if (!updated) throw notFound('Book not found')

    await emitCrudSideEffects({
      dataEngine: de,
      action: 'updated',
      entity: updated,
      identifiers: { id: String(updated.id), tenantId: scope.tenantId, organizationId: scope.organizationId },
      events: bookCrudEvents,
    })

    return updated
  },
  buildLog: async ({ result, snapshots }) => {
    const { translate } = await resolveTranslations()
    const before = snapshots.before as SerializedBook | undefined
    const after = serializeBook(result)
    const changes = buildChanges(before ?? null, after as unknown as Record<string, unknown>, [
      'title',
      'author',
      'isbn',
      'publisher',
      'publishedYear',
      'description',
      'totalCopies',
    ])
    return {
      actionLabel: translate('library.audit.books.update', 'Update book'),
      resourceKind: 'library.book',
      resourceId: String(result.id),
      tenantId: result.tenantId,
      organizationId: result.organizationId,
      changes,
      snapshotBefore: before ?? null,
      snapshotAfter: after,
    }
  },
}

const deleteBookCommand: CommandHandler<{ body?: Record<string, unknown>; query?: Record<string, unknown> }, Book> = {
  id: 'library.books.delete',
  async prepare(input, ctx) {
    const id = requireId(input, 'Book id required')
    const scope = ensureScope(ctx)
    const em = resolveEm(ctx)
    const existing = await em.findOne(Book, bookScopeFilter(id, scope))
    if (!existing) return null
    return { before: serializeBook(existing) }
  },
  async execute(input, ctx) {
    const id = requireId(input, 'Book id required')
    const scope = ensureScope(ctx)
    const em = resolveEm(ctx)
    const de = resolveDataEngine(ctx)

    const existing = await em.findOne(Book, bookScopeFilter(id, scope))
    if (!existing) throw notFound('Book not found')
    // A book with any loan history (any state) is not deletable — the loans are
    // its audit trail. A book never lent carries no references and is removed.
    const loanCount = await em.count(Loan, {
      bookId: id,
      tenantId: scope.tenantId,
      organizationId: scope.organizationId,
    } as FilterQuery<Loan>)
    if (loanCount > 0) {
      throw conflict('This book cannot be deleted because it has loan history')
    }

    const removed = await de.deleteOrmEntity({
      entity: Book,
      where: bookScopeFilter(id, scope),
      soft: false,
    })
    if (!removed) throw notFound('Book not found')

    await emitCrudSideEffects({
      dataEngine: de,
      action: 'deleted',
      entity: removed,
      identifiers: { id, tenantId: scope.tenantId, organizationId: scope.organizationId },
      events: bookCrudEvents,
    })

    return removed
  },
  buildLog: async ({ snapshots, input }) => {
    const { translate } = await resolveTranslations()
    const before = snapshots.before as SerializedBook | undefined
    const id = requireId(input, 'Book id required')
    return {
      actionLabel: translate('library.audit.books.delete', 'Delete book'),
      resourceKind: 'library.book',
      resourceId: id,
      tenantId: before?.tenantId ?? null,
      organizationId: before?.organizationId ?? null,
      snapshotBefore: before ?? null,
    }
  },
}

registerCommand(createBookCommand)
registerCommand(updateBookCommand)
registerCommand(deleteBookCommand)
