// Shared UI/API types for the Library module.

export type LoanStatus = 'active' | 'overdue' | 'returned'

/**
 * Shape returned by the books list API (via the CRUD factory transform).
 * `availableCopies` is the computed availability (`total_copies` minus active
 * loans), enriched by the route's `afterList` hook from Phase 2 onward.
 */
export type BookListItem = {
  id: string
  title: string
  author: string
  isbn: string | null
  publisher: string | null
  publishedYear: number | null
  description: string | null
  totalCopies: number
  availableCopies: number
  tenantId: string | null
  organizationId: string | null
  /** Optimistic-lock version token. */
  updatedAt: string | null
}

/**
 * Shape returned by the loans list API. `status` is derived at read time:
 * `returned` once `returnedAt` is set, otherwise `overdue` when past due, else
 * `active`.
 */
export type LoanListItem = {
  id: string
  bookId: string
  bookTitle: string
  borrowerCustomerId: string
  borrowerDisplayName: string
  borrowerEmail: string | null
  loanedAt: string
  dueAt: string
  returnedAt: string | null
  notes: string | null
  status: LoanStatus
  tenantId: string | null
  organizationId: string | null
  /** Optimistic-lock version token. */
  updatedAt: string | null
}
