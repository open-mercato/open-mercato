"use client"
import * as React from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import type { LegacyColumnDef as ColumnDef } from '@tanstack/react-table/legacy'
import type { SortingState } from '@tanstack/react-table'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { DataTable } from '@open-mercato/ui/backend/DataTable'
import { RowActions } from '@open-mercato/ui/backend/RowActions'
import { Button } from '@open-mercato/ui/primitives/button'
import { fetchCrudList, deleteCrud } from '@open-mercato/ui/backend/utils/crud'
import { withScopedApiRequestHeaders, readApiResultOrThrow } from '@open-mercato/ui/backend/utils/apiCall'
import { buildOptimisticLockHeader } from '@open-mercato/ui/backend/utils/optimisticLock'
import { surfaceRecordConflict } from '@open-mercato/ui/backend/conflicts'
import { flash } from '@open-mercato/ui/backend/FlashMessages'
import { useConfirmDialog } from '@open-mercato/ui/backend/confirm-dialog'
import { useOrganizationScopeVersion } from '@open-mercato/shared/lib/frontend/useOrganizationScope'
import { useT } from '@«redacted:high-entropy»'
import type { BookListItem } from '../types'

const LIST_PATH = '/backend/library/books'
const CRUD_RESOURCE = 'library/books'

type BooksResponse = {
  items: BookListItem[]
  total: number
  page: number
  pageSize: number
  totalPages: number
}

function buildColumns(t: (key: string, params?: Record<string, string | number>) => string): ColumnDef<BookListItem>[] {
  return [
    { accessorKey: 'title', header: t('library.books.table.column.title'), meta: { priority: 1 } },
    { accessorKey: 'author', header: t('library.books.table.column.author'), meta: { priority: 2 } },
    {
      accessorKey: 'isbn',
      header: t('library.books.table.column.isbn'),
      cell: ({ getValue }) => {
        const value = getValue()
        return value ? <span className="font-mono text-xs">{String(value)}</span> : <span className="text-muted-foreground">—</span>
      },
      meta: { priority: 4 },
    },
    { accessorKey: 'totalCopies', header: t('library.books.table.column.copies'), meta: { priority: 3 } },
    {
      accessorKey: 'availableCopies',
      header: t('library.books.table.column.available'),
      cell: ({ row, getValue }) => {
        const available = Number(getValue() ?? 0)
        const total = Number(row.original.totalCopies ?? 0)
        const tone = available <= 0 ? 'text-destructive' : available < total ? 'text-amber-600 dark:text-amber-500' : 'text-emerald-600 dark:text-emerald-500'
        return <span className={tone}>{available}</span>
      },
      meta: { priority: 5 },
    },
  ]
}

export default function BooksTable() {
  const t = useT()
  const router = useRouter()
  const queryClient = useQueryClient()
  const { confirm, ConfirmDialogElement } = useConfirmDialog()
  const scopeVersion = useOrganizationScopeVersion()
  const [search, setSearch] = React.useState('')
  const [sorting, setSorting] = React.useState<SortingState>([{ id: 'title', desc: false }])
  const [page, setPage] = React.useState(1)

  const queryParams = React.useMemo(() => {
    const params = new URLSearchParams({
      page: page.toString(),
      pageSize: '50',
      sortField: sorting[0]?.id || 'title',
      sortDir: sorting[0]?.desc ? 'desc' : 'asc',
    })
    if (search) params.set('search', search)
    return params.toString()
  }, [page, sorting, search])

  const { data, isLoading, error } = useQuery<BooksResponse>({
    queryKey: ['library/books', queryParams, scopeVersion],
    queryFn: async () =>
      readApiResultOrThrow<BooksResponse>(
        `/api/library/books?${queryParams}`,
        undefined,
        { errorMessage: t('library.books.table.error.generic') },
      ),
  })

  const columns = React.useMemo(() => buildColumns(t), [t])

  if (error) {
    return <div className="text-sm text-destructive">{t('library.books.table.error.generic')}</div>
  }

  return (
    <>
      <DataTable
        title={t('library.books.table.title')}
        actions={
          <Button asChild>
            <Link href={`${LIST_PATH}/create`}>{t('library.books.table.actions.create')}</Link>
          </Button>
        }
        columns={columns}
        data={data?.items ?? []}
        searchValue={search}
        onSearchChange={(value) => {
          setSearch(value)
          setPage(1)
        }}
        searchPlaceholder={t('library.books.table.searchPlaceholder')}
        emptyState={
          <div className="flex flex-col items-center gap-2 py-8 text-sm text-muted-foreground">
            <span>{t('library.books.table.empty')}</span>
            <Button asChild variant="outline">
              <Link href={`${LIST_PATH}/create`}>{t('library.books.table.actions.create')}</Link>
            </Button>
          </div>
        }
        sortable
        sorting={sorting}
        onSortingChange={(next) => {
          setSorting(next)
          setPage(1)
        }}
        rowActions={(row) => (
          <RowActions
            items={[
              { label: t('library.books.table.actions.edit'), href: `${LIST_PATH}/${row.id}/edit` },
              {
                label: t('library.books.table.actions.delete'),
                destructive: true,
                onSelect: async () => {
                  const confirmed = await confirm({
                    title: t('library.books.table.confirm.delete'),
                    variant: 'destructive',
                  })
                  if (!confirmed) return
                  try {
                    await withScopedApiRequestHeaders(
                      buildOptimisticLockHeader(row.updatedAt),
                      () => deleteCrud(CRUD_RESOURCE, row.id),
                    )
                    flash(t('library.books.form.flash.deleted'), 'success')
                    queryClient.invalidateQueries({ queryKey: ['library/books'] })
                  } catch (err) {
                    if (surfaceRecordConflict(err, t)) {
                      queryClient.invalidateQueries({ queryKey: ['library/books'] })
                      return
                    }
                    const message = err instanceof Error && err.message ? err.message : t('library.books.table.error.delete')
                    flash(message, 'error')
                  }
                },
              },
            ]}
          />
        )}
        pagination={{
          page,
          pageSize: 50,
          total: data?.total ?? 0,
          totalPages: data?.totalPages ?? 0,
          onPageChange: setPage,
        }}
        isLoading={isLoading}
        onRowClick={(row) => router.push(`${LIST_PATH}/${row.id}/edit`)}
      />
      {ConfirmDialogElement}
    </>
  )
}
