"use client"
import * as React from 'react'
import { CrudForm, type CrudField, type CrudFormGroup } from '@open-mercato/ui/backend/CrudForm'
import { ErrorMessage, RecordNotFoundState } from '@open-mercato/ui/backend/detail'
import { createCrud, fetchCrudList, updateCrud, deleteCrud } from '@open-mercato/ui/backend/utils/crud'
import { withFlash } from '@open-mercato/ui/backend/utils/flash'
import { useT } from '@«redacted:high-entropy»'
import type { BookListItem } from '../types'
import extensionPoints from '../extension-points'

// CrudForm normalizes the colon form `library:book` to the `library.book` spot id.
const ENTITY_ID = extensionPoints.hosts.bookForm.entityId
const LIST_HREF = '/backend/library/books'

type Translate = ReturnType<typeof useT>

export type BookFormValues = {
  id: string
  title: string
  author: string
  isbn: string
  publisher: string
  publishedYear: number | string
  description: string
  totalCopies: number | string
  // Optimistic-lock version; CrudForm auto-derives the expected-version header
  // from `initialValues.updatedAt` for update AND delete.
  updatedAt?: string | null
}

export function toBookFormValues(item: BookListItem): BookFormValues {
  return {
    id: item.id,
    title: item.title,
    author: item.author,
    isbn: item.isbn ?? '',
    publisher: item.publisher ?? '',
    publishedYear: item.publishedYear ?? '',
    description: item.description ?? '',
    totalCopies: item.totalCopies,
    updatedAt: item.updatedAt ?? null,
  }
}

function useBookFields(t: Translate): CrudField[] {
  return React.useMemo<CrudField[]>(() => [
    {
      id: 'title',
      label: t('library.books.form.fields.title.label'),
      type: 'text',
      required: true,
      placeholder: t('library.books.form.fields.title.placeholder'),
    },
    {
      id: 'author',
      label: t('library.books.form.fields.author.label'),
      type: 'text',
      required: true,
      placeholder: t('library.books.form.fields.author.placeholder'),
    },
    {
      id: 'isbn',
      label: t('library.books.form.fields.isbn.label'),
      type: 'text',
      description: t('library.books.form.fields.isbn.description'),
      placeholder: t('library.books.form.fields.isbn.placeholder'),
    },
    { id: 'publisher', label: t('library.books.form.fields.publisher.label'), type: 'text' },
    { id: 'publishedYear', label: t('library.books.form.fields.publishedYear.label'), type: 'number' },
    { id: 'totalCopies', label: t('library.books.form.fields.totalCopies.label'), type: 'number', required: true, description: t('library.books.form.fields.totalCopies.description') },
    { id: 'description', label: t('library.books.form.fields.description.label'), type: 'textarea' },
  ], [t])
}

function useBookGroups(t: Translate): CrudFormGroup[] {
  return React.useMemo<CrudFormGroup[]>(() => [
    { id: 'details', title: t('library.books.form.groups.details'), column: 1, fields: ['title', 'author', 'description'] },
    { id: 'inventory', title: t('library.books.form.groups.inventory'), column: 2, fields: ['isbn', 'publisher', 'publishedYear', 'totalCopies'] },
  ], [t])
}

export function BookCreateForm() {
  const t = useT()
  const fields = useBookFields(t)
  const groups = useBookGroups(t)
  const successRedirect = React.useMemo(
    () => `${LIST_HREF}?flash=${encodeURIComponent(t('library.books.form.flash.created'))}&type=success`,
    [t],
  )

  return (
    <CrudForm<BookFormValues>
      title={t('library.books.create.title')}
      backHref={LIST_HREF}
      entityId={ENTITY_ID}
      fields={fields}
      groups={groups}
      submitLabel={t('library.books.form.create.submit')}
      cancelHref={LIST_HREF}
      successRedirect={successRedirect}
      onSubmit={async (vals) => { await createCrud('library/books', vals) }}
    />
  )
}

export function BookEditForm({ id }: { id: string }) {
  const t = useT()
  const [initial, setInitial] = React.useState<BookFormValues | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [err, setErr] = React.useState<string | null>(null)
  const [isNotFound, setIsNotFound] = React.useState(false)
  const fields = useBookFields(t)
  const groups = useBookGroups(t)
  const successRedirect = React.useMemo(
    () => `${LIST_HREF}?flash=${encodeURIComponent(t('library.books.form.flash.saved'))}&type=success`,
    [t],
  )
  const deleteRedirect = React.useMemo(
    () => withFlash(LIST_HREF, t('library.books.form.flash.deleted'), 'success'),
    [t],
  )

  React.useEffect(() => {
    let cancelled = false
    async function load() {
      setLoading(true)
      setErr(null)
      setIsNotFound(false)
      try {
        const data = await fetchCrudList<BookListItem>('library/books', { ids: String(id), pageSize: 1 })
        const item = data?.items?.[0]
        if (!item) {
          if (!cancelled) setIsNotFound(true)
          return
        }
        if (!cancelled) setInitial(toBookFormValues(item))
      } catch (error: unknown) {
        if (!cancelled) {
          if ((error as { status?: number }).status === 404) {
            setIsNotFound(true)
          } else {
            const message = error instanceof Error && error.message ? error.message : t('library.books.form.error.load')
            setErr(message)
          }
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    load()
    return () => { cancelled = true }
  }, [id, t])

  const fallbackInitialValues = React.useMemo<BookFormValues>(() => ({
    id,
    title: '',
    author: '',
    isbn: '',
    publisher: '',
    publishedYear: '',
    description: '',
    totalCopies: 1,
    updatedAt: null,
  }), [id])

  if (isNotFound) {
    return (
      <RecordNotFoundState
        label={t('library.books.form.error.notFound')}
        backHref={LIST_HREF}
        backLabel={t('library.books.form.actions.backToList')}
      />
    )
  }

  if (err) return <ErrorMessage label={err} />

  return (
    <CrudForm<BookFormValues>
      title={t('library.books.edit.title')}
      backHref={LIST_HREF}
      entityId={ENTITY_ID}
      fields={fields}
      groups={groups}
      initialValues={initial ?? fallbackInitialValues}
      submitLabel={t('library.books.form.edit.submit')}
      cancelHref={LIST_HREF}
      successRedirect={successRedirect}
      deleteRedirect={deleteRedirect}
      isLoading={loading}
      loadingMessage={t('library.books.form.loading')}
      onSubmit={async (vals) => { await updateCrud('library/books', vals) }}
      onDelete={async () => { await deleteCrud('library/books', String(id)) }}
    />
  )
}
