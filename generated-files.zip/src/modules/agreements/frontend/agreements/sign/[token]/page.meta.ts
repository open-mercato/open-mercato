export const metadata = {
  pageTitle: 'Sign agreement',
  pageTitleKey: 'agreements.sign.pageTitle',
  navHidden: true,
}
