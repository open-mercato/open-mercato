import SignerCeremony from '../../../../components/SignerCeremony'

export default function AgreementSigningPage({ params }: { params: { token: string } }) {
  return <SignerCeremony token={params.token} />
}
