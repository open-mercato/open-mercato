export type SigningMode = 'sequential' | 'parallel'

export function canSignerSign(
  mode: SigningMode,
  routingOrder: number,
  signers: readonly { routingOrder: number; status: string }[],
): boolean {
  if (mode === 'parallel') return true
  return signers
    .filter((signer) => signer.routingOrder < routingOrder)
    .every((signer) => signer.status === 'signed')
}
