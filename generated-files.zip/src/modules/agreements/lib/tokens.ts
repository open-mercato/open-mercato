import { createHash, randomBytes } from 'node:crypto'

function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex')
}

export function createSignerToken(): { token: string; tokenHash: string } {
  const token = randomBytes(32).toString('base64url')
  return { token, tokenHash: hashToken(token) }
}

export function signerTokenHash(token: string): string {
  return hashToken(token)
}
