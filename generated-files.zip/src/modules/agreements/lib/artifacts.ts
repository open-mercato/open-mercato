import { createHash, randomUUID } from 'node:crypto'
import type { EntityManager, FilterQuery } from '@mikro-orm/postgresql'
import { StorageDriverFactory } from '@open-mercato/core/modules/attachments/lib/drivers'
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib'
import { AgreementArtifact, AgreementVersion, EnvelopeField, Signature, Signer, SigningEnvelope } from '../data/entities'

const PRIVATE_PARTITION = 'privateAttachments'
const MAX_PDF_BYTES = 10 * 1024 * 1024

export type ArtifactScope = { tenantId: string; organizationId: string }

function sha256(buffer: Buffer | string): string {
  return createHash('sha256').update(buffer).digest('hex')
}

function decodePdfPayload(payload: string): Buffer {
  const encoded = payload.replace(/^data:application\/pdf;base64,/, '').replace(/\s/g, '')
  const buffer = Buffer.from(encoded, 'base64')
  if (buffer.length === 0 || buffer.length > MAX_PDF_BYTES || buffer.subarray(0, 5).toString() !== '%PDF-') {
    throw new Error('PDF must be a valid file no larger than 10 MB')
  }
  return buffer
}

export function decodePdfBase64(payload: string): Buffer {
  return decodePdfPayload(payload)
}

export async function validatePdf(buffer: Buffer): Promise<{ pageCount: number }> {
  if (buffer.length === 0 || buffer.length > MAX_PDF_BYTES || buffer.subarray(0, 5).toString() !== '%PDF-') {
    throw new Error('PDF must be a valid file no larger than 10 MB')
  }
  const source = buffer.toString('latin1')
  if (/\/(?:JavaScript|JS|AA|Launch|OpenAction)\b/i.test(source)) {
    throw new Error('PDF contains active content and cannot be used for signing')
  }
  const pdf = await PDFDocument.load(buffer, { updateMetadata: false })
  return { pageCount: pdf.getPageCount() }
}

export async function storeAgreementArtifact(
  em: EntityManager,
  scope: ArtifactScope,
  input: { kind: AgreementArtifact['kind']; fileName: string; contentType: string; buffer: Buffer },
): Promise<AgreementArtifact> {
  const factory = new StorageDriverFactory(em)
  const driver = await factory.resolveForPartition(PRIVATE_PARTITION, scope)
  const stored = await driver.store({
    partitionCode: PRIVATE_PARTITION,
    orgId: scope.organizationId,
    tenantId: scope.tenantId,
    fileName: input.fileName,
    buffer: input.buffer,
  })
  const artifact = em.create(AgreementArtifact, {
    id: randomUUID(),
    tenantId: scope.tenantId,
    organizationId: scope.organizationId,
    kind: input.kind,
    partitionCode: PRIVATE_PARTITION,
    storageDriver: driver.key,
    storagePath: stored.storagePath,
    contentType: input.contentType,
    byteSize: input.buffer.length,
    contentHash: sha256(input.buffer),
    fileName: input.fileName,
    createdAt: new Date(),
  })
  em.persist(artifact)
  return artifact
}

export async function readAgreementArtifact(em: EntityManager, artifactId: string, scope: ArtifactScope): Promise<Buffer> {
  const artifact = await em.findOne(AgreementArtifact, {
    id: artifactId,
    tenantId: scope.tenantId,
    organizationId: scope.organizationId,
  } as FilterQuery<AgreementArtifact>)
  if (!artifact) throw new Error('Agreement artifact not found')
  const factory = new StorageDriverFactory(em)
  const driver = factory.resolveForAttachment(artifact.storageDriver)
  const stored = await driver.read(artifact.partitionCode, artifact.storagePath)
  if (sha256(stored.buffer) !== artifact.contentHash) throw new Error('Agreement artifact integrity check failed')
  return stored.buffer
}

function fieldValueFor(field: EnvelopeField, signature: Signature | null): string {
  const value = signature?.fieldValuesJson?.[String(field.id)]
  if (typeof value === 'string' && value.trim()) return value.trim()
  if (field.fieldType === 'signature') return signature?.valueText ?? ''
  if (field.fieldType === 'date') return signature?.signedAt.toISOString().slice(0, 10) ?? ''
  return ''
}

export async function renderCompletedPdf(
  em: EntityManager,
  envelope: SigningEnvelope,
  version: AgreementVersion,
  fields: EnvelopeField[],
  signers: Signer[],
  signatures: Signature[],
  scope: ArtifactScope,
): Promise<Buffer> {
  let pdf: PDFDocument
  if (version.uploadedPdfArtifactId) {
    pdf = await PDFDocument.load(await readAgreementArtifact(em, version.uploadedPdfArtifactId, scope), { updateMetadata: false })
  } else {
    pdf = await PDFDocument.create()
    pdf.addPage([612, 792])
    const font = await pdf.embedFont(StandardFonts.Helvetica)
    const page = pdf.getPage(0)
    page.drawText('Agreement signed electronically', { x: 50, y: 720, size: 18, font, color: rgb(0.1, 0.1, 0.1) })
    page.drawText(version.contentHtml.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 2_000), { x: 50, y: 680, size: 10, font, maxWidth: 510, lineHeight: 14 })
  }
  const font = await pdf.embedFont(StandardFonts.Helvetica)
  const signatureBySigner = new Map(signatures.map((signature) => [String(signature.signerId), signature]))
  for (const field of fields) {
    const page = pdf.getPage(field.pageNumber - 1)
    if (!page) throw new Error('Agreement field page is outside the PDF')
    const size = page.getSize()
    const value = fieldValueFor(field, signatureBySigner.get(String(field.signerId)) ?? null)
    if (!value && field.required) throw new Error('Required agreement field is incomplete')
    if (!value) continue
    const x = field.x * size.width
    const y = size.height - ((field.y + field.height) * size.height)
    page.drawRectangle({ x, y, width: field.width * size.width, height: field.height * size.height, borderColor: rgb(0.15, 0.35, 0.7), borderWidth: 0.75, opacity: 0.08 })
    page.drawText(value.slice(0, 500), { x: x + 4, y: y + Math.max(4, field.height * size.height / 2 - 5), size: Math.max(8, Math.min(16, field.height * size.height * 0.45)), font, maxWidth: Math.max(20, field.width * size.width - 8) })
  }
  const last = pdf.getPages()[pdf.getPageCount() - 1]
  const footer = signers.map((signer) => `${signer.displayName} — ${signatureBySigner.get(String(signer.id))?.signedAt.toISOString() ?? 'pending'}`).join('\n')
  last.drawText(footer, { x: 50, y: 35, size: 7, font, maxWidth: last.getSize().width - 100, lineHeight: 9 })
  return Buffer.from(await pdf.save({ useObjectStreams: false }))
}

export async function createEvidenceCertificate(
  envelope: SigningEnvelope,
  version: AgreementVersion,
  signers: Signer[],
  signatures: Signature[],
): Promise<Buffer> {
  const pdf = await PDFDocument.create()
  const page = pdf.addPage([612, 792])
  const font = await pdf.embedFont(StandardFonts.Helvetica)
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold)
  page.drawText('Certificate of completion', { x: 50, y: 740, size: 20, font: bold, color: rgb(0.1, 0.1, 0.1) })
  const lines = [
    'Ordinary electronic signature evidence — not a qualified or advanced signature.',
    `Envelope: ${envelope.id}`,
    `Agreement version: ${version.id}`,
    `Document hash: ${version.contentHash}`,
    `Disclosure hash: ${sha256(version.disclosureText)}`,
    `Completed at: ${envelope.completedAt?.toISOString() ?? new Date().toISOString()}`,
    '',
    ...signers.map((signer) => {
      const signature = signatures.find((item) => String(item.signerId) === String(signer.id))
      return `${signer.displayName} <${signer.email}> — ${signature?.method ?? 'pending'} — ${signature?.signedAt.toISOString() ?? 'pending'}`
    }),
  ]
  page.drawText(lines.join('\n'), { x: 50, y: 700, size: 9, font, maxWidth: 510, lineHeight: 16 })
  return Buffer.from(await pdf.save({ useObjectStreams: false }))
}
