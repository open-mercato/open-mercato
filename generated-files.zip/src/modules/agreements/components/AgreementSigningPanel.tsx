'use client'

import * as React from 'react'
import { useT } from '@«redacted:high-entropy»'
import { apiCallOrThrow } from '@open-mercato/ui/backend/utils/apiCall'
import { Button } from '@open-mercato/ui/primitives/button'
import { Input } from '@open-mercato/ui/primitives/input'
import { Textarea } from '@open-mercato/ui/primitives/textarea'
import { Checkbox } from '@open-mercato/ui/primitives/checkbox'

type SignerDraft = { display_name: string; email: string; routing_order: number }
type FieldDraft = { signer_index: number; field_type: 'signature' | 'initials' | 'date' | 'text'; page_number: number; x: number; y: number; width: number; height: number; required: boolean; label: string }
type LinkResult = { signerId: string; displayName: string; email: string; link: string }

export default function AgreementSigningPanel({ agreementId, initialStatus }: { agreementId: string; initialStatus?: string }) {
  const t = useT()
  const [disclosure, setDisclosure] = React.useState('By signing, I agree to be bound by this agreement and consent to electronic signing.')
  const [signers, setSigners] = React.useState<SignerDraft[]>([{ display_name: '', email: '', routing_order: 1 }])
  const [fields, setFields] = React.useState<FieldDraft[]>([])
  const [published, setPublished] = React.useState(initialStatus === 'published')
  const [requireEmailVerification, setRequireEmailVerification] = React.useState(false)
  const [links, setLinks] = React.useState<LinkResult[]>([])
  const [message, setMessage] = React.useState<string | null>(null)
  const [busy, setBusy] = React.useState(false)

  const updateSigner = (index: number, key: keyof SignerDraft, value: string) => {
    setSigners((current) => current.map((signer, itemIndex) => itemIndex === index
      ? { ...signer, [key]: key === 'routing_order' ? Number(value) : value }
      : signer))
  }

  const publish = async () => {
    setBusy(true)
    setMessage(null)
    try {
      await apiCallOrThrow(`/api/agreements/agreements/${agreementId}/publish`, {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ disclosure_text: disclosure }),
      }, { errorMessage: t('agreements.errors.publish', 'Unable to publish agreement') })
      setPublished(true)
      setMessage(t('agreements.flash.published', 'Agreement published.'))
    } catch (error) {
      setMessage(error instanceof Error ? error.message : t('agreements.errors.publish', 'Unable to publish agreement'))
    } finally { setBusy(false) }
  }

  const send = async () => {
    setBusy(true)
    setMessage(null)
    try {
      const result = await apiCallOrThrow<{ envelopeId: string; links: LinkResult[] }>(`/api/agreements/agreements/${agreementId}/envelopes`, {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ signing_mode: 'sequential', require_email_verification: requireEmailVerification, signers, fields }),
      }, { errorMessage: t('agreements.errors.send', 'Unable to create signing request') })
      setLinks(result.result?.links ?? [])
      setMessage(t('agreements.flash.sent', 'Signing request created.'))
    } catch (error) {
      setMessage(error instanceof Error ? error.message : t('agreements.errors.send', 'Unable to create signing request'))
    } finally { setBusy(false) }
  }

  return (
    <section className="mt-6 space-y-4 rounded-lg border p-6">
      <div>
        <h2 className="text-xl font-semibold">{t('agreements.signingPanel.heading', 'Publish and send for signing')}</h2>
        <p className="text-sm text-muted-foreground">{t('agreements.signingPanel.description', 'Publishing freezes the agreement version used by every signer.')}</p>
      </div>
      <Textarea value={disclosure} onChange={(event) => setDisclosure(event.target.value)} maxLength={10_000} aria-label={t('agreements.signingPanel.disclosure', 'Signing disclosure')} />
      {!published ? <Button type="button" disabled={busy || !disclosure.trim()} onClick={() => void publish()}>{t('agreements.actions.publish', 'Publish immutable version')}</Button> : null}
      {published ? (
        <div className="space-y-3 border-t pt-4">
          <h3 className="font-medium">{t('agreements.signingPanel.signers', 'Signers')}</h3>
          {signers.map((signer, index) => (
            <div className="grid gap-2 md:grid-cols-[1fr_1fr_120px]" key={index}>
              <Input value={signer.display_name} onChange={(event) => updateSigner(index, 'display_name', event.target.value)} placeholder={t('agreements.signingPanel.name', 'Full name')} aria-label={t('agreements.signingPanel.name', 'Full name')} />
              <Input type="email" value={signer.email} onChange={(event) => updateSigner(index, 'email', event.target.value)} placeholder={t('agreements.signingPanel.email', 'Email address')} aria-label={t('agreements.signingPanel.email', 'Email address')} />
              <Input type="number" min={1} value={signer.routing_order} onChange={(event) => updateSigner(index, 'routing_order', event.target.value)} aria-label={t('agreements.signingPanel.order', 'Routing order')} />
            </div>
          ))}
          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="outline" onClick={() => setSigners((current) => [...current, { display_name: '', email: '', routing_order: current.length + 1 }])}>{t('agreements.actions.addSigner', 'Add signer')}</Button>
            <Button type="button" variant="outline" onClick={() => setFields((current) => [...current, { signer_index: 0, field_type: 'signature', page_number: 1, x: 0.1, y: 0.1, width: 0.3, height: 0.08, required: true, label: '' }])}>{t('agreements.actions.addField', 'Add PDF field')}</Button>
            <Button type="button" disabled={busy} onClick={() => void send()}>{t('agreements.actions.send', 'Create signing links')}</Button>
          </div>
          <label className="flex items-start gap-2 text-sm"><Checkbox checked={requireEmailVerification} onCheckedChange={(checked) => setRequireEmailVerification(checked === true)} /><span>{t('agreements.signingPanel.requireVerification', 'Require optional email verification before signing')}</span></label>
          {fields.length > 0 ? (
            <div className="space-y-3 border-t pt-4">
              <h3 className="font-medium">{t('agreements.signingPanel.fields', 'Positioned PDF fields')}</h3>
              <p className="text-xs text-muted-foreground">{t('agreements.signingPanel.fieldsHint', 'Coordinates use normalized page values from 0 to 1. These fields require an uploaded PDF.')}</p>
              {fields.map((field, index) => <div className="grid gap-2 rounded-md border p-3 md:grid-cols-4" key={index}>
                <select className="h-10 rounded-md border bg-background px-3 text-sm" value={field.field_type} aria-label={t('agreements.signingPanel.fieldType', 'Field type')} onChange={(event) => setFields((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, field_type: event.target.value as FieldDraft['field_type'] } : item))}>
                  <option value="signature">{t('agreements.signingPanel.signatureField', 'Signature')}</option>
                  <option value="initials">{t('agreements.signingPanel.initialsField', 'Initials')}</option>
                  <option value="date">{t('agreements.signingPanel.dateField', 'Date')}</option>
                  <option value="text">{t('agreements.signingPanel.textField', 'Text')}</option>
                </select>
                <Input type="number" min={0} max={signers.length - 1} value={field.signer_index} aria-label={t('agreements.signingPanel.fieldSigner', 'Signer number')} onChange={(event) => setFields((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, signer_index: Number(event.target.value) } : item))} />
                <Input type="number" min={1} value={field.page_number} aria-label={t('agreements.signingPanel.fieldPage', 'PDF page')} onChange={(event) => setFields((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, page_number: Number(event.target.value) } : item))} />
                {(['x', 'y', 'width', 'height'] as const).map((key) => <Input key={key} type="number" min={0.01} max={1} step={0.01} value={field[key]} aria-label={`${t('agreements.signingPanel.fieldCoordinate', 'Field')} ${key}`} onChange={(event) => setFields((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, [key]: Number(event.target.value) } : item))} />)}
                <Button type="button" variant="outline" onClick={() => setFields((current) => current.filter((_, itemIndex) => itemIndex !== index))}>{t('agreements.actions.removeField', 'Remove field')}</Button>
              </div>)}
            </div>
          ) : null}
        </div>
      ) : null}
      {message ? <p role="status" className="text-sm text-muted-foreground">{message}</p> : null}
      {links.length > 0 ? (
        <div className="space-y-2 border-t pt-4">
          <h3 className="font-medium">{t('agreements.signingPanel.links', 'Generated links')}</h3>
          {links.map((link) => <p key={link.signerId} className="break-all text-sm"><span className="font-medium">{link.displayName}</span>: {link.link}</p>)}
          <p className="text-xs text-muted-foreground">{t('agreements.signingPanel.linkWarning', 'These links are secrets. Share each link only with its intended signer.')}</p>
        </div>
      ) : null}
    </section>
  )
}
