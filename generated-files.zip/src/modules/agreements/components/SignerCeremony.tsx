'use client'

import * as React from 'react'
import { useT } from '@«redacted:high-entropy»'
import { readApiResultOrThrow, apiCallOrThrow } from '@open-mercato/ui/backend/utils/apiCall'
import { Button } from '@open-mercato/ui/primitives/button'
import { Input } from '@open-mercato/ui/primitives/input'
import { Checkbox } from '@open-mercato/ui/primitives/checkbox'

type SigningPayload = {
  signerId: string
  envelopeId: string
  title: string
  contentHtml: string
  disclosureText: string
  disclosureHash: string
  signingMode: 'sequential' | 'parallel'
  envelopeStatus: string
  signerStatus: string
  canSign: boolean
  displayName: string
  requireEmailVerification: boolean
  verified: boolean
  fields: Array<{ id: string; fieldType: 'signature' | 'initials' | 'date' | 'text'; pageNumber: number; x: number; y: number; width: number; height: number; required: boolean; label: string | null }>
  pdfDocumentUrl: string | null
  expiresAt: string | null
}

type Point = { x: number; y: number }

export default function SignerCeremony({ token }: { token: string }) {
  const t = useT()
  const [payload, setPayload] = React.useState<SigningPayload | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState<string | null>(null)
  const [method, setMethod] = React.useState<'typed' | 'drawn'>('typed')
  const [typedValue, setTypedValue] = React.useState('')
  const [consent, setConsent] = React.useState(false)
  const [submitting, setSubmitting] = React.useState(false)
  const [result, setResult] = React.useState<string | null>(null)
  const [declineReason, setDeclineReason] = React.useState('')
  const [verificationCode, setVerificationCode] = React.useState('')
  const [verificationRequested, setVerificationRequested] = React.useState(false)
  const [fieldValues, setFieldValues] = React.useState<Record<string, string>>({})
  const canvasRef = React.useRef<HTMLCanvasElement | null>(null)
  const pointsRef = React.useRef<Point[]>([])
  const drawingRef = React.useRef(false)

  const endpoint = `/api/public/agreement-signing/${encodeURIComponent(token)}`

  const load = React.useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      setPayload(await readApiResultOrThrow<SigningPayload>(endpoint, undefined, { errorMessage: t('agreements.sign.errors.load', 'Unable to load signing request') }))
    } catch (err) {
      setError(err instanceof Error ? err.message : t('agreements.sign.errors.load', 'Unable to load signing request'))
    } finally {
      setLoading(false)
    }
  }, [endpoint, t])

  React.useEffect(() => { void load() }, [load])

  const draw = React.useCallback((point: Point) => {
    const canvas = canvasRef.current
    const previous = pointsRef.current.at(-1)
    if (!canvas || !previous) return
    const context = canvas.getContext('2d')
    if (!context) return
    context.strokeStyle = '#171717'
    context.lineWidth = 2
    context.lineCap = 'round'
    context.beginPath()
    context.moveTo(previous.x, previous.y)
    context.lineTo(point.x, point.y)
    context.stroke()
  }, [])

  const pointerPoint = (event: React.PointerEvent<HTMLCanvasElement>): Point => {
    const rect = event.currentTarget.getBoundingClientRect()
    return { x: event.clientX - rect.left, y: event.clientY - rect.top }
  }

  const clearDrawing = () => {
    pointsRef.current = []
    const canvas = canvasRef.current
    const context = canvas?.getContext('2d')
    if (canvas && context) context.clearRect(0, 0, canvas.width, canvas.height)
  }

  const signatureValue = method === 'typed'
    ? typedValue
    : JSON.stringify({ width: 640, height: 180, points: pointsRef.current })

  const submit = async () => {
    if (!payload) return
    setSubmitting(true)
    setError(null)
    try {
      await apiCallOrThrow(endpoint, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ method, value_text: signatureValue, field_values: fieldValues, consent_accepted: true, disclosure_hash: payload.disclosureHash }),
      }, { errorMessage: t('agreements.sign.errors.submit', 'Unable to record signature') })
      setResult(t('agreements.sign.complete', 'Your signature has been recorded.'))
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : t('agreements.sign.errors.submit', 'Unable to record signature'))
    } finally {
      setSubmitting(false)
    }
  }

  const requestVerification = async () => {
    if (!payload) return
    setSubmitting(true)
    setError(null)
    try {
      await apiCallOrThrow(`${endpoint}/verification/request`, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ signer_id: payload.signerId, envelope_id: payload.envelopeId }),
      }, { errorMessage: t('agreements.sign.errors.verificationRequest', 'Unable to send the verification code') })
      setVerificationRequested(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : t('agreements.sign.errors.verificationRequest', 'Unable to send the verification code'))
    } finally { setSubmitting(false) }
  }

  const confirmVerification = async () => {
    if (!payload) return
    setSubmitting(true)
    setError(null)
    try {
      await apiCallOrThrow(`${endpoint}/verification/confirm`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-agreement-signer-id': payload.signerId, 'x-agreement-envelope-id': payload.envelopeId },
        body: JSON.stringify({ code: verificationCode }),
      }, { errorMessage: t('agreements.sign.errors.verificationConfirm', 'Unable to verify the email address') })
      setPayload((current) => current ? { ...current, verified: true } : current)
      setVerificationRequested(false)
    } catch (err) {
      setError(err instanceof Error ? err.message : t('agreements.sign.errors.verificationConfirm', 'Unable to verify the email address'))
    } finally { setSubmitting(false) }
  }

  const decline = async () => {
    if (!declineReason.trim()) return
    setSubmitting(true)
    setError(null)
    try {
      await apiCallOrThrow(`${endpoint}/decline`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ reason: declineReason }),
      }, { errorMessage: t('agreements.sign.errors.decline', 'Unable to decline request') })
      setResult(t('agreements.sign.declined', 'You declined this signing request.'))
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : t('agreements.sign.errors.decline', 'Unable to decline request'))
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) return <p className="text-sm text-muted-foreground">{t('agreements.sign.loading', 'Loading agreement…')}</p>
  if (error && !payload) return <div role="alert" className="rounded-md border border-destructive/40 p-4 text-sm text-destructive">{error}</div>
  if (!payload) return null

  const inactive = payload.signerStatus === 'signed' || payload.signerStatus === 'declined' || payload.envelopeStatus === 'completed' || payload.envelopeStatus === 'declined'
  const waiting = !payload.canSign && payload.signerStatus !== 'signed' && payload.signerStatus !== 'declined'
  const verificationBlocked = payload.requireEmailVerification && !payload.verified

  return (
    <main className="mx-auto max-w-4xl space-y-6 px-4 py-8">
      <header className="space-y-2">
        <p className="text-sm text-muted-foreground">{t('agreements.sign.greeting', 'Hello {name}', { name: payload.displayName })}</p>
        <h1 className="text-3xl font-semibold tracking-tight">{payload.title}</h1>
        {payload.expiresAt ? <p className="text-sm text-muted-foreground">{t('agreements.sign.expires', 'Expires {date}', { date: new Date(payload.expiresAt).toLocaleString() })}</p> : null}
      </header>

      {/* The API sanitizes rich text before returning it; this is the public read-only rendering of that sanitized value. */}
      <article className="prose max-w-none rounded-lg border bg-background p-6" dangerouslySetInnerHTML={{ __html: payload.contentHtml }} />
      {payload.pdfDocumentUrl ? <a className="text-sm underline" href={payload.pdfDocumentUrl} target="_blank" rel="noreferrer">{t('agreements.sign.openPdf', 'Open the source PDF')}</a> : null}

      <section className="space-y-4 rounded-lg border p-6" aria-labelledby="disclosure-heading">
        <h2 id="disclosure-heading" className="text-xl font-semibold">{t('agreements.sign.disclosureHeading', 'Electronic signature disclosure')}</h2>
        <p className="whitespace-pre-wrap text-sm text-muted-foreground">{payload.disclosureText}</p>
        {result ? <p role="status" className="rounded-md bg-muted p-3 text-sm">{result}</p> : null}
        {error ? <p role="alert" className="text-sm text-destructive">{error}</p> : null}
        {!inactive && !waiting ? (
          <>
            {verificationBlocked ? (
              <div className="space-y-3 rounded-md border p-4">
                <p className="text-sm">{t('agreements.sign.verifyDescription', 'Verify control of your email address before signing. This verifies mailbox access and is not a qualified identity proof.')}</p>
                {!verificationRequested ? <Button type="button" disabled={submitting} onClick={() => void requestVerification()}>{t('agreements.sign.requestVerification', 'Send verification code')}</Button> : (
                  <div className="flex flex-wrap gap-2">
                    <Input value={verificationCode} onChange={(event) => setVerificationCode(event.target.value)} inputMode="numeric" maxLength={6} placeholder={t('agreements.sign.verificationCode', '6-digit code')} aria-label={t('agreements.sign.verificationCode', '6-digit code')} />
                    <Button type="button" disabled={submitting || verificationCode.length !== 6} onClick={() => void confirmVerification()}>{t('agreements.sign.verify', 'Verify email')}</Button>
                  </div>
                )}
              </div>
            ) : null}
            {!verificationBlocked && payload.fields.length > 0 ? (
              <div className="space-y-3 rounded-md border p-4">
                <h3 className="font-medium">{t('agreements.sign.fieldsHeading', 'Required document fields')}</h3>
                {payload.fields.map((field) => <Input key={field.id} value={fieldValues[field.id] ?? ''} onChange={(event) => setFieldValues((current) => ({ ...current, [field.id]: event.target.value }))} placeholder={field.label ?? field.fieldType} aria-label={field.label ?? field.fieldType} />)}
              </div>
            ) : null}
            {!verificationBlocked ? <>
            <div className="flex gap-2" role="tablist" aria-label={t('agreements.sign.method', 'Signature method')}>
              <Button type="button" variant={method === 'typed' ? 'default' : 'outline'} onClick={() => setMethod('typed')}>{t('agreements.sign.typed', 'Type signature')}</Button>
              <Button type="button" variant={method === 'drawn' ? 'default' : 'outline'} onClick={() => setMethod('drawn')}>{t('agreements.sign.drawn', 'Draw signature')}</Button>
            </div>
            {method === 'typed' ? (
              <Input value={typedValue} onChange={(event) => setTypedValue(event.target.value)} placeholder={t('agreements.sign.signaturePlaceholder', 'Your full name')} aria-label={t('agreements.sign.signatureLabel', 'Signature')} />
            ) : (
              <div className="space-y-2">
                <canvas
                  ref={canvasRef}
                  width={640}
                  height={180}
                  className="h-44 w-full touch-none rounded-md border bg-white"
                  aria-label={t('agreements.sign.drawingLabel', 'Draw your signature')}
                  onPointerDown={(event) => { event.currentTarget.setPointerCapture(event.pointerId); drawingRef.current = true; const point = pointerPoint(event); pointsRef.current.push(point) }}
                  onPointerMove={(event) => { if (!drawingRef.current) return; const point = pointerPoint(event); pointsRef.current.push(point); draw(point) }}
                  onPointerUp={() => { drawingRef.current = false }}
                  onPointerCancel={() => { drawingRef.current = false }}
                />
                <Button type="button" variant="outline" onClick={clearDrawing}>{t('agreements.sign.clear', 'Clear')}</Button>
              </div>
            )}
            <label className="flex items-start gap-3 text-sm">
              <Checkbox checked={consent} onCheckedChange={(checked) => setConsent(checked === true)} aria-label={t('agreements.sign.consentLabel', 'Consent to electronic signature')} />
              <span>{t('agreements.sign.consent', 'I consent to sign this agreement electronically and agree that this signature is associated with this document.')}</span>
            </label>
            <Button type="button" disabled={submitting || !consent || !signatureValue.trim()} onClick={() => void submit()}>{submitting ? t('agreements.sign.submitting', 'Submitting…') : t('agreements.sign.submit', 'Sign agreement')}</Button>
            <div className="space-y-2 border-t pt-4">
              <label htmlFor="decline-reason" className="text-sm font-medium">{t('agreements.sign.declineReason', 'Decline reason')}</label>
              <Input id="decline-reason" value={declineReason} onChange={(event) => setDeclineReason(event.target.value)} />
            <Button type="button" variant="outline" disabled={submitting || !declineReason.trim()} onClick={() => void decline()}>{t('agreements.sign.decline', 'Decline request')}</Button>
            </div>
            </> : null}
          </>
        ) : (
          <p className="text-sm text-muted-foreground">{waiting ? t('agreements.sign.waiting', 'This request will become available after the previous signer completes.') : t(`agreements.sign.status.${payload.signerStatus}`, 'This signing request is no longer active.')}</p>
        )}
        {payload.requireEmailVerification ? <p className="text-xs text-muted-foreground">{t('agreements.sign.emailVerification', 'Email verification is configured for this request and may be added by the delivery provider.')}</p> : null}
      </section>
    </main>
  )
}
