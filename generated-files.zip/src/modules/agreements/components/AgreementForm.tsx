'use client'

import * as React from 'react'
import { useRouter } from 'next/navigation'
import { CrudForm, type CrudField } from '@open-mercato/ui/backend/CrudForm'
import { ErrorMessage, RecordNotFoundState } from '@open-mercato/ui/backend/detail'
import { createCrud, deleteCrud, fetchCrudList, updateCrud } from '@open-mercato/ui/backend/utils/crud'
import { pushWithFlash } from '@open-mercato/ui/backend/utils/flash'
import { surfaceRecordConflict } from '@open-mercato/ui/backend/conflicts'
import { useT } from '@«redacted:high-entropy»'
import { RichEditor } from '@open-mercato/ui/primitives/rich-editor'
import AgreementSigningPanel from './AgreementSigningPanel'

const LIST_HREF = '/backend/agreements'
const API_PATH = 'agreements/agreements'
const ENTITY_ID = 'agreements:agreement'

export type AgreementFormValues = {
  id?: string
  title: string
  description: string
  draft_content_html: string
  pdf_base64?: string
  status?: string
  updatedAt?: string | null
}

export function toAgreementFormValues(item: Record<string, unknown>): AgreementFormValues {
  return {
    id: String(item.id),
    title: typeof item.title === 'string' ? item.title : '',
    description: typeof item.description === 'string' ? item.description : '',
    draft_content_html: typeof item.draft_content_html === 'string' ? item.draft_content_html : '',
    status: typeof item.status === 'string' ? item.status : 'draft',
    updatedAt: typeof item.updatedAt === 'string' ? item.updatedAt : null,
  }
}

function useAgreementFields(t: ReturnType<typeof useT>): CrudField[] {
  return React.useMemo(() => [
    {
      id: 'title',
      label: t('agreements.form.title', 'Title'),
      type: 'text' as const,
      required: true,
      placeholder: t('agreements.form.titlePlaceholder', 'e.g. Terms of service'),
    },
    {
      id: 'description',
      label: t('agreements.form.description', 'Description'),
      type: 'textarea' as const,
      rows: 3,
    },
    {
      id: 'draft_content_html',
      label: t('agreements.form.content', 'Agreement content'),
      type: 'custom' as const,
      required: false,
      component: ({ value, setValue, id, error }) => (
        <div className="space-y-2">
          <RichEditor
            id={id}
            value={typeof value === 'string' ? value : ''}
            onChange={setValue}
            variant="standard"
            minRows={18}
            placeholder={t('agreements.form.contentPlaceholder', 'Paste or write the agreement text…')}
          />
          {error ? <p className="text-sm text-destructive">{error}</p> : null}
        </div>
      ),
    },
    {
      id: 'pdf_base64',
      label: t('agreements.form.pdf', 'Optional PDF source'),
      type: 'custom' as const,
      component: ({ setValue, id }) => (
        <div className="space-y-2">
          <input
            id={id}
            type="file"
            accept="application/pdf,.pdf"
            onChange={(event) => {
              const file = event.target.files?.[0]
              if (!file) return
              const reader = new FileReader()
              reader.onload = () => setValue(typeof reader.result === 'string' ? reader.result : '')
              reader.readAsDataURL(file)
            }}
          />
          <p className="text-xs text-muted-foreground">{t('agreements.form.pdfHint', 'Use a PDF up to 10 MB. Positioned fields can be added when sending.')}</p>
        </div>
      ),
    },
  ], [t])
}

export function AgreementCreateForm() {
  const t = useT()
  const fields = useAgreementFields(t)
  const successRedirect = `${LIST_HREF}?flash=${encodeURIComponent(t('agreements.flash.created', 'Agreement created'))}&type=success`
  return (
    <CrudForm<AgreementFormValues>
      title={t('agreements.form.createHeading', 'New agreement')}
      backHref={LIST_HREF}
      entityId={ENTITY_ID}
      fields={fields}
      initialValues={{ title: '', description: '', draft_content_html: '', pdf_base64: '' }}
      submitLabel={t('agreements.actions.create', 'Create agreement')}
      cancelHref={LIST_HREF}
      successRedirect={successRedirect}
      onSubmit={async (values) => { await createCrud(API_PATH, values) }}
    />
  )
}

export function AgreementEditForm({ id }: { id: string }) {
  const t = useT()
  const router = useRouter()
  const fields = useAgreementFields(t)
  const [initial, setInitial] = React.useState<AgreementFormValues | null>(null)
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState<string | null>(null)
  const [notFound, setNotFound] = React.useState(false)

  React.useEffect(() => {
    let cancelled = false
    setLoading(true)
    fetchCrudList<Record<string, unknown>>(API_PATH, { ids: id, pageSize: 1 })
      .then((result) => {
        const item = result.items?.[0]
        if (!item) setNotFound(true)
        else setInitial(toAgreementFormValues(item))
      })
      .catch((err) => {
        if (!cancelled) {
          if ((err as { status?: number }).status === 404) setNotFound(true)
          else setError(err instanceof Error ? err.message : t('agreements.errors.load', 'Unable to load agreement'))
        }
      })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [id, t])

  if (notFound) return <RecordNotFoundState label={t('agreements.errors.notFound', 'Agreement not found')} backHref={LIST_HREF} backLabel={t('agreements.actions.back', 'Back to agreements')} />
  if (error) return <ErrorMessage label={error} />

  const fallback: AgreementFormValues = { id, title: '', description: '', draft_content_html: '', pdf_base64: '', status: 'draft', updatedAt: null }
  return <>
    <CrudForm<AgreementFormValues>
        title={t('agreements.form.editHeading', 'Edit agreement')}
        backHref={LIST_HREF}
        entityId={ENTITY_ID}
        fields={fields}
        initialValues={initial ?? fallback}
        submitLabel={t('agreements.actions.save', 'Save changes')}
        cancelHref={LIST_HREF}
        isLoading={loading}
        loadingMessage={t('agreements.loading', 'Loading agreement…')}
        onSubmit={async (values) => {
          try {
            await updateCrud(API_PATH, values)
            pushWithFlash(router, LIST_HREF, t('agreements.flash.saved', 'Agreement saved'), 'success')
          } catch (err) {
            if (surfaceRecordConflict(err, t)) return
            throw err
          }
        }}
        onDelete={async () => {
          try {
            await deleteCrud(API_PATH, id)
            pushWithFlash(router, LIST_HREF, t('agreements.flash.archived', 'Agreement archived'), 'success')
          } catch (err) {
            if (surfaceRecordConflict(err, t)) return
            throw err
          }
        }}
      />
      {initial?.status === 'draft' || initial?.status === 'published' ? <AgreementSigningPanel agreementId={id} initialStatus={initial.status} /> : null}
    </>
}
