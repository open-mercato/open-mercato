'use client'

import * as React from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import type { ColumnDef, SortingState } from '@tanstack/react-table'
import { DataTable } from '@open-mercato/ui/backend/DataTable'
import { RowActions } from '@open-mercato/ui/backend/RowActions'
import { Button } from '@open-mercato/ui/primitives/button'
import { StatusBadge, type StatusBadgeVariant } from '@open-mercato/ui/primitives/status-badge'
import { fetchCrudList, deleteCrud } from '@open-mercato/ui/backend/utils/crud'
import { buildOptimisticLockHeader } from '@open-mercato/ui/backend/utils/optimisticLock'
import { withScopedApiRequestHeaders } from '@open-mercato/ui/backend/utils/apiCall'
import { surfaceRecordConflict } from '@open-mercato/ui/backend/conflicts'
import { flash } from '@open-mercato/ui/backend/FlashMessages'
import { useConfirmDialog } from '@open-mercato/ui/backend/confirm-dialog'
import { useT } from '@«redacted:high-entropy»'

export type AgreementRow = {
  id: string
  title: string
  status: 'draft' | 'published' | 'archived'
  updatedAt?: string | null
}

function statusVariant(status: AgreementRow['status']): StatusBadgeVariant {
  if (status === 'published') return 'success'
  if (status === 'archived') return 'neutral'
  return 'warning'
}

export default function AgreementsTable() {
  const t = useT()
  const router = useRouter()
  const queryClient = useQueryClient()
  const { confirm, ConfirmDialogElement } = useConfirmDialog()
  const [sorting, setSorting] = React.useState<SortingState>([{ id: 'updated_at', desc: true }])
  const [page, setPage] = React.useState(1)
  const [title, setTitle] = React.useState('')
  const queryParams = React.useMemo(() => ({
    page,
    pageSize: 50,
    title: title || undefined,
    sortField: sorting[0]?.id || 'updated_at',
    sortDir: sorting[0]?.desc ? 'desc' : 'asc',
  }), [page, sorting, title])
  const { data, isLoading, error } = useQuery({
    queryKey: ['agreements', queryParams],
    queryFn: () => fetchCrudList<AgreementRow>('agreements/agreements', queryParams),
  })

  const columns = React.useMemo<ColumnDef<AgreementRow>[]>(() => [
    { accessorKey: 'title', header: t('agreements.table.title', 'Title'), meta: { priority: 1 } },
    {
      accessorKey: 'status',
      header: t('agreements.table.status', 'Status'),
      meta: { priority: 2 },
      cell: ({ row }) => (
        <StatusBadge variant={statusVariant(row.original.status)} dot>
          {t(`agreements.status.${row.original.status}`, row.original.status)}
        </StatusBadge>
      ),
    },
  ], [t])

  return (
    <>
      <DataTable
        title={t('agreements.table.heading', 'Agreements')}
        actions={<Button asChild><Link href="/backend/agreements/create">{t('agreements.actions.create', 'New agreement')}</Link></Button>}
        columns={columns}
        data={data?.items ?? []}
        entityId="agreements:agreement"
        sortable
        sorting={sorting}
        onSortingChange={setSorting}
        searchValue={title}
        onSearchChange={(value) => { setTitle(value); setPage(1) }}
        searchAlign="right"
        rowActions={(row) => (
          <RowActions items={[
            { label: t('agreements.actions.edit', 'Edit'), href: `/backend/agreements/${row.id}/edit` },
            ...(row.status === 'draft' ? [{
              label: t('agreements.actions.archive', 'Archive'),
              destructive: true,
              onSelect: async () => {
                if (!await confirm({ title: t('agreements.confirm.archive', 'Archive this agreement?'), variant: 'destructive' })) return
                try {
                  await withScopedApiRequestHeaders(buildOptimisticLockHeader(row.updatedAt), () => deleteCrud('agreements/agreements', row.id))
                  flash(t('agreements.flash.archived', 'Agreement archived'), 'success')
                  await queryClient.invalidateQueries({ queryKey: ['agreements'] })
                } catch (err) {
                  if (surfaceRecordConflict(err, t)) {
                    await queryClient.invalidateQueries({ queryKey: ['agreements'] })
                    return
                  }
                  flash(err instanceof Error ? err.message : t('agreements.errors.archive', 'Unable to archive agreement'), 'error')
                }
              },
            }] : []),
          ]} />
        )}
        pagination={{ page, pageSize: 50, total: data?.total ?? 0, totalPages: data?.totalPages ?? 0, onPageChange: setPage }}
        isLoading={isLoading}
        error={error instanceof Error ? error.message : undefined}
        onRowClick={(row) => { router.push(`/backend/agreements/${row.id}/edit`) }}
      />
      {ConfirmDialogElement}
    </>
  )
}
