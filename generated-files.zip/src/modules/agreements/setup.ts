import type { ModuleSetupConfig } from '@open-mercato/shared/modules/setup'

export const setup: ModuleSetupConfig = {
  defaultRoleFeatures: {
    superadmin: ['agreements.*'],
    admin: ['agreements.*'],
    employee: ['agreements.view'],
  },
}

export default setup
