export const features = [
  { id: 'agreements.view', title: 'View agreements', module: 'agreements' },
  {
    id: 'agreements.manage',
    title: 'Manage agreements',
    module: 'agreements',
    dependsOn: ['agreements.view'],
  },
]

export default features
