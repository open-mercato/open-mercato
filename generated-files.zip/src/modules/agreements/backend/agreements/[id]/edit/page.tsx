import { AgreementEditForm } from '../../../../components/AgreementForm'

export default function AgreementEditPage({ params }: { params: { id: string } }) {
  return <AgreementEditForm id={params.id} />
}
