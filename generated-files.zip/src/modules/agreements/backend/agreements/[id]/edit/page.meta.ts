export const metadata = {
  requireAuth: true,
  requireFeatures: ['agreements.manage'],
  pageTitle: 'Edit agreement',
  pageTitleKey: 'agreements.form.editHeading',
  pageGroup: 'Agreements',
  pageGroupKey: 'agreements.page.group',
  pageOrder: 142,
  icon: 'file-edit',
  breadcrumb: [
    { label: 'Agreements', labelKey: 'agreements.page.title', href: '/backend/agreements' },
    { label: 'Edit agreement', labelKey: 'agreements.form.editHeading' },
  ],
}
