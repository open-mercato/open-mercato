import AgreementsTable from '../../components/AgreementsTable'

export default function AgreementsPage() {
  return <AgreementsTable />
}
