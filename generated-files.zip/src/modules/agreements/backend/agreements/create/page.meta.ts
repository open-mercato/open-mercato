export const metadata = {
  requireAuth: true,
  requireFeatures: ['agreements.manage'],
  pageTitle: 'New agreement',
  pageTitleKey: 'agreements.form.createHeading',
  pageGroup: 'Agreements',
  pageGroupKey: 'agreements.page.group',
  pageOrder: 141,
  icon: 'file-text',
  breadcrumb: [
    { label: 'Agreements', labelKey: 'agreements.page.title', href: '/backend/agreements' },
    { label: 'New agreement', labelKey: 'agreements.form.createHeading' },
  ],
}
