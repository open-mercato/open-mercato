import { AgreementCreateForm } from '../../../components/AgreementForm'

export default function AgreementCreatePage() {
  return <AgreementCreateForm />
}
