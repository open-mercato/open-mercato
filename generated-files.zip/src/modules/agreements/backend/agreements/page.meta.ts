export const metadata = {
  requireAuth: true,
  requireFeatures: ['agreements.view'],
  pageTitle: 'Agreements',
  pageTitleKey: 'agreements.page.title',
  pageGroup: 'Agreements',
  pageGroupKey: 'agreements.page.group',
  pageOrder: 140,
  icon: 'file-text',
  breadcrumb: [{ label: 'Agreements', labelKey: 'agreements.page.title' }],
}
