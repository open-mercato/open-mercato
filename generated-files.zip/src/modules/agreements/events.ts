import { createModuleEvents } from '@open-mercato/shared/modules/events'

const events = [
  { id: 'agreements.agreement.created', label: 'Agreement created', entity: 'agreement', category: 'crud' },
  { id: 'agreements.agreement.updated', label: 'Agreement updated', entity: 'agreement', category: 'crud' },
  { id: 'agreements.agreement.deleted', label: 'Agreement archived', entity: 'agreement', category: 'crud' },
  { id: 'agreements.version.published', label: 'Agreement version published', entity: 'agreement_version', category: 'lifecycle' },
  { id: 'agreements.envelope.sent', label: 'Signing envelope sent', entity: 'envelope', category: 'lifecycle' },
  { id: 'agreements.signer.viewed', label: 'Signer viewed agreement', entity: 'signer', category: 'lifecycle' },
  { id: 'agreements.signer.signed', label: 'Signer signed agreement', entity: 'signer', category: 'lifecycle' },
  { id: 'agreements.signer.declined', label: 'Signer declined agreement', entity: 'signer', category: 'lifecycle' },
  { id: 'agreements.envelope.completed', label: 'Signing envelope completed', entity: 'envelope', category: 'lifecycle' },
  { id: 'agreements.evidence.ready', label: 'Signing evidence ready', entity: 'envelope', category: 'lifecycle' },
  { id: 'agreements.evidence.failed', label: 'Signing evidence finalization failed', entity: 'envelope', category: 'lifecycle' },
  { id: 'agreements.signer.verification.requested', label: 'Signer verification requested', entity: 'signer', category: 'lifecycle' },
  { id: 'agreements.signer.verification.completed', label: 'Signer verification completed', entity: 'signer', category: 'lifecycle' },
] as const

export const eventsConfig = createModuleEvents({ moduleId: 'agreements', events })
export const emitAgreementsEvent = eventsConfig.emit
export type AgreementEventId = typeof events[number]['id']

export default eventsConfig
