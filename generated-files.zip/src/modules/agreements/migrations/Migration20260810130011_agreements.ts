import { Migration } from '@mikro-orm/migrations';

export class Migration«redacted:phone»_agreements extends Migration {

  override name = 'Migration«redacted:phone»';

  override up(): void | Promise<void> {
    this.addSql(`create table "agreements" ("id" uuid not null default gen_random_uuid(), "tenant_id" uuid not null, "organization_id" uuid not null, "title" text not null, "description" text null, "draft_content_html" text not null, "status" text not null default 'draft', "published_version_id" uuid null, "created_by_user_id" uuid null, "created_at" timestamptz not null, "updated_at" timestamptz not null, "deleted_at" timestamptz null, primary key ("id"));`);
    this.addSql(`create index "agreements_tenant_id_organization_id_status_index" on "agreements" ("tenant_id", "organization_id", "status");`);

    this.addSql(`create table "agreement_versions" ("id" uuid not null default gen_random_uuid(), "agreement_id" uuid not null, "tenant_id" uuid not null, "organization_id" uuid not null, "version_number" int not null, "content_html" text not null, "content_hash" text not null, "disclosure_text" text not null, "published_at" timestamptz not null, "published_by_user_id" uuid null, "created_at" timestamptz not null, primary key ("id"));`);
    this.addSql(`create index "agreement_versions_tenant_id_organization_id_agreement_id_index" on "agreement_versions" ("tenant_id", "organization_id", "agreement_id");`);
    this.addSql(`alter table "agreement_versions" add constraint "agreement_versions_scope_number_unique" unique ("tenant_id", "organization_id", "agreement_id", "version_number");`);

    this.addSql(`create table "agreement_audit_events" ("id" uuid not null default gen_random_uuid(), "envelope_id" uuid not null, "signer_id" uuid null, "tenant_id" uuid not null, "organization_id" uuid not null, "event_type" text not null, "actor_kind" text not null, "actor_user_id" uuid null, "metadata_json" jsonb null, "previous_hash" text null, "event_hash" text not null, "created_at" timestamptz not null, primary key ("id"));`);
    this.addSql(`create index "agreement_audit_events_tenant_id_organization_id_e_cd148_index" on "agreement_audit_events" ("tenant_id", "organization_id", "envelope_id", "created_at");`);

    this.addSql(`create table "agreement_signatures" ("id" uuid not null default gen_random_uuid(), "envelope_id" uuid not null, "signer_id" uuid not null, "tenant_id" uuid not null, "organization_id" uuid not null, "method" text not null default 'typed', "value_text" text not null, "consent_accepted" boolean not null default false, "disclosure_hash" text not null, "document_hash" text not null, "signed_at" timestamptz not null, "ip_address" text null, "user_agent" text null, "created_at" timestamptz not null, primary key ("id"));`);
    this.addSql(`alter table "agreement_signatures" add constraint "agreement_signatures_signer_unique" unique ("signer_id");`);

    this.addSql(`create table "agreement_signers" ("id" uuid not null default gen_random_uuid(), "envelope_id" uuid not null, "tenant_id" uuid not null, "organization_id" uuid not null, "display_name" text not null, "email" text not null, "routing_order" int not null, "status" text not null default 'pending', "token_hash" text not null, "verified_at" timestamptz null, "signed_at" timestamptz null, "declined_at" timestamptz null, "decline_reason" text null, "created_at" timestamptz not null, "updated_at" timestamptz not null, primary key ("id"));`);
    this.addSql(`create index "agreement_signers_tenant_id_organization_id_envelo_eab16_index" on "agreement_signers" ("tenant_id", "organization_id", "envelope_id", "status");`);
    this.addSql(`alter table "agreement_signers" add constraint "agreement_signers_envelope_order_unique" unique ("envelope_id", "routing_order");`);
    this.addSql(`alter table "agreement_signers" add constraint "agreement_signers_token_hash_unique" unique ("token_hash");`);

    this.addSql(`create table "agreement_envelopes" ("id" uuid not null default gen_random_uuid(), "agreement_id" uuid not null, "agreement_version_id" uuid not null, "tenant_id" uuid not null, "organization_id" uuid not null, "status" text not null default 'draft', "signing_mode" text not null default 'sequential', "require_email_verification" boolean not null default false, "expires_at" timestamptz null, "sent_at" timestamptz null, "completed_at" timestamptz null, "created_by_user_id" uuid null, "created_at" timestamptz not null, "updated_at" timestamptz not null, "deleted_at" timestamptz null, primary key ("id"));`);
    this.addSql(`create index "agreement_envelopes_tenant_id_organization_id_status_index" on "agreement_envelopes" ("tenant_id", "organization_id", "status");`);
  }

}
