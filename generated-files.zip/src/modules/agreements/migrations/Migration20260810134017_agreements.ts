import { Migration } from '@mikro-orm/migrations';

export class «redacted:high-entropy» extends Migration {

  override name = 'Migration«redacted:phone»';

  override up(): void | Promise<void> {
    this.addSql(`create table "agreement_artifacts" ("id" uuid not null default gen_random_uuid(), "tenant_id" uuid not null, "organization_id" uuid not null, "kind" text not null, "partition_code" text not null default 'privateAttachments', "storage_driver" text not null default 'local', "storage_path" text not null, "content_type" text not null, "byte_size" int not null, "content_hash" text not null, "file_name" text not null, "created_at" timestamptz not null, primary key ("id"));`);
    this.addSql(`create index "agreement_artifacts_tenant_id_organization_id_kind_index" on "agreement_artifacts" ("tenant_id", "organization_id", "kind");`);

    this.addSql(`create table "agreement_envelope_fields" ("id" uuid not null default gen_random_uuid(), "envelope_id" uuid not null, "signer_id" uuid not null, "tenant_id" uuid not null, "organization_id" uuid not null, "field_type" text not null, "page_number" int not null, "x" numeric(10,6) not null, "y" numeric(10,6) not null, "width" numeric(10,6) not null, "height" numeric(10,6) not null, "required" boolean not null default true, "label" text null, "created_at" timestamptz not null, primary key ("id"));`);
    this.addSql(`create index "agreement_envelope_fields_tenant_id_organization_i_e6c4c_index" on "agreement_envelope_fields" ("tenant_id", "organization_id", "envelope_id", "signer_id");`);

    this.addSql(`alter table "agreements" add "draft_pdf_artifact_id" uuid null;`);

    this.addSql(`alter table "agreement_versions" add "source_mode" text not null default 'rich_text', add "uploaded_pdf_artifact_id" uuid null;`);

    this.addSql(`alter table "agreement_signatures" add "field_values_json" jsonb null;`);

    this.addSql(`alter table "agreement_signers" add "verification_code_hash" text null, add "verification_expires_at" timestamptz null, add "verification_attempts" int not null default 0, add "verification_locked_until" timestamptz null;`);

    this.addSql(`alter table "agreement_envelopes" add "final_artifact_id" uuid null, add "certificate_artifact_id" uuid null;`);
  }

  override down(): void | Promise<void> {
    this.addSql(`drop table if exists "agreement_envelope_fields";`);
    this.addSql(`drop table if exists "agreement_artifacts";`);
    this.addSql(`alter table "agreement_envelopes" drop column "final_artifact_id", drop column "certificate_artifact_id";`);

    this.addSql(`alter table "agreement_signatures" drop column "field_values_json";`);

    this.addSql(`alter table "agreement_signers" drop column "verification_code_hash", drop column "verification_expires_at", drop column "verification_attempts", drop column "verification_locked_until";`);

    this.addSql(`alter table "agreement_versions" drop column "source_mode", drop column "uploaded_pdf_artifact_id";`);

    this.addSql(`alter table "agreements" drop column "draft_pdf_artifact_id";`);
  }

}
