import { z } from 'zod'

const richTextSchema = z.string().trim().max(150_000).default('')
const pdfBase64Schema = z.string().regex(/^(?:data:application\/pdf;base64,)?[A-Za-z0-9+/=\r\n]+$/, 'Invalid PDF payload').max(14_000_000).optional()

export const envelopeFieldSchema = z.object({
  signer_id: z.string().uuid().optional(),
  signer_index: z.number().int().min(0).max(49).optional(),
  field_type: z.enum(['signature', 'initials', 'date', 'text']),
  page_number: z.number().int().min(1).max(10_000),
  x: z.number().min(0).max(1),
  y: z.number().min(0).max(1),
  width: z.number().gt(0).max(1),
  height: z.number().gt(0).max(1),
  required: z.boolean().default(true),
  label: z.string().trim().max(200).nullable().optional(),
}).refine((value) => value.signer_id || value.signer_index !== undefined, { message: 'A field signer is required' })

export const agreementListSchema = z.object({
  id: z.string().uuid().optional(),
  ids: z.string().optional(),
  title: z.string().max(200).optional(),
  status: z.enum(['draft', 'published', 'archived']).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(50),
  sortField: z.enum(['title', 'status', 'created_at', 'updated_at']).default('updated_at'),
  sortDir: z.enum(['asc', 'desc']).default('desc'),
}).passthrough()

export const agreementCreateSchema = z.object({
  id: z.string().uuid().optional(),
  title: z.string().trim().min(1).max(200),
  description: z.string().max(2_000).nullable().optional(),
  draft_content_html: richTextSchema,
  pdf_base64: pdfBase64Schema,
  pdf_file_name: z.string().trim().max(255).optional(),
})

export const agreementUpdateSchema = agreementCreateSchema.extend({
  id: z.string().uuid(),
  expected_updated_at: z.string().min(1).optional(),
})

export const agreementDeleteSchema = z.object({ id: z.string().uuid() })

export const publishAgreementSchema = z.object({
  id: z.string().uuid(),
  disclosure_text: z.string().trim().min(1).max(10_000),
})

export const signerInputSchema = z.object({
  display_name: z.string().trim().min(1).max(200),
  email: z.string().trim().email().max(320),
  routing_order: z.number().int().min(1).max(100),
})

export const sendEnvelopeSchema = z.object({
  agreement_id: z.string().uuid(),
  signing_mode: z.enum(['sequential', 'parallel']).default('sequential'),
  require_email_verification: z.boolean().default(false),
  expires_at: z.string().datetime().nullable().optional(),
  signers: z.array(signerInputSchema).min(1).max(50),
  fields: z.array(envelopeFieldSchema).max(500).default([]),
})

export const publicSignSchema = z.object({
  signer_id: z.string().uuid(),
  envelope_id: z.string().uuid(),
  method: z.enum(['typed', 'drawn']),
  value_text: z.string().trim().min(1).max(200_000),
  consent_accepted: z.literal(true),
  disclosure_hash: z.string().min(1).max(128),
  field_values: z.record(z.string().uuid(), z.string().max(200_000)).default({}),
  user_agent: z.string().max(1_000).optional(),
})

export const verificationRequestSchema = z.object({})
export const verificationConfirmSchema = z.object({ code: z.string().regex(/^\d{6}$/) })

export const publicSignCommandSchema = publicSignSchema.extend({
  token_hash: z.string().length(64),
  ip_address: z.string().max(200).nullable().optional(),
})

export const declineSignerSchema = z.object({
  signer_id: z.string().uuid(),
  envelope_id: z.string().uuid(),
  token_hash: z.string().length(64),
  reason: z.string().trim().min(1).max(2_000),
})

export const viewSignerCommandSchema = z.object({
  signer_id: z.string().uuid(),
  envelope_id: z.string().uuid(),
  token_hash: z.string().length(64),
})

export type AgreementCreateInput = z.infer<typeof agreementCreateSchema>
export type AgreementUpdateInput = z.infer<typeof agreementUpdateSchema>
export type SendEnvelopeInput = z.infer<typeof sendEnvelopeSchema>
export type PublicSignInput = z.infer<typeof publicSignSchema>
