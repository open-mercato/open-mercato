import { Entity, Index, PrimaryKey, Property, Unique } from '@mikro-orm/decorators/legacy'

export type AgreementStatus = 'draft' | 'published' | 'archived'
export type EnvelopeStatus = 'draft' | 'sent' | 'in_progress' | 'finalizing' | 'completed' | 'declined' | 'expired' | 'voided'
export type SignerStatus = 'pending' | 'invited' | 'viewed' | 'ready' | 'signed' | 'declined' | 'expired'

@Entity({ tableName: 'agreements' })
@Index({ properties: ['tenantId', 'organizationId', 'status'] })
export class Agreement {
  @PrimaryKey({ type: 'uuid', defaultRaw: 'gen_random_uuid()' })
  id!: string

  @Property({ name: 'tenant_id', type: 'uuid' })
  tenantId!: string

  @Property({ name: 'organization_id', type: 'uuid' })
  organizationId!: string

  @Property({ type: 'text' })
  title!: string

  @Property({ type: 'text', nullable: true })
  description?: string | null

  @Property({ name: 'draft_content_html', type: 'text' })
  draftContentHtml!: string

  @Property({ name: 'draft_pdf_artifact_id', type: 'uuid', nullable: true })
  draftPdfArtifactId?: string | null

  @Property({ type: 'text', default: 'draft' })
  status: AgreementStatus = 'draft'

  @Property({ name: 'published_version_id', type: 'uuid', nullable: true })
  publishedVersionId?: string | null

  @Property({ name: 'created_by_user_id', type: 'uuid', nullable: true })
  createdByUserId?: string | null

  @Property({ name: 'created_at', type: Date, onCreate: () => new Date() })
  createdAt: Date = new Date()

  @Property({ name: 'updated_at', type: Date, onUpdate: () => new Date() })
  updatedAt: Date = new Date()

  @Property({ name: 'deleted_at', type: Date, nullable: true })
  deletedAt?: Date | null
}

@Entity({ tableName: 'agreement_versions' })
@Index({ properties: ['tenantId', 'organizationId', 'agreementId'] })
@Unique({ name: 'agreement_versions_scope_number_unique', properties: ['tenantId', 'organizationId', 'agreementId', 'versionNumber'] })
export class AgreementVersion {
  @PrimaryKey({ type: 'uuid', defaultRaw: 'gen_random_uuid()' })
  id!: string

  @Property({ name: 'agreement_id', type: 'uuid' })
  agreementId!: string

  @Property({ name: 'tenant_id', type: 'uuid' })
  tenantId!: string

  @Property({ name: 'organization_id', type: 'uuid' })
  organizationId!: string

  @Property({ name: 'version_number', type: 'integer' })
  versionNumber!: number

  @Property({ name: 'content_html', type: 'text' })
  contentHtml!: string

  @Property({ name: 'source_mode', type: 'text', default: 'rich_text' })
  sourceMode: 'rich_text' | 'pdf' | 'both' = 'rich_text'

  @Property({ name: 'uploaded_pdf_artifact_id', type: 'uuid', nullable: true })
  uploadedPdfArtifactId?: string | null

  @Property({ name: 'content_hash', type: 'text' })
  contentHash!: string

  @Property({ name: 'disclosure_text', type: 'text' })
  disclosureText!: string

  @Property({ name: 'published_at', type: Date })
  publishedAt: Date = new Date()

  @Property({ name: 'published_by_user_id', type: 'uuid', nullable: true })
  publishedByUserId?: string | null

  @Property({ name: 'created_at', type: Date, onCreate: () => new Date() })
  createdAt: Date = new Date()
}

@Entity({ tableName: 'agreement_envelopes' })
@Index({ properties: ['tenantId', 'organizationId', 'status'] })
export class SigningEnvelope {
  @PrimaryKey({ type: 'uuid', defaultRaw: 'gen_random_uuid()' })
  id!: string

  @Property({ name: 'agreement_id', type: 'uuid' })
  agreementId!: string

  @Property({ name: 'agreement_version_id', type: 'uuid' })
  agreementVersionId!: string

  @Property({ name: 'tenant_id', type: 'uuid' })
  tenantId!: string

  @Property({ name: 'organization_id', type: 'uuid' })
  organizationId!: string

  @Property({ type: 'text', default: 'draft' })
  status: EnvelopeStatus = 'draft'

  @Property({ name: 'signing_mode', type: 'text', default: 'sequential' })
  signingMode: 'sequential' | 'parallel' = 'sequential'

  @Property({ name: 'require_email_verification', type: 'boolean', default: false })
  requireEmailVerification = false

  @Property({ name: 'expires_at', type: Date, nullable: true })
  expiresAt?: Date | null

  @Property({ name: 'sent_at', type: Date, nullable: true })
  sentAt?: Date | null

  @Property({ name: 'completed_at', type: Date, nullable: true })
  completedAt?: Date | null

  @Property({ name: 'final_artifact_id', type: 'uuid', nullable: true })
  finalArtifactId?: string | null

  @Property({ name: 'certificate_artifact_id', type: 'uuid', nullable: true })
  certificateArtifactId?: string | null

  @Property({ name: 'created_by_user_id', type: 'uuid', nullable: true })
  createdByUserId?: string | null

  @Property({ name: 'created_at', type: Date, onCreate: () => new Date() })
  createdAt: Date = new Date()

  @Property({ name: 'updated_at', type: Date, onUpdate: () => new Date() })
  updatedAt: Date = new Date()

  @Property({ name: 'deleted_at', type: Date, nullable: true })
  deletedAt?: Date | null
}

@Entity({ tableName: 'agreement_signers' })
@Index({ properties: ['tenantId', 'organizationId', 'envelopeId', 'status'] })
@Unique({ name: 'agreement_signers_token_hash_unique', properties: ['tokenHash'] })
@Unique({ name: 'agreement_signers_envelope_order_unique', properties: ['envelopeId', 'routingOrder'] })
export class Signer {
  @PrimaryKey({ type: 'uuid', defaultRaw: 'gen_random_uuid()' })
  id!: string

  @Property({ name: 'envelope_id', type: 'uuid' })
  envelopeId!: string

  @Property({ name: 'tenant_id', type: 'uuid' })
  tenantId!: string

  @Property({ name: 'organization_id', type: 'uuid' })
  organizationId!: string

  @Property({ name: 'display_name', type: 'text' })
  displayName!: string

  @Property({ type: 'text' })
  email!: string

  @Property({ name: 'routing_order', type: 'integer' })
  routingOrder!: number

  @Property({ type: 'text', default: 'pending' })
  status: SignerStatus = 'pending'

  @Property({ name: 'token_hash', type: 'text' })
  tokenHash!: string

  @Property({ name: 'verified_at', type: Date, nullable: true })
  verifiedAt?: Date | null

  @Property({ name: 'verification_code_hash', type: 'text', nullable: true })
  verificationCodeHash?: string | null

  @Property({ name: 'verification_expires_at', type: Date, nullable: true })
  verificationExpiresAt?: Date | null

  @Property({ name: 'verification_attempts', type: 'integer', default: 0 })
  verificationAttempts = 0

  @Property({ name: 'verification_locked_until', type: Date, nullable: true })
  verificationLockedUntil?: Date | null

  @Property({ name: 'signed_at', type: Date, nullable: true })
  signedAt?: Date | null

  @Property({ name: 'declined_at', type: Date, nullable: true })
  declinedAt?: Date | null

  @Property({ name: 'decline_reason', type: 'text', nullable: true })
  declineReason?: string | null

  @Property({ name: 'created_at', type: Date, onCreate: () => new Date() })
  createdAt: Date = new Date()

  @Property({ name: 'updated_at', type: Date, onUpdate: () => new Date() })
  updatedAt: Date = new Date()
}

@Entity({ tableName: 'agreement_signatures' })
@Unique({ name: 'agreement_signatures_signer_unique', properties: ['signerId'] })
export class Signature {
  @PrimaryKey({ type: 'uuid', defaultRaw: 'gen_random_uuid()' })
  id!: string

  @Property({ name: 'envelope_id', type: 'uuid' })
  envelopeId!: string

  @Property({ name: 'signer_id', type: 'uuid' })
  signerId!: string

  @Property({ name: 'tenant_id', type: 'uuid' })
  tenantId!: string

  @Property({ name: 'organization_id', type: 'uuid' })
  organizationId!: string

  @Property({ type: 'text' })
  method: 'typed' | 'drawn' = 'typed'

  @Property({ name: 'value_text', type: 'text' })
  valueText!: string

  @Property({ name: 'consent_accepted', type: 'boolean' })
  consentAccepted = false

  @Property({ name: 'disclosure_hash', type: 'text' })
  disclosureHash!: string

  @Property({ name: 'document_hash', type: 'text' })
  documentHash!: string

  @Property({ name: 'field_values_json', type: 'json', nullable: true })
  fieldValuesJson?: Record<string, string> | null

  @Property({ name: 'signed_at', type: Date })
  signedAt: Date = new Date()

  @Property({ name: 'ip_address', type: 'text', nullable: true })
  ipAddress?: string | null

  @Property({ name: 'user_agent', type: 'text', nullable: true })
  userAgent?: string | null

  @Property({ name: 'created_at', type: Date, onCreate: () => new Date() })
  createdAt: Date = new Date()
}

export type EnvelopeFieldType = 'signature' | 'initials' | 'date' | 'text'

@Entity({ tableName: 'agreement_envelope_fields' })
@Index({ properties: ['tenantId', 'organizationId', 'envelopeId', 'signerId'] })
export class EnvelopeField {
  @PrimaryKey({ type: 'uuid', defaultRaw: 'gen_random_uuid()' })
  id!: string

  @Property({ name: 'envelope_id', type: 'uuid' })
  envelopeId!: string

  @Property({ name: 'signer_id', type: 'uuid' })
  signerId!: string

  @Property({ name: 'tenant_id', type: 'uuid' })
  tenantId!: string

  @Property({ name: 'organization_id', type: 'uuid' })
  organizationId!: string

  @Property({ name: 'field_type', type: 'text' })
  fieldType!: EnvelopeFieldType

  @Property({ name: 'page_number', type: 'integer' })
  pageNumber!: number

  @Property({ type: 'decimal', precision: 10, scale: 6 })
  x!: number

  @Property({ type: 'decimal', precision: 10, scale: 6 })
  y!: number

  @Property({ type: 'decimal', precision: 10, scale: 6 })
  width!: number

  @Property({ type: 'decimal', precision: 10, scale: 6 })
  height!: number

  @Property({ type: 'boolean', default: true })
  required = true

  @Property({ type: 'text', nullable: true })
  label?: string | null

  @Property({ name: 'created_at', type: Date, onCreate: () => new Date() })
  createdAt: Date = new Date()
}

export type AgreementArtifactKind = 'uploaded_pdf' | 'final_document' | 'certificate'

@Entity({ tableName: 'agreement_artifacts' })
@Index({ properties: ['tenantId', 'organizationId', 'kind'] })
export class AgreementArtifact {
  @PrimaryKey({ type: 'uuid', defaultRaw: 'gen_random_uuid()' })
  id!: string

  @Property({ name: 'tenant_id', type: 'uuid' })
  tenantId!: string

  @Property({ name: 'organization_id', type: 'uuid' })
  organizationId!: string

  @Property({ type: 'text' })
  kind!: AgreementArtifactKind

  @Property({ name: 'partition_code', type: 'text', default: 'privateAttachments' })
  partitionCode = 'privateAttachments'

  @Property({ name: 'storage_driver', type: 'text', default: 'local' })
  storageDriver = 'local'

  @Property({ name: 'storage_path', type: 'text' })
  storagePath!: string

  @Property({ name: 'content_type', type: 'text' })
  contentType!: string

  @Property({ name: 'byte_size', type: 'integer' })
  byteSize!: number

  @Property({ name: 'content_hash', type: 'text' })
  contentHash!: string

  @Property({ name: 'file_name', type: 'text' })
  fileName!: string

  @Property({ name: 'created_at', type: Date, onCreate: () => new Date() })
  createdAt: Date = new Date()
}

@Entity({ tableName: 'agreement_audit_events' })
@Index({ properties: ['tenantId', 'organizationId', 'envelopeId', 'createdAt'] })
export class AuditEvent {
  @PrimaryKey({ type: 'uuid', defaultRaw: 'gen_random_uuid()' })
  id!: string

  @Property({ name: 'envelope_id', type: 'uuid' })
  envelopeId!: string

  @Property({ name: 'signer_id', type: 'uuid', nullable: true })
  signerId?: string | null

  @Property({ name: 'tenant_id', type: 'uuid' })
  tenantId!: string

  @Property({ name: 'organization_id', type: 'uuid' })
  organizationId!: string

  @Property({ name: 'event_type', type: 'text' })
  eventType!: string

  @Property({ name: 'actor_kind', type: 'text' })
  actorKind!: 'staff' | 'signer' | 'system'

  @Property({ name: 'actor_user_id', type: 'uuid', nullable: true })
  actorUserId?: string | null

  @Property({ name: 'metadata_json', type: 'json', nullable: true })
  metadataJson?: Record<string, unknown> | null

  @Property({ name: 'previous_hash', type: 'text', nullable: true })
  previousHash?: string | null

  @Property({ name: 'event_hash', type: 'text' })
  eventHash!: string

  @Property({ name: 'created_at', type: Date, onCreate: () => new Date() })
  createdAt: Date = new Date()
}
