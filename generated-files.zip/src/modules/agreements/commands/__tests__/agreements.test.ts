import { describe, expect, it } from '@jest/globals'
import { createSignerToken, signerTokenHash } from '../../lib/tokens'
import { canSignerSign } from '../../lib/routing'

describe('agreement signer links', () => {
  it('creates high-entropy bearer tokens and stores only their hash', () => {
    const first = createSignerToken()
    const second = createSignerToken()

    expect(first.token).toHaveLength(43)
    expect(first.tokenHash).toHaveLength(64)
    expect(first.tokenHash).toBe(signerTokenHash(first.token))
    expect(first.tokenHash).not.toBe(first.token)
    expect(first.token).not.toBe(second.token)
    expect(second.tokenHash).toBe(signerTokenHash(second.token))
  })
})

describe('agreement signer routing', () => {
  it('opens sequential signing only after lower routing orders are signed', () => {
    const signers = [
      { routingOrder: 1, status: 'signed' },
      { routingOrder: 2, status: 'viewed' },
      { routingOrder: 3, status: 'invited' },
    ]

    expect(canSignerSign('sequential', 2, signers)).toBe(true)
    expect(canSignerSign('sequential', 3, signers)).toBe(false)
    expect(canSignerSign('parallel', 3, signers)).toBe(true)
  })
})
