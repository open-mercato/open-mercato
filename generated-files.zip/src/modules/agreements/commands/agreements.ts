import { createHash, randomInt, randomUUID, timingSafeEqual } from 'node:crypto'
import React from 'react'
import type { EntityManager, FilterQuery } from '@mikro-orm/postgresql'
import type { CommandHandler, CommandRuntimeContext } from '@open-mercato/shared/lib/commands'
import { registerCommand } from '@open-mercato/shared/lib/commands'
import { CrudHttpError } from '@open-mercato/shared/lib/crud/errors'
import { assertOptimisticLock } from '@open-mercato/shared/lib/crud/optimistic-lock-command'
import { extractUndoPayload } from '@open-mercato/shared/lib/commands/undo'
import { emitCrudSideEffects, emitCrudUndoSideEffects } from '@open-mercato/shared/lib/commands/helpers'
import { withAtomicFlush } from '@open-mercato/shared/lib/commands/flush'
import type { CrudEventsConfig } from '@open-mercato/shared/lib/crud/types'
import type { DataEngine } from '@open-mercato/shared/lib/data/engine'
import { findOneWithDecryption } from '@open-mercato/shared/lib/encryption/find'
import { sanitizeRichTextHtml } from '@open-mercato/shared/lib/html/sanitizeRichText'
import { resolveTranslations } from '@open-mercato/shared/lib/i18n/server'
import { sendEmail } from '@open-mercato/shared/lib/email/send'
import { z } from 'zod'
import {
  Agreement,
  AgreementArtifact,
  AgreementVersion,
  AuditEvent,
  EnvelopeField,
  Signature,
  Signer,
  SigningEnvelope,
} from '../data/entities'
import {
  agreementCreateSchema,
  agreementDeleteSchema,
  agreementUpdateSchema,
  declineSignerSchema,
  publishAgreementSchema,
  publicSignCommandSchema,
  sendEnvelopeSchema,
  verificationConfirmSchema,
  viewSignerCommandSchema,
} from '../data/validators'
import { createSignerToken, signerTokenHash } from '../lib/tokens'
import { canSignerSign } from '../lib/routing'
import { emitAgreementsEvent } from '../events'
import {
  createEvidenceCertificate,
  decodePdfBase64,
  readAgreementArtifact,
  renderCompletedPdf,
  storeAgreementArtifact,
  validatePdf,
} from '../lib/artifacts'

export const AGREEMENT_ENTITY_ID = 'agreements:agreement' as const

export const agreementCrudEvents: CrudEventsConfig<Agreement> = {
  module: 'agreements',
  entity: 'agreement',
  persistent: true,
  buildPayload: ({ identifiers }) => ({
    id: identifiers.id,
    tenantId: identifiers.tenantId,
    organizationId: identifiers.organizationId,
  }),
}

type Scope = { tenantId: string; organizationId: string }
type RawInput = Record<string, unknown> | { body?: unknown; query?: unknown }

type AgreementSnapshot = {
  id: string
  tenantId: string
  organizationId: string
  title: string
  description: string | null
  draftContentHtml: string
  status: string
  publishedVersionId: string | null
  draftPdfArtifactId: string | null
}

function ensureScope(ctx: CommandRuntimeContext): Scope {
  const tenantId = ctx.auth?.tenantId ?? null
  const organizationId = ctx.selectedOrganizationId ?? ctx.auth?.orgId ?? null
  if (!tenantId || !organizationId) {
    throw new CrudHttpError(400, { error: 'Tenant and organization context are required' })
  }
  return { tenantId, organizationId }
}

function inputBody(input: RawInput): Record<string, unknown> {
  if ('body' in input && input.body && typeof input.body === 'object' && !Array.isArray(input.body)) {
    return input.body as Record<string, unknown>
  }
  return input as Record<string, unknown>
}

function getEntityManager(ctx: CommandRuntimeContext): EntityManager {
  return ctx.transactionalEm ?? ctx.container.resolve<EntityManager>('em')
}

function getDataEngine(ctx: CommandRuntimeContext): DataEngine {
  return ctx.container.resolve<DataEngine>('dataEngine')
}

function snapshotAgreement(agreement: Agreement): AgreementSnapshot {
  return {
    id: String(agreement.id),
    tenantId: String(agreement.tenantId),
    organizationId: String(agreement.organizationId),
    title: agreement.title,
    description: agreement.description ?? null,
    draftContentHtml: agreement.draftContentHtml,
    status: agreement.status,
    publishedVersionId: agreement.publishedVersionId ?? null,
    draftPdfArtifactId: agreement.draftPdfArtifactId ?? null,
  }
}

async function findAgreement(em: EntityManager, id: string, scope: Scope): Promise<Agreement> {
  const agreement = await findOneWithDecryption(
    em,
    Agreement,
    { id, tenantId: scope.tenantId, organizationId: scope.organizationId, deletedAt: null } as FilterQuery<Agreement>,
    undefined,
    scope,
  )
  if (!agreement) throw new CrudHttpError(404, { error: 'Agreement not found' })
  return agreement
}

function hashContent(content: string, disclosure: string): string {
  return createHash('sha256').update(`${content}\n${disclosure}`).digest('hex')
}

async function emitAgreementLifecycleEvent(
  eventId: Parameters<typeof emitAgreementsEvent>[0],
  payload: Record<string, unknown>,
): Promise<void> {
  await emitAgreementsEvent(eventId, payload, { persistent: true }).catch(() => undefined)
}

function isDuplicateKeyError(error: unknown): boolean {
  if (!error || typeof error !== 'object') return false
  const candidate = error as { code?: unknown; message?: unknown }
  return candidate.code === '23505' || (typeof candidate.message === 'string' && candidate.message.toLowerCase().includes('duplicate key'))
}

async function appendAuditEvent(
  em: EntityManager,
  input: {
    envelopeId: string
    signerId?: string | null
    tenantId: string
    organizationId: string
    eventType: string
    actorKind: 'staff' | 'signer' | 'system'
    actorUserId?: string | null
    metadataJson?: Record<string, unknown>
  },
): Promise<AuditEvent> {
  const previous = await em.findOne(
    AuditEvent,
    { envelopeId: input.envelopeId, tenantId: input.tenantId, organizationId: input.organizationId },
    { orderBy: { createdAt: 'desc' } },
  )
  const createdAt = new Date()
  const eventHash = createHash('sha256')
    .update(JSON.stringify({
      envelopeId: input.envelopeId,
      signerId: input.signerId ?? null,
      eventType: input.eventType,
      actorKind: input.actorKind,
      metadataJson: input.metadataJson ?? null,
      previousHash: previous?.eventHash ?? null,
      createdAt: createdAt.toISOString(),
    }))
    .digest('hex')
  const event = em.create(AuditEvent, {
    id: randomUUID(),
    envelopeId: input.envelopeId,
    signerId: input.signerId ?? null,
    tenantId: input.tenantId,
    organizationId: input.organizationId,
    eventType: input.eventType,
    actorKind: input.actorKind,
    actorUserId: input.actorUserId ?? null,
    metadataJson: input.metadataJson ?? null,
    previousHash: previous?.eventHash ?? null,
    eventHash,
    createdAt,
  })
  em.persist(event)
  return event
}

const createAgreementCommand: CommandHandler<RawInput, Agreement> = {
  id: 'agreements.agreements.create',
  isUndoable: true,
  async execute(rawInput, ctx) {
    const scope = ensureScope(ctx)
    const parsed = agreementCreateSchema.parse(inputBody(rawInput))
    const content = sanitizeRichTextHtml(parsed.draft_content_html)
    let draftPdfArtifactId: string | null = null
    if (!content.trim() && !parsed.pdf_base64) throw new CrudHttpError(400, { error: 'Agreement content or a PDF is required' })
    const em = getEntityManager(ctx)
    if (parsed.pdf_base64) {
      const buffer = decodePdfBase64(parsed.pdf_base64)
      await validatePdf(buffer)
      const artifact = await storeAgreementArtifact(em, scope, {
        kind: 'uploaded_pdf',
        fileName: parsed.pdf_file_name || 'agreement.pdf',
        contentType: 'application/pdf',
        buffer,
      })
      draftPdfArtifactId = String(artifact.id)
    }
    const agreement = await getDataEngine(ctx).createOrmEntity({
      entity: Agreement,
      data: {
        ...(parsed.id ? { id: parsed.id } : {}),
        tenantId: scope.tenantId,
        organizationId: scope.organizationId,
        title: parsed.title,
        description: parsed.description ?? null,
        draftContentHtml: content,
        draftPdfArtifactId,
        status: 'draft',
        publishedVersionId: null,
        createdByUserId: ctx.auth?.sub ?? null,
      },
    })
    await emitCrudSideEffects({
      dataEngine: getDataEngine(ctx),
      action: 'created',
      entity: agreement,
      identifiers: { id: String(agreement.id), tenantId: scope.tenantId, organizationId: scope.organizationId },
      events: agreementCrudEvents,
    })
    return agreement
  },
  buildLog: async ({ result }) => {
    const { translate } = await resolveTranslations()
    return {
      actionLabel: translate('agreements.audit.create', 'Create agreement'),
      resourceKind: AGREEMENT_ENTITY_ID,
      resourceId: String(result.id),
      tenantId: String(result.tenantId),
      organizationId: String(result.organizationId),
      snapshotAfter: snapshotAgreement(result),
    }
  },
  async undo({ logEntry, ctx }) {
    const undo = extractUndoPayload<{ after?: AgreementSnapshot }>(logEntry)
    const snapshot = (logEntry.snapshotAfter as AgreementSnapshot | null | undefined) ?? undo?.after
    if (!snapshot?.id) throw new CrudHttpError(400, { error: 'Agreement undo snapshot is missing' })
    const scope = ensureScope(ctx)
    await getDataEngine(ctx).deleteOrmEntity({
      entity: Agreement,
      where: { id: snapshot.id, tenantId: scope.tenantId, organizationId: scope.organizationId } as FilterQuery<Agreement>,
      soft: true,
      softDeleteField: 'deletedAt',
    })
    await emitCrudUndoSideEffects({
      dataEngine: getDataEngine(ctx),
      action: 'deleted',
      entity: null,
      identifiers: { id: snapshot.id, tenantId: scope.tenantId, organizationId: scope.organizationId },
      events: agreementCrudEvents,
    })
  },
}

const updateAgreementCommand: CommandHandler<RawInput, Agreement> = {
  id: 'agreements.agreements.update',
  isUndoable: true,
  async prepare(rawInput, ctx) {
    const scope = ensureScope(ctx)
    const parsed = agreementUpdateSchema.parse(inputBody(rawInput))
    const agreement = await findAgreement(getEntityManager(ctx), parsed.id, scope)
    assertOptimisticLock({
      resourceKind: AGREEMENT_ENTITY_ID,
      resourceId: parsed.id,
      expected: parsed.expected_updated_at,
      current: agreement.updatedAt,
    })
    return { before: snapshotAgreement(agreement) }
  },
  async execute(rawInput, ctx) {
    const scope = ensureScope(ctx)
    const parsed = agreementUpdateSchema.parse(inputBody(rawInput))
    const content = sanitizeRichTextHtml(parsed.draft_content_html)
    if (!content.trim() && !parsed.pdf_base64) throw new CrudHttpError(400, { error: 'Agreement content or a PDF is required' })
    let draftPdfArtifactId: string | undefined
    if (parsed.pdf_base64) {
      const buffer = decodePdfBase64(parsed.pdf_base64)
      await validatePdf(buffer)
      const artifact = await storeAgreementArtifact(getEntityManager(ctx), scope, {
        kind: 'uploaded_pdf',
        fileName: parsed.pdf_file_name || 'agreement.pdf',
        contentType: 'application/pdf',
        buffer,
      })
      draftPdfArtifactId = String(artifact.id)
    }
    const agreement = await getDataEngine(ctx).updateOrmEntity({
      entity: Agreement,
      where: { id: parsed.id, tenantId: scope.tenantId, organizationId: scope.organizationId, deletedAt: null } as FilterQuery<Agreement>,
      apply: (entity) => {
        if (entity.status !== 'draft') throw new CrudHttpError(409, { error: 'Published agreements are immutable' })
        entity.title = parsed.title
        entity.description = parsed.description ?? null
        entity.draftContentHtml = content
        if (draftPdfArtifactId !== undefined) entity.draftPdfArtifactId = draftPdfArtifactId
      },
    })
    if (!agreement) throw new CrudHttpError(404, { error: 'Agreement not found' })
    await emitCrudSideEffects({
      dataEngine: getDataEngine(ctx),
      action: 'updated',
      entity: agreement,
      identifiers: { id: String(agreement.id), tenantId: scope.tenantId, organizationId: scope.organizationId },
      events: agreementCrudEvents,
    })
    return agreement
  },
  buildLog: async ({ result, snapshots }) => {
    const { translate } = await resolveTranslations()
    return {
      actionLabel: translate('agreements.audit.update', 'Update agreement'),
      resourceKind: AGREEMENT_ENTITY_ID,
      resourceId: String(result.id),
      tenantId: String(result.tenantId),
      organizationId: String(result.organizationId),
      snapshotBefore: snapshots.before ?? null,
      snapshotAfter: snapshotAgreement(result),
    }
  },
  async undo({ logEntry, ctx }) {
    const before = logEntry.snapshotBefore as AgreementSnapshot | null | undefined
    if (!before?.id) throw new CrudHttpError(400, { error: 'Agreement undo snapshot is missing' })
    const scope = ensureScope(ctx)
    const restored = await getDataEngine(ctx).updateOrmEntity({
      entity: Agreement,
      where: { id: before.id, tenantId: scope.tenantId, organizationId: scope.organizationId, deletedAt: null } as FilterQuery<Agreement>,
      apply: (entity) => {
        entity.title = before.title
        entity.description = before.description
        entity.draftContentHtml = before.draftContentHtml
        entity.status = before.status as AgreementStatus
        entity.publishedVersionId = before.publishedVersionId
      },
    })
    if (!restored) throw new CrudHttpError(404, { error: 'Agreement not found' })
    await emitCrudUndoSideEffects({
      dataEngine: getDataEngine(ctx),
      action: 'updated',
      entity: restored,
      identifiers: { id: before.id, tenantId: scope.tenantId, organizationId: scope.organizationId },
      events: agreementCrudEvents,
    })
  },
}

const deleteAgreementCommand: CommandHandler<RawInput, Agreement> = {
  id: 'agreements.agreements.delete',
  isUndoable: true,
  async prepare(rawInput, ctx) {
    const scope = ensureScope(ctx)
    const parsed = agreementDeleteSchema.parse(inputBody(rawInput))
    const agreement = await findAgreement(getEntityManager(ctx), parsed.id, scope)
    if (agreement.status === 'published') throw new CrudHttpError(409, { error: 'Published agreements must be archived' })
    return { before: snapshotAgreement(agreement) }
  },
  async execute(rawInput, ctx) {
    const scope = ensureScope(ctx)
    const parsed = agreementDeleteSchema.parse(inputBody(rawInput))
    const agreement = await getDataEngine(ctx).deleteOrmEntity({
      entity: Agreement,
      where: { id: parsed.id, tenantId: scope.tenantId, organizationId: scope.organizationId, deletedAt: null } as FilterQuery<Agreement>,
      soft: true,
      softDeleteField: 'deletedAt',
    })
    if (!agreement) throw new CrudHttpError(404, { error: 'Agreement not found' })
    await emitCrudSideEffects({
      dataEngine: getDataEngine(ctx),
      action: 'deleted',
      entity: agreement,
      identifiers: { id: parsed.id, tenantId: scope.tenantId, organizationId: scope.organizationId },
      events: agreementCrudEvents,
    })
    return agreement
  },
  buildLog: async ({ snapshots, input }) => {
    const { translate } = await resolveTranslations()
    const parsed = agreementDeleteSchema.parse(inputBody(input))
    const before = snapshots.before as AgreementSnapshot | undefined
    return {
      actionLabel: translate('agreements.audit.delete', 'Archive agreement'),
      resourceKind: AGREEMENT_ENTITY_ID,
      resourceId: parsed.id,
      tenantId: before?.tenantId ?? null,
      organizationId: before?.organizationId ?? null,
      snapshotBefore: before ?? null,
    }
  },
  async undo({ logEntry, ctx }) {
    const before = logEntry.snapshotBefore as AgreementSnapshot | null | undefined
    if (!before?.id) throw new CrudHttpError(400, { error: 'Agreement undo snapshot is missing' })
    const scope = ensureScope(ctx)
    const em = getEntityManager(ctx)
    const agreement = await em.findOne(Agreement, { id: before.id, tenantId: scope.tenantId, organizationId: scope.organizationId } as FilterQuery<Agreement>)
    if (!agreement) throw new CrudHttpError(404, { error: 'Agreement not found' })
    agreement.deletedAt = null
    agreement.title = before.title
    agreement.description = before.description
    agreement.draftContentHtml = before.draftContentHtml
    agreement.status = before.status as AgreementStatus
    agreement.publishedVersionId = before.publishedVersionId
    await em.flush()
    await emitCrudUndoSideEffects({
      dataEngine: getDataEngine(ctx),
      action: 'updated',
      entity: agreement,
      identifiers: { id: before.id, tenantId: scope.tenantId, organizationId: scope.organizationId },
      events: agreementCrudEvents,
    })
  },
}

type AgreementStatus = 'draft' | 'published' | 'archived'

const publishAgreementCommand: CommandHandler<RawInput, { id: string; versionId: string; contentHash: string; updatedAt: string }> = {
  id: 'agreements.versions.publish',
  async execute(rawInput, ctx) {
    const scope = ensureScope(ctx)
    const parsed = publishAgreementSchema.parse(inputBody(rawInput))
    const em = getEntityManager(ctx)
    const agreement = await findAgreement(em, parsed.id, scope)
    if (agreement.status !== 'draft') throw new CrudHttpError(409, { error: 'Only draft agreements can be published' })
    const content = sanitizeRichTextHtml(agreement.draftContentHtml)
    const disclosure = sanitizeRichTextHtml(parsed.disclosure_text)
    let sourceMode: AgreementVersion['sourceMode'] = 'rich_text'
    let uploadedPdfArtifactId: string | null = agreement.draftPdfArtifactId ?? null
    let sourceHash = content
    if (uploadedPdfArtifactId) {
      const pdf = await readAgreementArtifact(em, uploadedPdfArtifactId, scope)
      await validatePdf(pdf)
      sourceMode = content.trim() ? 'both' : 'pdf'
      sourceHash = `${content}\n${createHash('sha256').update(pdf).digest('hex')}`
    }
    if (!content.trim() && !uploadedPdfArtifactId) throw new CrudHttpError(400, { error: 'Agreement content or a PDF is required' })
    const contentHash = hashContent(sourceHash, disclosure)
    const previousVersions = await em.find(AgreementVersion, {
      agreementId: agreement.id,
      tenantId: scope.tenantId,
      organizationId: scope.organizationId,
    })
    const versionNumber = previousVersions.reduce((max, version) => Math.max(max, version.versionNumber), 0) + 1
    const version = em.create(AgreementVersion, {
      id: randomUUID(),
      agreementId: agreement.id,
      tenantId: scope.tenantId,
      organizationId: scope.organizationId,
      versionNumber,
      contentHtml: content,
      sourceMode,
      uploadedPdfArtifactId,
      contentHash,
      disclosureText: disclosure,
      publishedAt: new Date(),
      publishedByUserId: ctx.auth?.sub ?? null,
      createdAt: new Date(),
    })
    await withAtomicFlush(em, [async () => {
      agreement.status = 'published'
      agreement.publishedVersionId = version.id
      em.persist(version)
    }], { transaction: true, label: 'agreements.versions.publish' })
    await emitAgreementLifecycleEvent('agreements.version.published', {
      id: version.id,
      agreementId: agreement.id,
      tenantId: scope.tenantId,
      organizationId: scope.organizationId,
      versionNumber,
      contentHash,
    })
    return { id: String(agreement.id), versionId: String(version.id), contentHash, updatedAt: agreement.updatedAt.toISOString() }
  },
  buildLog: () => ({ skipLog: true }),
}

type EnvelopeLink = { signerId: string; displayName: string; email: string; token: string }

const sendEnvelopeCommand: CommandHandler<RawInput, { envelopeId: string; links: EnvelopeLink[] }> = {
  id: 'agreements.envelopes.send',
  async execute(rawInput, ctx) {
    const scope = ensureScope(ctx)
    const parsed = sendEnvelopeSchema.parse(inputBody(rawInput))
    const em = getEntityManager(ctx)
    const agreement = await findAgreement(em, parsed.agreement_id, scope)
    if (agreement.status !== 'published' || !agreement.publishedVersionId) {
      throw new CrudHttpError(409, { error: 'A published agreement version is required' })
    }
    const version = await em.findOne(AgreementVersion, {
      id: agreement.publishedVersionId,
      agreementId: agreement.id,
      tenantId: scope.tenantId,
      organizationId: scope.organizationId,
    } as FilterQuery<AgreementVersion>)
    if (!version) throw new CrudHttpError(409, { error: 'Published agreement version is missing' })
    let pdfPageCount: number | null = null
    if (parsed.fields.length > 0) {
      if (!version.uploadedPdfArtifactId) throw new CrudHttpError(400, { error: 'Positioned fields require an uploaded PDF' })
      const pdf = await readAgreementArtifact(em, version.uploadedPdfArtifactId, scope)
      pdfPageCount = (await validatePdf(pdf)).pageCount
    }
    const orders = parsed.signers.map((signer) => signer.routing_order)
    if (new Set(orders).size !== orders.length) throw new CrudHttpError(400, { error: 'Signer routing order must be unique' })
    const normalizedEmails = parsed.signers.map((signer) => signer.email.trim().toLowerCase())
    if (new Set(normalizedEmails).size !== normalizedEmails.length) throw new CrudHttpError(400, { error: 'Signer email must be unique' })
    const expiresAt = parsed.expires_at ? new Date(parsed.expires_at) : null
    if (expiresAt && expiresAt <= new Date()) throw new CrudHttpError(400, { error: 'Expiration must be in the future' })

    const envelope = em.create(SigningEnvelope, {
      id: randomUUID(),
      agreementId: agreement.id,
      agreementVersionId: version.id,
      tenantId: scope.tenantId,
      organizationId: scope.organizationId,
      status: 'sent',
      signingMode: parsed.signing_mode,
      requireEmailVerification: parsed.require_email_verification,
      expiresAt,
      sentAt: new Date(),
      createdByUserId: ctx.auth?.sub ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    })
    const links: EnvelopeLink[] = []
    const signerRecords: Signer[] = []
    await withAtomicFlush(em, [async () => {
      em.persist(envelope)
      for (const input of parsed.signers) {
        const token = createSignerToken()
        const signer = em.create(Signer, {
          id: randomUUID(),
          envelopeId: envelope.id,
          tenantId: scope.tenantId,
          organizationId: scope.organizationId,
          displayName: input.display_name,
          email: input.email.trim().toLowerCase(),
          routingOrder: input.routing_order,
          status: 'invited',
          tokenHash: token.tokenHash,
          verificationAttempts: 0,
          createdAt: new Date(),
          updatedAt: new Date(),
        })
        em.persist(signer)
        signerRecords.push(signer)
        links.push({ signerId: String(signer.id), displayName: signer.displayName, email: signer.email, token: token.token })
      }
      for (const field of parsed.fields) {
        const signer = field.signer_id
          ? signerRecords.find((candidate) => String(candidate.id) === field.signer_id)
          : signerRecords[field.signer_index ?? -1]
        if (!signer) throw new CrudHttpError(400, { error: 'Each PDF field must be assigned to a signer' })
        if ((field.x + field.width) > 1 || (field.y + field.height) > 1 || (pdfPageCount !== null && field.page_number > pdfPageCount)) {
          throw new CrudHttpError(400, { error: 'PDF field must fit within a document page' })
        }
        const envelopeField = em.create(EnvelopeField, {
          id: randomUUID(),
          envelopeId: envelope.id,
          signerId: signer.id,
          tenantId: scope.tenantId,
          organizationId: scope.organizationId,
          fieldType: field.field_type,
          pageNumber: field.page_number,
          x: field.x,
          y: field.y,
          width: field.width,
          height: field.height,
          required: field.required,
          label: field.label ?? null,
          createdAt: new Date(),
        })
        em.persist(envelopeField)
      }
      await appendAuditEvent(em, {
        envelopeId: envelope.id,
        tenantId: scope.tenantId,
        organizationId: scope.organizationId,
        eventType: 'envelope.sent',
        actorKind: 'staff',
        actorUserId: ctx.auth?.sub ?? null,
        metadataJson: { signerCount: links.length, signingMode: parsed.signing_mode },
      })
    }], { transaction: true, label: 'agreements.envelopes.send' })
    await emitAgreementLifecycleEvent('agreements.envelope.sent', {
      id: envelope.id,
      agreementId: agreement.id,
      tenantId: scope.tenantId,
      organizationId: scope.organizationId,
      signerCount: links.length,
    })
    return { envelopeId: String(envelope.id), links }
  },
  buildLog: () => ({ skipLog: true }),
}

async function finalizeCompletedEnvelope(
  em: EntityManager,
  envelope: SigningEnvelope,
  version: AgreementVersion,
  scope: Scope,
): Promise<void> {
  if (envelope.finalArtifactId && envelope.certificateArtifactId && envelope.status === 'completed') return
  const signers = await em.find(Signer, { envelopeId: envelope.id, tenantId: scope.tenantId, organizationId: scope.organizationId } as FilterQuery<Signer>)
  const signatures = await em.find(Signature, { envelopeId: envelope.id, tenantId: scope.tenantId, organizationId: scope.organizationId } as FilterQuery<Signature>)
  const fields = await em.find(EnvelopeField, { envelopeId: envelope.id, tenantId: scope.tenantId, organizationId: scope.organizationId } as FilterQuery<EnvelopeField>)
  const finalBuffer = await renderCompletedPdf(em, envelope, version, fields, signers, signatures, scope)
  const finalArtifact = await storeAgreementArtifact(em, scope, {
    kind: 'final_document',
    fileName: `agreement-${envelope.id}-completed.pdf`,
    contentType: 'application/pdf',
    buffer: finalBuffer,
  })
  envelope.finalArtifactId = String(finalArtifact.id)
  const certificateBuffer = await createEvidenceCertificate(envelope, version, signers, signatures)
  const certificateArtifact = await storeAgreementArtifact(em, scope, {
    kind: 'certificate',
    fileName: `agreement-${envelope.id}-certificate.pdf`,
    contentType: 'application/pdf',
    buffer: certificateBuffer,
  })
  envelope.certificateArtifactId = String(certificateArtifact.id)
  envelope.status = 'completed'
  await withAtomicFlush(em, [async () => {
    await appendAuditEvent(em, {
      envelopeId: envelope.id,
      tenantId: scope.tenantId,
      organizationId: scope.organizationId,
      eventType: 'evidence.ready',
      actorKind: 'system',
      metadataJson: { finalHash: finalArtifact.contentHash, certificateHash: certificateArtifact.contentHash },
    })
  }], { transaction: true, label: 'agreements.evidence.finalize' })
  await emitAgreementLifecycleEvent('agreements.evidence.ready', {
    id: envelope.id,
    tenantId: scope.tenantId,
    organizationId: scope.organizationId,
    finalHash: finalArtifact.contentHash,
    certificateHash: certificateArtifact.contentHash,
  })
}

type VerificationInput = { signer_id: string; envelope_id: string; token_hash: string }

const requestSignerVerificationCommand: CommandHandler<VerificationInput, { retryAfter: number }> = {
  id: 'agreements.signers.verification.request',
  async execute(rawInput, ctx) {
    const parsed = rawInput
    const em = getEntityManager(ctx)
    const signer = await em.findOne(Signer, { id: parsed.signer_id, tokenHash: parsed.token_hash })
    if (!signer) throw new CrudHttpError(404, { error: 'Signing link is invalid' })
    const envelope = await em.findOne(SigningEnvelope, { id: parsed.envelope_id, tenantId: signer.tenantId, organizationId: signer.organizationId, deletedAt: null } as FilterQuery<SigningEnvelope>)
    if (!envelope || envelope.id !== signer.envelopeId) throw new CrudHttpError(404, { error: 'Signing link is invalid' })
    if (!envelope.requireEmailVerification) return { retryAfter: 0 }
    if (signer.verificationLockedUntil && signer.verificationLockedUntil > new Date()) throw new CrudHttpError(429, { error: 'Email verification is temporarily locked' })
    const now = new Date()
    const code = String(randomInt(100000, 1_000_000))
    signer.verificationCodeHash = createHash('sha256').update(code).digest('hex')
    signer.verificationExpiresAt = new Date(now.getTime() + 10 * 60 * 1000)
    signer.verificationAttempts = 0
    signer.verificationLockedUntil = null
    await withAtomicFlush(em, [async () => {
      await appendAuditEvent(em, {
        envelopeId: envelope.id,
        signerId: signer.id,
        tenantId: signer.tenantId,
        organizationId: signer.organizationId,
        eventType: 'verification.requested',
        actorKind: 'signer',
      })
    }], { transaction: true, label: 'agreements.signers.verification.request' })
    try {
      await sendEmail({
        to: signer.email,
        subject: 'Agreement email verification code',
        react: React.createElement('div', null, React.createElement('p', null, 'Your agreement verification code is:'), React.createElement('strong', null, code), React.createElement('p', null, 'This code expires in 10 minutes.')),
      })
    } catch {
      throw new CrudHttpError(503, { error: 'Email verification delivery is unavailable' })
    }
    return { retryAfter: 60 }
  },
  buildLog: () => ({ skipLog: true }),
}

const confirmSignerVerificationCommand: CommandHandler<VerificationInput & { code: string }, { verified: true }> = {
  id: 'agreements.signers.verification.confirm',
  async execute(rawInput, ctx) {
    const parsed = verificationConfirmSchema.parse({ code: rawInput.code })
    const em = getEntityManager(ctx)
    const signer = await em.findOne(Signer, { id: rawInput.signer_id, tokenHash: rawInput.token_hash })
    if (!signer) throw new CrudHttpError(404, { error: 'Signing link is invalid' })
    const envelope = await em.findOne(SigningEnvelope, { id: rawInput.envelope_id, tenantId: signer.tenantId, organizationId: signer.organizationId, deletedAt: null } as FilterQuery<SigningEnvelope>)
    if (!envelope || envelope.id !== signer.envelopeId) throw new CrudHttpError(404, { error: 'Signing link is invalid' })
    if (signer.verifiedAt) return { verified: true }
    if (!signer.verificationCodeHash || !signer.verificationExpiresAt || signer.verificationExpiresAt <= new Date()) throw new CrudHttpError(410, { error: 'Verification code has expired' })
    if (signer.verificationLockedUntil && signer.verificationLockedUntil > new Date()) throw new CrudHttpError(429, { error: 'Email verification is temporarily locked' })
    const expected = Buffer.from(signer.verificationCodeHash, 'hex')
    const actual = Buffer.from(createHash('sha256').update(parsed.code).digest('hex'), 'hex')
    if (expected.length !== actual.length || !timingSafeEqual(expected, actual)) {
      signer.verificationAttempts += 1
      if (signer.verificationAttempts >= 5) signer.verificationLockedUntil = new Date(Date.now() + 15 * 60 * 1000)
      await em.flush()
      throw new CrudHttpError(400, { error: 'Verification code is invalid' })
    }
    signer.verifiedAt = new Date()
    signer.verificationCodeHash = null
    signer.verificationExpiresAt = null
    signer.verificationAttempts = 0
    await withAtomicFlush(em, [async () => {
      await appendAuditEvent(em, {
        envelopeId: envelope.id,
        signerId: signer.id,
        tenantId: signer.tenantId,
        organizationId: signer.organizationId,
        eventType: 'verification.completed',
        actorKind: 'signer',
      })
    }], { transaction: true, label: 'agreements.signers.verification.confirm' })
    return { verified: true }
  },
  buildLog: () => ({ skipLog: true }),
}

const viewSignerCommand: CommandHandler<Record<string, unknown>, { status: string }> = {
  id: 'agreements.signers.view',
  async execute(rawInput, ctx) {
    const parsed = viewSignerCommandSchema.parse(rawInput)
    const em = getEntityManager(ctx)
    const tokenHash = parsed.token_hash
    const signer = await em.findOne(Signer, { id: parsed.signer_id, tokenHash })
    if (!signer) throw new CrudHttpError(404, { error: 'Signing link is invalid' })
    const envelope = await em.findOne(SigningEnvelope, {
      id: parsed.envelope_id,
      tenantId: signer.tenantId,
      organizationId: signer.organizationId,
      deletedAt: null,
    } as FilterQuery<SigningEnvelope>)
    if (!envelope || envelope.id !== signer.envelopeId) throw new CrudHttpError(404, { error: 'Signing link is invalid' })
    if (envelope.expiresAt && envelope.expiresAt <= new Date()) throw new CrudHttpError(410, { error: 'Signing link has expired' })
    if (signer.status === 'invited') {
      signer.status = 'viewed'
      await withAtomicFlush(em, [async () => {
        await appendAuditEvent(em, {
          envelopeId: envelope.id,
          signerId: signer.id,
          tenantId: signer.tenantId,
          organizationId: signer.organizationId,
          eventType: 'signer.viewed',
          actorKind: 'signer',
        })
      }], { transaction: true, label: 'agreements.signers.view' })
      await emitAgreementLifecycleEvent('agreements.signer.viewed', {
        id: signer.id,
        envelopeId: envelope.id,
        tenantId: signer.tenantId,
        organizationId: signer.organizationId,
      })
    }
    return { status: signer.status }
  },
  buildLog: () => ({ skipLog: true }),
}

const signEnvelopeCommand: CommandHandler<Record<string, unknown>, { status: string; duplicate?: boolean }> = {
  id: 'agreements.signers.sign',
  async execute(rawInput, ctx) {
    const parsed = publicSignCommandSchema.parse(rawInput)
    const em = getEntityManager(ctx)
    const signer = await em.findOne(Signer, { id: parsed.signer_id, tokenHash: parsed.token_hash })
    if (!signer) throw new CrudHttpError(404, { error: 'Signing link is invalid' })
    const envelope = await em.findOne(SigningEnvelope, {
      id: parsed.envelope_id,
      tenantId: signer.tenantId,
      organizationId: signer.organizationId,
      deletedAt: null,
    } as FilterQuery<SigningEnvelope>)
    if (!envelope || envelope.id !== signer.envelopeId) throw new CrudHttpError(404, { error: 'Signing link is invalid' })
    if (signer.status === 'signed') return { status: 'signed', duplicate: true }
    if (envelope.status !== 'sent' && envelope.status !== 'in_progress') throw new CrudHttpError(409, { error: 'Signing request is not active' })
    if (envelope.expiresAt && envelope.expiresAt <= new Date()) throw new CrudHttpError(410, { error: 'Signing request has expired' })
    const envelopeSigners = await em.find(Signer, {
      envelopeId: envelope.id,
      tenantId: signer.tenantId,
      organizationId: signer.organizationId,
    } as FilterQuery<Signer>)
    if (!canSignerSign(envelope.signingMode, signer.routingOrder, envelopeSigners)) {
      throw new CrudHttpError(409, { error: 'Another signer must complete first' })
    }
    if (envelope.requireEmailVerification && !signer.verifiedAt) {
      throw new CrudHttpError(409, { error: 'Email verification is required before signing' })
    }
    if (!parsed.consent_accepted) throw new CrudHttpError(400, { error: 'Electronic-signature consent is required' })
    const version = await findOneWithDecryption(
      em,
      AgreementVersion,
      { id: envelope.agreementVersionId, tenantId: signer.tenantId, organizationId: signer.organizationId } as FilterQuery<AgreementVersion>,
      undefined,
      { tenantId: signer.tenantId, organizationId: signer.organizationId },
    )
    if (!version) throw new CrudHttpError(404, { error: 'Agreement version is unavailable' })
    const expectedDisclosureHash = createHash('sha256').update(version.disclosureText).digest('hex')
    if (parsed.disclosure_hash !== expectedDisclosureHash) throw new CrudHttpError(409, { error: 'The disclosure has changed; reload the agreement' })
    const fields = await em.find(EnvelopeField, {
      envelopeId: envelope.id,
      signerId: signer.id,
      tenantId: signer.tenantId,
      organizationId: signer.organizationId,
    } as FilterQuery<EnvelopeField>)
    const fieldIds = new Set(fields.map((field) => String(field.id)))
    for (const key of Object.keys(parsed.field_values)) {
      if (!fieldIds.has(key)) throw new CrudHttpError(400, { error: 'A field does not belong to this signer' })
    }
    for (const field of fields) {
      if (field.required && !parsed.field_values[String(field.id)]?.trim() && field.fieldType !== 'signature' && field.fieldType !== 'date') {
        throw new CrudHttpError(400, { error: 'All required fields must be completed' })
      }
    }
    const existing = await em.findOne(Signature, { signerId: signer.id, tenantId: signer.tenantId, organizationId: signer.organizationId })
    if (existing) return { status: 'signed', duplicate: true }

    let completes = false
    try {
      await withAtomicFlush(em, [async () => {
        const signature = em.create(Signature, {
        id: randomUUID(),
        envelopeId: envelope.id,
        signerId: signer.id,
        tenantId: signer.tenantId,
        organizationId: signer.organizationId,
        method: parsed.method,
        valueText: parsed.value_text,
        consentAccepted: true,
        disclosureHash: parsed.disclosure_hash,
        documentHash: version.contentHash,
        fieldValuesJson: parsed.field_values,
        signedAt: new Date(),
        ipAddress: parsed.ip_address ?? null,
        userAgent: parsed.user_agent ?? null,
        createdAt: new Date(),
      })
        signer.status = 'signed'
        signer.signedAt = signature.signedAt
        const remaining = await em.find(Signer, {
          envelopeId: envelope.id,
          tenantId: signer.tenantId,
          organizationId: signer.organizationId,
        } as FilterQuery<Signer>)
        completes = remaining.filter((candidate) => candidate.id !== signer.id && candidate.status !== 'signed').length === 0
        envelope.status = completes ? 'finalizing' : 'in_progress'
        if (completes) envelope.completedAt = signature.signedAt
        em.persist(signature)
        await appendAuditEvent(em, {
          envelopeId: envelope.id,
          signerId: signer.id,
          tenantId: signer.tenantId,
          organizationId: signer.organizationId,
          eventType: 'signer.signed',
          actorKind: 'signer',
          metadataJson: { method: parsed.method, documentHash: version.contentHash },
        })
        if (completes) {
          await appendAuditEvent(em, {
            envelopeId: envelope.id,
            tenantId: signer.tenantId,
            organizationId: signer.organizationId,
            eventType: 'envelope.completed',
            actorKind: 'system',
          })
        }
      }], { transaction: true, label: 'agreements.signers.sign' })
    } catch (error) {
      if (isDuplicateKeyError(error)) return { status: 'signed', duplicate: true }
      throw error
    }
    await emitAgreementLifecycleEvent('agreements.signer.signed', {
      id: signer.id,
      envelopeId: envelope.id,
      tenantId: signer.tenantId,
      organizationId: signer.organizationId,
      status: envelope.status,
    })
    if (completes) {
      try {
        await finalizeCompletedEnvelope(em, envelope, version, { tenantId: signer.tenantId, organizationId: signer.organizationId })
      } catch (error) {
        // The signer state is durable even if finalization needs a retry. Do not
        // turn a completed signing action into a duplicate submission.
        await emitAgreementLifecycleEvent('agreements.evidence.failed', {
          id: envelope.id,
          tenantId: signer.tenantId,
          organizationId: signer.organizationId,
          reason: error instanceof Error ? error.message : 'finalization_failed',
        })
      }
      await emitAgreementLifecycleEvent('agreements.envelope.completed', {
        id: envelope.id,
        tenantId: signer.tenantId,
        organizationId: signer.organizationId,
      })
    }
    return { status: envelope.status }
  },
  buildLog: () => ({ skipLog: true }),
}

const declineSignerCommand: CommandHandler<Record<string, unknown>, { status: string }> = {
  id: 'agreements.signers.decline',
  async execute(rawInput, ctx) {
    const parsed = declineSignerSchema.parse(rawInput)
    const em = getEntityManager(ctx)
    const signer = await em.findOne(Signer, { id: parsed.signer_id, tokenHash: parsed.token_hash })
    if (!signer || signer.envelopeId !== parsed.envelope_id) throw new CrudHttpError(404, { error: 'Signing link is invalid' })
    const envelope = await em.findOne(SigningEnvelope, {
      id: parsed.envelope_id,
      tenantId: signer.tenantId,
      organizationId: signer.organizationId,
      deletedAt: null,
    } as FilterQuery<SigningEnvelope>)
    if (!envelope) throw new CrudHttpError(404, { error: 'Signing link is invalid' })
    if (signer.status === 'signed') throw new CrudHttpError(409, { error: 'A signed agreement cannot be declined' })
    if (envelope.status !== 'sent' && envelope.status !== 'in_progress') throw new CrudHttpError(409, { error: 'Signing request is not active' })
    if (envelope.expiresAt && envelope.expiresAt <= new Date()) throw new CrudHttpError(410, { error: 'Signing request has expired' })
    signer.status = 'declined'
    signer.declinedAt = new Date()
    signer.declineReason = parsed.reason
    envelope.status = 'declined'
    await withAtomicFlush(em, [async () => {
      await appendAuditEvent(em, {
        envelopeId: envelope.id,
        signerId: signer.id,
        tenantId: signer.tenantId,
        organizationId: signer.organizationId,
        eventType: 'signer.declined',
        actorKind: 'signer',
      })
    }], { transaction: true, label: 'agreements.signers.decline' })
    await emitAgreementLifecycleEvent('agreements.signer.declined', {
      id: signer.id,
      envelopeId: envelope.id,
      tenantId: signer.tenantId,
      organizationId: signer.organizationId,
    })
    return { status: envelope.status }
  },
  buildLog: () => ({ skipLog: true }),
}

registerCommand(createAgreementCommand)
registerCommand(updateAgreementCommand)
registerCommand(deleteAgreementCommand)
registerCommand(publishAgreementCommand)
registerCommand(sendEnvelopeCommand)
registerCommand(requestSignerVerificationCommand)
registerCommand(confirmSignerVerificationCommand)
registerCommand(viewSignerCommand)
registerCommand(signEnvelopeCommand)
registerCommand(declineSignerCommand)

export { publishAgreementCommand, sendEnvelopeCommand, requestSignerVerificationCommand, confirmSignerVerificationCommand, signEnvelopeCommand, viewSignerCommand, declineSignerCommand }
