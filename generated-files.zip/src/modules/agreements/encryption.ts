import type { ModuleEncryptionMap } from '@open-mercato/shared/modules/encryption'

const defaultEncryptionMaps: ModuleEncryptionMap[] = [
  {
    entityId: 'agreements:agreement',
    fields: [{ field: 'draft_content_html' }],
  },
  {
    entityId: 'agreements:agreement_version',
    fields: [{ field: 'content_html' }, { field: 'disclosure_text' }],
  },
  {
    entityId: 'agreements:signer',
    fields: [{ field: 'email' }, { field: 'decline_reason' }],
  },
  {
    entityId: 'agreements:signature',
    fields: [{ field: 'value_text' }, { field: 'ip_address' }, { field: 'user_agent' }],
  },
]

export { defaultEncryptionMaps }
export default defaultEncryptionMaps
