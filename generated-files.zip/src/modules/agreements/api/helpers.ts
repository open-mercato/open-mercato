import { getAuthFromRequest } from '@open-mercato/shared/lib/auth/server'
import { createRequestContainer } from '@open-mercato/shared/lib/di/container'
import type { CommandRuntimeContext } from '@open-mercato/shared/lib/commands'
import type { AuthContext } from '@open-mercato/shared/lib/auth/server'

export async function resolveAgreementRequest(request: Request) {
  const auth = await getAuthFromRequest(request)
  const container = await createRequestContainer()
  return { auth, container }
}

export function commandContext(
  container: Awaited<ReturnType<typeof createRequestContainer>>,
  auth: AuthContext,
): CommandRuntimeContext {
  return {
    container,
    auth,
    organizationScope: auth?.orgId
      ? {
          selectedId: auth.orgId,
          filterIds: [auth.orgId],
          allowedIds: [auth.orgId],
          tenantId: auth.tenantId,
        }
      : null,
    selectedOrganizationId: auth?.orgId ?? null,
    organizationIds: auth?.orgId ? [auth.orgId] : [],
  }
}

export function requestError(error: unknown, fallback = 'Request failed'): Response {
  const status = typeof error === 'object' && error !== null && 'status' in error && typeof error.status === 'number'
    ? error.status
    : typeof error === 'object' && error !== null && 'statusCode' in error && typeof error.statusCode === 'number'
      ? error.statusCode
      : 500
  const message = error instanceof Error ? error.message : fallback
  return Response.json({ error: message }, { status })
}

export function publicRequestError(status: number, message = 'Signing link is invalid'): Response {
  return Response.json({ error: message }, { status })
}
