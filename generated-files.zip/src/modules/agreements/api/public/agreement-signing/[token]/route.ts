import { createHash } from 'node:crypto'
import { z } from 'zod'
import type { EntityManager, FilterQuery } from '@mikro-orm/postgresql'
import { readJsonSafe } from '@open-mercato/shared/lib/http/readJsonSafe'
import { findOneWithDecryption } from '@open-mercato/shared/lib/encryption/find'
import type { OpenApiMethodDoc, OpenApiRouteDoc } from '@open-mercato/shared/lib/openapi'
import { commandContext, publicRequestError, requestError, resolveAgreementRequest } from '../../../helpers'
import { Agreement, AgreementVersion, EnvelopeField, Signer, SigningEnvelope } from '../../../../data/entities'
import { publicSignSchema } from '../../../../data/validators'
import { agreementsTag, agreementErrorSchema, publicSigningResponseSchema, publicSigningResultSchema } from '../../../../api/openapi'
import { signerTokenHash } from '../../../../lib/tokens'
import { canSignerSign } from '../../../../lib/routing'

export const metadata = {
  GET: { requireAuth: false },
  POST: { requireAuth: false },
}

async function resolveSigner(request: Request, token: string) {
  if (!token || token.length < 20 || token.length > 200) return null
  const { container } = await resolveAgreementRequest(request)
  const em = container.resolve<EntityManager>('em')
  const tokenHash = signerTokenHash(token)
  const signer = await em.findOne(Signer, { tokenHash })
  if (!signer) return null
  const envelope = await em.findOne(SigningEnvelope, {
    id: signer.envelopeId,
    tenantId: signer.tenantId,
    organizationId: signer.organizationId,
    deletedAt: null,
  } as FilterQuery<SigningEnvelope>)
  if (!envelope) return null
  return { container, em, signer, envelope, tokenHash }
}

export async function GET(request: Request, ctx: { params: { token: string } }) {
  const resolved = await resolveSigner(request, ctx.params.token)
  if (!resolved) return publicRequestError(404)
  try {
    const { container, em, signer, envelope, tokenHash } = resolved
    const commandBus = container.resolve<any>('commandBus')
    await commandBus.execute('agreements.signers.view', {
      input: { signer_id: signer.id, envelope_id: envelope.id, token_hash: tokenHash },
      ctx: commandContext(container, null),
    })
    if (envelope.expiresAt && envelope.expiresAt <= new Date()) return publicRequestError(410, 'Signing link has expired')
    const version = await findOneWithDecryption(
      em,
      AgreementVersion,
      { id: envelope.agreementVersionId, tenantId: signer.tenantId, organizationId: signer.organizationId } as FilterQuery<AgreementVersion>,
      undefined,
      { tenantId: signer.tenantId, organizationId: signer.organizationId },
    )
    const agreement = await em.findOne(Agreement, {
      id: envelope.agreementId,
      tenantId: signer.tenantId,
      organizationId: signer.organizationId,
      deletedAt: null,
    } as FilterQuery<Agreement>)
    if (!version || !agreement) return publicRequestError(404)
    const envelopeSigners = await em.find(Signer, {
      envelopeId: envelope.id,
      tenantId: signer.tenantId,
      organizationId: signer.organizationId,
    } as FilterQuery<Signer>)
    const canSign = canSignerSign(envelope.signingMode, signer.routingOrder, envelopeSigners)
    const fields = await em.find(EnvelopeField, { envelopeId: envelope.id, signerId: signer.id, tenantId: signer.tenantId, organizationId: signer.organizationId })
    return Response.json({
      signerId: signer.id,
      envelopeId: envelope.id,
      title: agreement.title,
      contentHtml: version.contentHtml,
      disclosureText: version.disclosureText,
      disclosureHash: createHash('sha256').update(version.disclosureText).digest('hex'),
      signingMode: envelope.signingMode,
      envelopeStatus: envelope.status,
      signerStatus: signer.status === 'invited' ? 'viewed' : signer.status,
      canSign,
      displayName: signer.displayName,
      requireEmailVerification: envelope.requireEmailVerification,
      verified: Boolean(signer.verifiedAt),
      fields: fields.map((field) => ({
        id: String(field.id), fieldType: field.fieldType, pageNumber: field.pageNumber,
        x: Number(field.x), y: Number(field.y), width: Number(field.width), height: Number(field.height),
        required: field.required, label: field.label ?? null,
      })),
      pdfDocumentUrl: version.uploadedPdfArtifactId ? `/api/public/agreement-signing/${encodeURIComponent(ctx.params.token)}/document` : null,
      expiresAt: envelope.expiresAt?.toISOString() ?? null,
    })
  } catch (error) {
    return requestError(error)
  }
}

export async function POST(request: Request, ctx: { params: { token: string } }) {
  const resolved = await resolveSigner(request, ctx.params.token)
  if (!resolved) return publicRequestError(404)
  const { container, signer, envelope, tokenHash } = resolved
  const body = await readJsonSafe<unknown>(request, {})
  const parsed = publicSignSchema.safeParse({
    ...(body && typeof body === 'object' && !Array.isArray(body) ? body : {}),
    signer_id: signer.id,
    envelope_id: envelope.id,
  })
  if (!parsed.success) return Response.json({ error: 'Invalid signature payload' }, { status: 400 })
  try {
    const commandBus = container.resolve<any>('commandBus')
    const { result } = await commandBus.execute('agreements.signers.sign', {
      input: {
        ...parsed.data,
        token_hash: tokenHash,
        ip_address: request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || request.headers.get('x-real-ip') || null,
        user_agent: request.headers.get('user-agent') ?? undefined,
      },
      ctx: commandContext(container, null),
    })
    return Response.json(result)
  } catch (error) {
    return requestError(error)
  }
}

const tokenParamsSchema = z.object({ token: z.string().min(20).max(200) })
const signingGetDoc: OpenApiMethodDoc = {
  summary: 'Read a public agreement signing ceremony',
  tags: [agreementsTag],
  responses: [{ status: 200, description: 'Agreement content and signing state.', schema: publicSigningResponseSchema }],
  errors: [
    { status: 404, description: 'Invalid signing link.', schema: agreementErrorSchema },
    { status: 410, description: 'Expired signing link.', schema: agreementErrorSchema },
  ],
}
const signingPostDoc: OpenApiMethodDoc = {
  summary: 'Submit an ordinary electronic signature',
  tags: [agreementsTag],
  requestBody: { schema: publicSignSchema.omit({ signer_id: true, envelope_id: true }) },
  responses: [{ status: 200, description: 'Signature recorded.', schema: publicSigningResultSchema }],
  errors: [
    { status: 400, description: 'Invalid signature or missing consent.', schema: agreementErrorSchema },
    { status: 404, description: 'Invalid signing link.', schema: agreementErrorSchema },
    { status: 409, description: 'Signing cannot proceed in the current state.', schema: agreementErrorSchema },
    { status: 410, description: 'Expired signing link.', schema: agreementErrorSchema },
  ],
}

export const openApi: OpenApiRouteDoc = {
  tag: agreementsTag,
  summary: 'Public agreement signing',
  pathParams: tokenParamsSchema,
  methods: { GET: signingGetDoc, POST: signingPostDoc },
}
