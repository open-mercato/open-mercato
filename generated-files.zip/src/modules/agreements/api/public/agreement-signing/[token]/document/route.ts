import type { EntityManager, FilterQuery } from '@mikro-orm/postgresql'
import { publicRequestError, resolveAgreementRequest } from '@/modules/agreements/api/helpers'
import { AgreementVersion, Signer, SigningEnvelope } from '@/modules/agreements/data/entities'
import { signerTokenHash } from '@/modules/agreements/lib/tokens'
import { readAgreementArtifact } from '@/modules/agreements/lib/artifacts'

export const metadata = { GET: { requireAuth: false } }

export async function GET(request: Request, ctx: { params: { token: string } }) {
  if (!ctx.params.token || ctx.params.token.length < 20) return publicRequestError(404)
  const { container } = await resolveAgreementRequest(request)
  const em = container.resolve<EntityManager>('em')
  const tokenHash = signerTokenHash(ctx.params.token)
  const signer = await em.findOne(Signer, { tokenHash })
  if (!signer) return publicRequestError(404)
  const envelope = await em.findOne(SigningEnvelope, { id: signer.envelopeId, tenantId: signer.tenantId, organizationId: signer.organizationId, deletedAt: null } as FilterQuery<SigningEnvelope>)
  if (!envelope || (envelope.status !== 'completed' && signer.status !== 'signed')) return publicRequestError(404)
  const version = await em.findOne(AgreementVersion, { id: envelope.agreementVersionId, tenantId: signer.tenantId, organizationId: signer.organizationId } as FilterQuery<AgreementVersion>)
  if (!version?.uploadedPdfArtifactId) return publicRequestError(404)
  try {
    const buffer = await readAgreementArtifact(em, version.uploadedPdfArtifactId, { tenantId: signer.tenantId, organizationId: signer.organizationId })
    return new Response(buffer as unknown as BodyInit, { status: 200, headers: { 'content-type': 'application/pdf', 'cache-control': 'private, no-store' } })
  } catch {
    return publicRequestError(404)
  }
}
