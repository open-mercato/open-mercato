import { z } from 'zod'
import { readJsonSafe } from '@open-mercato/shared/lib/http/readJsonSafe'
import type { OpenApiMethodDoc, OpenApiRouteDoc } from '@open-mercato/shared/lib/openapi'
import { commandContext, publicRequestError, requestError, resolveAgreementRequest } from '../../../../helpers'
import { declineSignerSchema } from '../../../../../data/validators'
import { agreementsTag, agreementErrorSchema, publicSigningResultSchema } from '../../../../../api/openapi'
import { Signer, SigningEnvelope } from '../../../../../data/entities'
import { signerTokenHash } from '../../../../../lib/tokens'

export const metadata = {
  POST: { requireAuth: false },
}

export async function POST(request: Request, ctx: { params: { token: string } }) {
  const token = ctx.params.token
  if (!token || token.length < 20 || token.length > 200) return publicRequestError(404)
  const { container } = await resolveAgreementRequest(request)
  const em = container.resolve<any>('em')
  const tokenHash = signerTokenHash(token)
  const signer = await em.findOne(Signer, { tokenHash })
  if (!signer) return publicRequestError(404)
  const envelope = await em.findOne(SigningEnvelope, { id: signer.envelopeId, tenantId: signer.tenantId, organizationId: signer.organizationId, deletedAt: null })
  if (!envelope) return publicRequestError(404)
  const body = await readJsonSafe<unknown>(request, {})
  const parsed = declineSignerSchema.safeParse({
    ...(body && typeof body === 'object' && !Array.isArray(body) ? body : {}),
    signer_id: signer.id,
    envelope_id: envelope.id,
    token_hash: tokenHash,
  })
  if (!parsed.success) return Response.json({ error: 'A decline reason is required' }, { status: 400 })
  try {
    const commandBus = container.resolve<any>('commandBus')
    const result = await commandBus.execute('agreements.signers.decline', {
      input: parsed.data,
      ctx: commandContext(container, null),
    })
    return Response.json(result)
  } catch (error) {
    return requestError(error)
  }
}

const declineDoc: OpenApiMethodDoc = {
  summary: 'Decline an agreement signing request',
  tags: [agreementsTag],
  requestBody: { schema: z.object({ reason: z.string().min(1).max(2_000) }) },
  responses: [{ status: 200, description: 'Signing request declined.', schema: publicSigningResultSchema }],
  errors: [
    { status: 400, description: 'A decline reason is required.', schema: agreementErrorSchema },
    { status: 404, description: 'Invalid signing link.', schema: agreementErrorSchema },
    { status: 409, description: 'A signed agreement cannot be declined.', schema: agreementErrorSchema },
  ],
}

export const openApi: OpenApiRouteDoc = {
  tag: agreementsTag,
  summary: 'Decline agreement signing',
  pathParams: z.object({ token: z.string().min(20).max(200) }),
  methods: { POST: declineDoc },
}
