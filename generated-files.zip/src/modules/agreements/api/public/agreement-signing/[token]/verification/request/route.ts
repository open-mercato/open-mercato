import { readJsonSafe } from '@open-mercato/shared/lib/http/readJsonSafe'
import { commandContext, publicRequestError, requestError, resolveAgreementRequest } from '@/modules/agreements/api/helpers'
import { Signer, SigningEnvelope } from '@/modules/agreements/data/entities'
import { signerTokenHash } from '@/modules/agreements/lib/tokens'

export const metadata = { POST: { requireAuth: false } }

export async function POST(request: Request, ctx: { params: { token: string } }) {
  const { container } = await resolveAgreementRequest(request)
  const tokenHash = signerTokenHash(ctx.params.token)
  const body = (await readJsonSafe<{ signer_id?: string; envelope_id?: string }>(request, {})) ?? {}
  if (!body.signer_id || !body.envelope_id) return publicRequestError(400, 'Invalid verification request')
  const em = container.resolve<any>('em')
  const signer = await em.findOne(Signer, { id: body.signer_id, tokenHash })
  if (!signer) return publicRequestError(404)
  const envelope = await em.findOne(SigningEnvelope, { id: body.envelope_id, tenantId: signer.tenantId, organizationId: signer.organizationId, deletedAt: null })
  if (!envelope || envelope.id !== signer.envelopeId) return publicRequestError(404)
  try {
    const { result } = await container.resolve<any>('commandBus').execute('agreements.signers.verification.request', {
      input: { signer_id: signer.id, envelope_id: envelope.id, token_hash: tokenHash },
      ctx: commandContext(container, null),
    })
    return Response.json(result)
  } catch (error) {
    return requestError(error)
  }
}
