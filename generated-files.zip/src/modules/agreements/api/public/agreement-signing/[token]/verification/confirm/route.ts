import { readJsonSafe } from '@open-mercato/shared/lib/http/readJsonSafe'
import { commandContext, publicRequestError, requestError, resolveAgreementRequest } from '@/modules/agreements/api/helpers'
import { Signer, SigningEnvelope } from '@/modules/agreements/data/entities'
import { signerTokenHash } from '@/modules/agreements/lib/tokens'
import { verificationConfirmSchema } from '@/modules/agreements/data/validators'

export const metadata = { POST: { requireAuth: false } }

export async function POST(request: Request, ctx: { params: { token: string } }) {
  const { container } = await resolveAgreementRequest(request)
  const tokenHash = signerTokenHash(ctx.params.token)
  const body = await readJsonSafe<unknown>(request, {})
  const parsed = verificationConfirmSchema.safeParse(body)
  if (!parsed.success) return publicRequestError(400, 'Invalid verification code')
  const signerId = request.headers.get('x-agreement-signer-id')
  const envelopeId = request.headers.get('x-agreement-envelope-id')
  if (!signerId || !envelopeId) return publicRequestError(400, 'Invalid verification request')
  const em = container.resolve<any>('em')
  const signer = await em.findOne(Signer, { id: signerId, tokenHash })
  if (!signer) return publicRequestError(404)
  const envelope = await em.findOne(SigningEnvelope, { id: envelopeId, tenantId: signer.tenantId, organizationId: signer.organizationId, deletedAt: null })
  if (!envelope || envelope.id !== signer.envelopeId) return publicRequestError(404)
  try {
    const { result } = await container.resolve<any>('commandBus').execute('agreements.signers.verification.confirm', {
      input: { signer_id: signer.id, envelope_id: envelope.id, token_hash: tokenHash, code: parsed.data.code },
      ctx: commandContext(container, null),
    })
    return Response.json(result)
  } catch (error) {
    return requestError(error)
  }
}
