import { z, type ZodTypeAny } from 'zod'
import type { OpenApiRouteDoc } from '@open-mercato/shared/lib/openapi'
import {
  createCrudOpenApiFactory,
  createPagedListResponseSchema,
  type CrudOpenApiOptions,
} from '@open-mercato/shared/lib/openapi/crud'

export const agreementsTag = 'Agreements'

export const agreementErrorSchema = z.object({ error: z.string() }).passthrough()

export const agreementListItemSchema = z.object({
  id: z.string().uuid(),
  title: z.string(),
  description: z.string().nullable().optional(),
  draft_content_html: z.string().nullable().optional(),
  status: z.enum(['draft', 'published', 'archived']),
  published_version_id: z.string().uuid().nullable().optional(),
  tenant_id: z.string().uuid().nullable().optional(),
  organization_id: z.string().uuid().nullable().optional(),
  updatedAt: z.string().nullable().optional(),
}).passthrough()

export const agreementCreatedSchema = z.object({ id: z.string().uuid() })
export const agreementOkSchema = z.object({ ok: z.literal(true) })

export const publishAgreementResponseSchema = z.object({
  id: z.string().uuid(),
  versionId: z.string().uuid(),
  contentHash: z.string(),
  updatedAt: z.string(),
})

export const sendEnvelopeResponseSchema = z.object({
  envelopeId: z.string().uuid(),
  links: z.array(z.object({
    signerId: z.string().uuid(),
    displayName: z.string(),
    email: z.string().email(),
    link: z.string().url(),
  })),
})

export const publicSigningResponseSchema = z.object({
  signerId: z.string().uuid(),
  envelopeId: z.string().uuid(),
  title: z.string(),
  contentHtml: z.string(),
  disclosureText: z.string(),
  disclosureHash: z.string(),
  signingMode: z.enum(['sequential', 'parallel']),
  envelopeStatus: z.string(),
  signerStatus: z.string(),
  canSign: z.boolean(),
  displayName: z.string(),
  requireEmailVerification: z.boolean(),
  verified: z.boolean(),
  fields: z.array(z.object({
    id: z.string().uuid(), fieldType: z.enum(['signature', 'initials', 'date', 'text']), pageNumber: z.number(),
    x: z.number(), y: z.number(), width: z.number(), height: z.number(), required: z.boolean(), label: z.string().nullable(),
  })),
  pdfDocumentUrl: z.string().nullable(),
  expiresAt: z.string().nullable(),
})

export const publicSigningResultSchema = z.object({ status: z.string(), duplicate: z.boolean().optional() })

export function createAgreementsPagedListResponseSchema(itemSchema: ZodTypeAny) {
  return createPagedListResponseSchema(itemSchema, { paginationMetaOptional: true })
}

const buildCrudOpenApi = createCrudOpenApiFactory({
  defaultTag: agreementsTag,
  defaultCreateResponseSchema: agreementCreatedSchema,
  defaultOkResponseSchema: agreementOkSchema,
  makeListDescription: ({ pluralLower }) =>
    `Returns a paginated collection of ${pluralLower} in the current tenant and organization scope.`,
})

export function createAgreementsCrudOpenApi(options: CrudOpenApiOptions): OpenApiRouteDoc {
  return buildCrudOpenApi(options)
}
