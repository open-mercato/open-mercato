import { z } from 'zod'
import { readJsonSafe } from '@open-mercato/shared/lib/http/readJsonSafe'
import type { OpenApiMethodDoc, OpenApiRouteDoc } from '@open-mercato/shared/lib/openapi'
import { commandContext, requestError, resolveAgreementRequest } from '../../../helpers'
import { publishAgreementSchema } from '../../../../data/validators'
import { agreementsTag, agreementErrorSchema, publishAgreementResponseSchema } from '../../../../api/openapi'

export const metadata = {
  POST: { requireAuth: true, requireFeatures: ['agreements.manage'] },
}

export async function POST(request: Request, ctx: { params: { id: string } }) {
  const { auth, container } = await resolveAgreementRequest(request)
  if (!auth?.tenantId || !auth.orgId) return Response.json({ error: 'Organization scope required' }, { status: 400 })
  const body = await readJsonSafe<unknown>(request, {})
  const parsed = publishAgreementSchema.safeParse({
    ...(body && typeof body === 'object' && !Array.isArray(body) ? body : {}),
    id: ctx.params.id,
  })
  if (!parsed.success) return Response.json({ error: 'Invalid publish payload' }, { status: 400 })
  try {
    const commandBus = container.resolve<any>('commandBus')
    const result = await commandBus.execute('agreements.versions.publish', {
      input: parsed.data,
      ctx: commandContext(container, auth),
    })
    return Response.json(result)
  } catch (error) {
    return requestError(error)
  }
}

const publishDoc: OpenApiMethodDoc = {
  summary: 'Publish an immutable agreement version',
  tags: [agreementsTag],
  requestBody: { schema: z.object({ disclosure_text: z.string().min(1).max(10_000) }) },
  responses: [{ status: 200, description: 'Published version.', schema: publishAgreementResponseSchema }],
  errors: [
    { status: 400, description: 'Invalid payload or missing organization scope.', schema: agreementErrorSchema },
    { status: 401, description: 'Authentication required.', schema: agreementErrorSchema },
    { status: 409, description: 'Agreement is not publishable.', schema: agreementErrorSchema },
  ],
}

export const openApi: OpenApiRouteDoc = {
  tag: agreementsTag,
  summary: 'Publish an agreement',
  pathParams: z.object({ id: z.string().uuid() }),
  methods: { POST: publishDoc },
}
