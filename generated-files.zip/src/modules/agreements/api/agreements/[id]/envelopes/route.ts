import { z } from 'zod'
import { readJsonSafe } from '@open-mercato/shared/lib/http/readJsonSafe'
import type { OpenApiMethodDoc, OpenApiRouteDoc } from '@open-mercato/shared/lib/openapi'
import { commandContext, requestError, resolveAgreementRequest } from '../../../helpers'
import { sendEnvelopeSchema } from '../../../../data/validators'
import { agreementsTag, agreementErrorSchema, sendEnvelopeResponseSchema } from '../../../../api/openapi'

export const metadata = {
  POST: { requireAuth: true, requireFeatures: ['agreements.manage'] },
}

export async function POST(request: Request, ctx: { params: { id: string } }) {
  const { auth, container } = await resolveAgreementRequest(request)
  if (!auth?.tenantId || !auth.orgId) return Response.json({ error: 'Organization scope required' }, { status: 400 })
  const body = await readJsonSafe<unknown>(request, {})
  const parsed = sendEnvelopeSchema.safeParse({
    ...(body && typeof body === 'object' && !Array.isArray(body) ? body : {}),
    agreement_id: ctx.params.id,
  })
  if (!parsed.success) return Response.json({ error: 'Invalid envelope payload' }, { status: 400 })
  try {
    const commandBus = container.resolve<any>('commandBus')
    const { result } = await commandBus.execute('agreements.envelopes.send', {
      input: parsed.data,
      ctx: commandContext(container, auth),
    })
    const baseUrl = new URL(`/agreements/sign/`, request.url)
    return Response.json({
      envelopeId: result.envelopeId,
      links: result.links.map((link: { signerId: string; displayName: string; email: string; token: string }) => ({
        signerId: link.signerId,
        displayName: link.displayName,
        email: link.email,
        link: new URL(link.token, baseUrl).toString(),
      })),
    }, { status: 201 })
  } catch (error) {
    return requestError(error)
  }
}

const envelopeDoc: OpenApiMethodDoc = {
  summary: 'Create a multi-signer agreement envelope',
  tags: [agreementsTag],
  requestBody: { schema: sendEnvelopeSchema.omit({ agreement_id: true }) },
  responses: [{ status: 201, description: 'Envelope created with one link per signer.', schema: sendEnvelopeResponseSchema }],
  errors: [
    { status: 400, description: 'Invalid payload or missing organization scope.', schema: agreementErrorSchema },
    { status: 401, description: 'Authentication required.', schema: agreementErrorSchema },
    { status: 409, description: 'A published agreement version is required.', schema: agreementErrorSchema },
  ],
}

export const openApi: OpenApiRouteDoc = {
  tag: agreementsTag,
  summary: 'Send an agreement for signing',
  pathParams: z.object({ id: z.string().uuid() }),
  methods: { POST: envelopeDoc },
}
