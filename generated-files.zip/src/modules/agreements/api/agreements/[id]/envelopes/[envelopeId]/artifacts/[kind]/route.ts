import type { EntityManager, FilterQuery } from '@mikro-orm/postgresql'
import { AgreementArtifact, SigningEnvelope } from '@/modules/agreements/data/entities'
import { resolveAgreementRequest } from '@/modules/agreements/api/helpers'
import { readAgreementArtifact } from '@/modules/agreements/lib/artifacts'

export const metadata = { GET: { requireAuth: true, requireFeatures: ['agreements.view'] } }

export async function GET(request: Request, ctx: { params: { id: string; envelopeId: string; kind: string } }) {
  const { auth, container } = await resolveAgreementRequest(request)
  if (!auth?.tenantId || !auth.orgId) return Response.json({ error: 'Organization scope required' }, { status: 400 })
  if (ctx.params.kind !== 'final' && ctx.params.kind !== 'certificate') return Response.json({ error: 'Artifact not found' }, { status: 404 })
  const em = container.resolve<EntityManager>('em')
  const envelope = await em.findOne(SigningEnvelope, { id: ctx.params.envelopeId, agreementId: ctx.params.id, tenantId: auth.tenantId, organizationId: auth.orgId, deletedAt: null } as FilterQuery<SigningEnvelope>)
  if (!envelope) return Response.json({ error: 'Artifact not found' }, { status: 404 })
  const artifactId = ctx.params.kind === 'final' ? envelope.finalArtifactId : envelope.certificateArtifactId
  if (!artifactId) return Response.json({ error: 'Artifact is not ready' }, { status: 404 })
  const artifact = await em.findOne(AgreementArtifact, { id: artifactId, tenantId: auth.tenantId, organizationId: auth.orgId })
  if (!artifact) return Response.json({ error: 'Artifact not found' }, { status: 404 })
  try {
    const buffer = await readAgreementArtifact(em, artifact.id, { tenantId: auth.tenantId, organizationId: auth.orgId })
    return new Response(buffer as unknown as BodyInit, { status: 200, headers: { 'content-type': artifact.contentType, 'content-disposition': `attachment; filename="${artifact.fileName.replace(/[^a-zA-Z0-9._-]/g, '_')}"`, 'cache-control': 'private, no-store' } })
  } catch {
    return Response.json({ error: 'Artifact is unavailable' }, { status: 404 })
  }
}
