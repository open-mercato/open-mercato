import { z } from 'zod'
import { makeCrudRoute } from '@open-mercato/shared/lib/crud/factory'
import { escapeLikePattern } from '@open-mercato/shared/lib/db/escapeLikePattern'
import type { OpenApiRouteDoc } from '@open-mercato/shared/lib/openapi'
import { Agreement } from '../../data/entities'
import { agreementCrudEvents } from '../../commands/agreements'
import { agreementListSchema } from '../../data/validators'
import {
  agreementCreatedSchema,
  agreementErrorSchema,
  agreementListItemSchema,
  agreementOkSchema,
  createAgreementsPagedListResponseSchema,
  createAgreementsCrudOpenApi,
} from '../openapi'

const entityId = 'agreements:agreement' as const
const rawBodySchema = z.object({}).passthrough()

function isSingleRecordRequest(query: { id?: string; ids?: string }): boolean {
  return Boolean(query.id || query.ids)
}

function toIsoTimestamp(value: unknown): string | null {
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value.toISOString()
  if (typeof value === 'string' || typeof value === 'number') {
    const parsed = new Date(value)
    return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString()
  }
  return null
}

export const { metadata, GET, POST, PUT, DELETE } = makeCrudRoute({
  metadata: {
    GET: { requireAuth: true, requireFeatures: ['agreements.view'] },
    POST: { requireAuth: true, requireFeatures: ['agreements.manage'] },
    PUT: { requireAuth: true, requireFeatures: ['agreements.manage'] },
    DELETE: { requireAuth: true, requireFeatures: ['agreements.manage'] },
  },
  orm: {
    entity: Agreement,
    idField: 'id',
    orgField: 'organizationId',
    tenantField: 'tenantId',
    softDeleteField: 'deletedAt',
  },
  events: agreementCrudEvents,
  list: {
    schema: agreementListSchema,
    entityId,
    fields: (query) => [
      'id',
      'title',
      'status',
      'published_version_id',
      'tenant_id',
      'organization_id',
      'created_at',
      'updated_at',
      ...(isSingleRecordRequest(query) ? ['description', 'draft_content_html'] : []),
    ],
    sortFieldMap: {
      id: 'id',
      title: 'title',
      status: 'status',
      created_at: 'created_at',
      updated_at: 'updated_at',
      updatedAt: 'updated_at',
    },
    buildFilters: (query) => {
      const filters: Record<string, unknown> = {}
      if (query.id) filters.id = query.id
      if (query.ids) {
        const ids = query.ids.split(',').map((value) => value.trim()).filter(Boolean)
        if (ids.length > 0) filters.id = { $in: ids }
      }
      if (query.title) filters.title = { $ilike: `%${escapeLikePattern(query.title)}%` }
      if (query.status) filters.status = query.status
      return filters
    },
    transformItem: (item) => ({
      id: String(item.id),
      title: String(item.title),
      description: typeof item.description === 'string' ? item.description : null,
      draft_content_html: typeof item.draft_content_html === 'string' ? item.draft_content_html : null,
      status: String(item.status),
      published_version_id: item.published_version_id ?? null,
      tenant_id: item.tenant_id ?? null,
      organization_id: item.organization_id ?? null,
      updatedAt: toIsoTimestamp(item.updated_at),
    }),
  },
  actions: {
    create: {
      commandId: 'agreements.agreements.create',
      schema: rawBodySchema,
      mapInput: ({ parsed }) => parsed,
      response: ({ result }) => ({ id: String(result.id) }),
      status: 201,
    },
    update: {
      commandId: 'agreements.agreements.update',
      schema: rawBodySchema,
      mapInput: ({ parsed }) => parsed,
      response: () => ({ ok: true }),
    },
    delete: {
      commandId: 'agreements.agreements.delete',
      response: () => ({ ok: true }),
    },
  },
})

export const openApi: OpenApiRouteDoc = createAgreementsCrudOpenApi({
  resourceName: 'Agreement',
  pluralName: 'Agreements',
  querySchema: agreementListSchema,
  listResponseSchema: createAgreementsPagedListResponseSchema(agreementListItemSchema),
  create: {
    schema: rawBodySchema,
    description: 'Creates a draft agreement with sanitized rich-text content.',
    responseSchema: agreementCreatedSchema,
  },
  update: {
    schema: rawBodySchema,
    description: 'Updates a draft agreement using its optimistic-lock version.',
    responseSchema: agreementOkSchema,
  },
  del: {
    schema: z.object({ id: z.string().uuid() }),
    description: 'Archives a draft agreement.',
    responseSchema: agreementOkSchema,
  },
})
