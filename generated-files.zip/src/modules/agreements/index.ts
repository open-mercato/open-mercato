import type { ModuleInfo } from '@open-mercato/shared/modules/registry'

export const metadata: ModuleInfo = {
  name: 'agreements',
  title: 'Agreement signing',
  version: '0.1.0',
  description: 'Scoped agreement authoring and ordinary electronic signing.',
  author: '«redacted:custom-literal»',
  license: 'MIT',
}

export default metadata
