# Library — Books Catalog & Lending

**Date**: 2026-08-13
**Status**: Draft

## TLDR

A `library` module for this standalone Open Mercato app that lets backend staff catalog books and lend them to borrowers. Borrowers are customer records from the installed `customers` module (linked by ID + snapshot, never duplicated). The smallest coherent outcome: staff can register books, check a copy out to a customer with a due date, and mark it returned — with availability enforced transactionally and full tenant/organization isolation.

## Problem Statement

The app has no way to track a book collection or who currently holds which copy. Staff today would keep this in a spreadsheet: no availability enforcement (double-lending the last copy), no due-date visibility (overdue loans surface only when someone remembers to check), and no per-organization isolation. A catalog alone does not solve the lending half; lending alone has nothing to lend. Both ship together as one capability.

## Overview and Success Measures

- **Primary outcome:** 100% of loans recorded in the system; zero checkouts that exceed available copies (enforced, not best-effort).
- **Leading indicators:** number of cataloged books, number of active loans, count of overdue loans visible without manual checking.
- **Baseline:** unknown — no system exists today; first measurement is the catalog size after initial data entry.
- **Market / product reference:** [Koha](https://koha-community.org/en/about/), the leading open-source ILS. **Adopted:** circulation with due dates and derived overdue state; copy-count availability; borrower as a patron record. **Rejected for v1:** MARC/Z39.50 cataloging formats, acquisitions, serials, holds/reservations, fines, OPAC (public catalog), notices — enterprise-ILS complexity this app does not need. Holds and notifications are natural follow-up specs.

## Goals

- **REQ-001** — Staff can create, list, edit, and delete books (title, author, ISBN, publisher, year, description, copy count) in the backend, scoped to their organization.
- **REQ-002** — Staff can check an available copy out to a customer and mark it returned; the system rejects checkout when no copy is available and surfaces active/overdue/returned state.

## Non-goals

- No portal/OPAC — backend staff only.
- No holds/reservations, renewals, fines, or overdue notifications (follow-up specs).
- No loan edit or cancel flow — an accidental checkout (wrong customer, wrong due date) is corrected by returning the loan with an explanatory staff note. A dedicated cancel/correction path is a follow-up; see Risks.
- No ISBN metadata lookup, cover-image fetching, CSV import/export, or other external integrations in v1.
- No individual copy/barcode tracking — copies are a count on the book, not separate records.
- No dashboard widgets; no full-text search indexer config (DataTable query-engine filtering is sufficient at v1 scale).
- No borrower entity of our own — borrowers live in the installed `customers` module.

## Proposed Solution

One app-owned module `library` with two entities (`Book`, `Loan`), command-mediated mutations, `makeCrudRoute`-style CRUD APIs, and `DataTable`/`CrudForm` backend pages. Availability is computed (`total_copies` minus active loans) and re-checked inside the checkout command's transaction, so double-lending is impossible under concurrency. Loans reference books by intra-module FK and customers by cross-module ID + display snapshot, per platform rules. Deleting a book with any loan history is blocked by a guard; books never loaned can be deleted.

### Design Decisions and Alternatives

| Decision | Rationale | Alternative considered | Why rejected / deferred |
|---|---|---|---|
| Copies as an integer `total_copies` on `Book` | Smallest model that enforces availability; v1 has no per-copy barcode need | Separate `BookCopy` entity (Koha "items") | Adds a whole CRUD surface for zero v1 workflows; migration path exists if barcodes are ever needed |
| Availability re-checked in the checkout command transaction | Correct under concurrent checkouts; single source of truth | Check in the UI/route only | Race between two staff checkouts would double-lend the last copy |
| Borrower = customer ID + snapshot | Platform rule: no cross-module ORM relations; customer remains source of truth | Own `Borrower` entity | Duplicates CRM data and drifts out of sync |
| Overdue as derived state (`due_at < now() AND returned_at IS NULL`) | No scheduler, no job, always correct | Scheduler job flipping a `status` column | A stored status can drift from the clock; derived state cannot |
| Block delete of books with loan history | Preserves loan audit trail | Soft-delete flag / cascade | Soft delete adds a lifecycle for no v1 need; cascade destroys history |

## Domain Vocabulary and Business Rules

| Term / invariant | Precise meaning or rule | Source of truth | Failure behavior |
|---|---|---|---|
| Book | A lendable title; `total_copies ≥ 0` | `library:book` | Validation rejects negative counts (400) |
| Active loan | `Loan` row with `returned_at IS NULL` | `library:loan` | — |
| Availability | `total_copies − count(active loans for book)`; checkout requires availability ≥ 1 | computed in checkout command | Checkout rejected with 409 when 0 |
| Overdue | Active loan with `due_at < now()` | derived at read time | Displayed as overdue; no write occurs |
| Borrower | Existing `customers:customer_entity` record; loan stores its ID plus a display-name/email snapshot | `customers` module | Checkout rejected (400) when customer ID does not exist in scope |
| ISBN | Optional, unique per organization when present | `library:book` | Duplicate ISBN rejected with 409 |
| Delete rule | A book may be deleted only when it has no loans (any state) | delete command guard | 409 with explanation |

## Users, Permissions, and Scope

| Actor | Allowed outcomes | Scope rule | Required feature IDs |
|---|---|---|---|
| Staff (backend user) | View books and loans | own organization | `library.backend`, `library.view` |
| Staff librarian | Create/edit/delete books; checkout and return loans | own organization | `library.books.manage`, `library.loans.manage` |

`tenantId` and `organizationId` are derived from the authenticated backend session context on every read and write — never from request payloads; requests without scope fail closed. No system-scope (`organizationId: null`) operation exists in this module. Setup grants the features to the admin/staff roles following the `example` setup pattern.

## Reuse and Ownership Map

| Capability | Reuse / extend / app-own | Existing module or new module | Integration seam | Why |
|---|---|---|---|---|
| Book catalog | app-owned | `library` (new) | — | No installed module models lendable titles |
| Loans / circulation | app-owned | `library` (new) | ID/snapshot to `customers` | No installed circulation capability |
| Borrower records | reuse | `customers` (`customers:customer_entity`) | ID + display snapshot | CRM stays source of truth; no duplication |
| Auth/session/ACL | reuse | `auth` | feature IDs via `requireFeatures` / route `metadata` | Installed contract |
| Backend shell, DataTable, CrudForm, API helpers | reuse | framework/ui | canonical primitives | Never raw tables/forms/fetch |

## Architecture and Data Flow

```text
staff -> /backend/library/books        -> /api/library/books        -> library.books.* commands    -> library_books
staff -> /backend/library/loans        -> /api/library/loans        -> library.loans.checkout      -> library_loans
                                        /api/library/loans/[id]/return -> library.loans.return     + customer read (by ID)
commands -> library.book.* / library.loan.* events (post-commit)
```

- **Module boundaries:** one module owns both entities because availability is a transactional invariant spanning books and loans — splitting them would force cross-module transactions.
- **Extension points:** none consumed in v1; the module emits standard events and registers standard surfaces so later UMES extensions (custom fields, injection widgets) work without changes.
- **Alternatives considered:** extending `catalog` (products) — rejected; products model sellable stock with pricing, not lendable copies with due dates, and would couple library behavior to commerce upgrades.
- **Compatibility:** no existing API, data, or UI changes; the module is purely additive. New module routes/schemas follow `BACKWARD_COMPATIBILITY.md` once shipped.

## User Journeys

### Journey J-001 — Catalog a book

1. Staff opens **Library → Books** (`/backend/library/books`).
2. Clicks **Add book**, fills the `CrudForm` (title, author, optional ISBN/publisher/year/description, copies), saves.
3. Book appears in the `DataTable`; `library.book.created` emitted post-commit.
4. Duplicate ISBN → 409 with a localized form error; concurrent edit → optimistic-lock 409 with reload guidance.

### Journey J-002 — Checkout and return

1. Staff opens **Library → Loans → New checkout** (`/backend/library/loans/create`).
2. Selects a book (only books shown; availability displayed), selects a customer from the customers picker, sets a due date, saves.
3. Checkout command re-checks availability in-transaction, creates the loan, emits `library.loan.checked_out`; the loans table shows the loan as **Active** (or **Overdue** once past due).
4. Staff clicks **Return** on the row; the command stamps `returned_at`, emits `library.loan.returned`; the row becomes **Returned**.
5. Last copy checked out twice concurrently → one checkout wins, the other gets 409 with a localized "no copies available" message. Returning an already-returned loan → 409 conflict.

## UI and Interaction Contracts

Closest installed reference: the `example` todos surfaces (`src/modules/example/backend/todos/**`, `src/modules/example/components/TodosTable.tsx`, `TodoForm.tsx`) — the canonical page shell, DataTable, and CrudForm patterns; the customers module's backend pages (`node_modules/@open-mercato/core/src/modules/customers/backend/customers/**`) for the customer-picker idiom. All pages use `Page`/`PageBody`, `DataTable`, `CrudForm`, shared API helpers — no exceptions requested.

**Reference display rule (applies to every surface):** any cross-record reference is a `CrudForm` selection control backed by an option-source route — staff pick from a searchable list of display names, never type or paste a UUID, and UUIDs are never rendered anywhere in the UI. The checkout form's **Book** field is a select showing `title — author` plus current availability; the **Customer** field is a select backed by the installed customers module's scoped option source showing the customer display name (with email as secondary text). The loans table's **Book** column renders the book title and the **Borrower** column renders the `borrower_display_name` snapshot — raw IDs appear only in API payloads.

| Surface / route | Purpose and primary actions | Data source / mutations | Closest installed reference | Canonical shell / components | Required states | Requirement IDs |
|---|---|---|---|---|---|---|
| `/backend/library/books` | List/search books; add, edit, delete | `GET /api/library/books`; delete command | `example/backend/todos/page.tsx` + `TodosTable` | `Page`, `PageBody`, `DataTable` | loading, empty, error, conflict, success, permission denied | REQ-001 |
| `/backend/library/books/create`, `/backend/library/books/[id]/edit` | Create/edit a book | `POST`/`PUT /api/library/books` | `example` todos create/edit + `TodoForm` | `Page`, `PageBody`, `CrudForm` | loading, error, conflict (409 version), success | REQ-001 |
| `/backend/library/loans` | List loans with status filter; return action | `GET /api/library/loans`; `POST /api/library/loans/[id]/return` | `example/backend/todos/page.tsx` + `TodosTable` | `Page`, `PageBody`, `DataTable` | loading, empty, error, conflict, permission denied | REQ-002 |
| `/backend/library/loans/create` | Checkout form | `POST /api/library/loans` | `example` todos create + `TodoForm`; customers picker | `Page`, `PageBody`, `CrudForm` | loading, error, conflict (no copies), success | REQ-002 |

### UI architecture

| Role | Navigation groups in order | Dashboard / injected widgets | Login-to-primary-task flow |
|---|---|---|---|
| Staff librarian | Library → Books; Library → Loans | none in v1 | login → Library → Books → Add book (≤3 clicks); login → Library → Loans → New checkout (≤3 clicks) |

| Surface / widget | Empty state guidance and action | Responsive behavior | Keyboard / focus behavior |
|---|---|---|---|
| Books table | Localized "No books yet" + Add-book CTA | Columns collapse to title/author/copies on narrow | Full keyboard sort/pagination; dialogs trap focus |
| Loans table | Localized "No loans yet" + New-checkout CTA | Status badge + borrower + due date remain visible | Return row action reachable by keyboard with confirm |
| Forms | — | Single column on narrow | Label-associated fields; submit/cancel; inline errors announced |

### `/backend/library/books` — Books

```text
┌────────────────────────────────────────────────────────────┐
│ Books                                          [Add book]  │
│ [search: title/author/ISBN..................]              │
├────────────────────────────────────────────────────────────┤
│ Title        │ Author     │ ISBN        │ Copies │ Avail.  │
│ …(DataTable rows; row actions: Edit, Delete)…              │
├────────────────────────────────────────────────────────────┤
│ ‹ 1 2 3 … pagination ›                                     │
└────────────────────────────────────────────────────────────┘
```

### `/backend/library/loans` — Loans

```text
┌────────────────────────────────────────────────────────────┐
│ Loans                                     [New checkout]   │
│ [status: All | Active | Overdue | Returned]  [search…]     │
├────────────────────────────────────────────────────────────┤
│ Book         │ Borrower    │ Loaned   │ Due      │ Status  │
│ …(DataTable rows; active rows expose: Return)…             │
├────────────────────────────────────────────────────────────┤
│ ‹ 1 2 3 … pagination ›                                     │
└────────────────────────────────────────────────────────────┘
```

- **Behavior:** server-side sort/filter/pagination; delete and return use destructive-confirmation dialogs; optimistic-lock conflicts show a localized conflict state with reload; checkout submit disabled while pending.
- **Responsive and accessibility:** status is a badge with text, never color-only; focus order follows visual order; screen-reader announcements for save/return outcomes.
- **Localization:** all strings under the `library.*` namespace; ship `en`, `de`, `es`, `ko`, `pl` catalogs matching the project's locale set; dates via locale-aware formatting.
- **Design-system and theming:** semantic tokens only; status badges via shared status treatment; verify light/dark and narrow width; no hard-coded palette colors.

Implementation of every UI slice must invoke `om-backend-ui-design` and follow `.ai/guides/backend-ui.md`.

## Data Models

### `Book` (`library:book`, table `library_books`)

| Field | Type / nullability | Scope / index | Sensitive / encrypted | Lifecycle and validation |
|---|---|---|---|---|
| `id` | UUID, required | primary key | no | immutable |
| `tenant_id` / `organization_id` | UUID, required | composite scope indexes | no | trusted context only |
| `title` | string, required | index (list ordering) | no | trimmed, 1–300 chars |
| `author` | string, required | index | no | 1–300 chars |
| `isbn` | string, nullable | unique per (organization_id) where present | no | ISBN-10/13 shape when present |
| `publisher` | string, nullable | — | no | ≤300 chars |
| `published_year` | int, nullable | — | no | 0–current year+1 |
| `description` | text, nullable | — | no | free text, no PII expectation |
| `total_copies` | int, required, default 1 | — | no | ≥0; lowering below active-loan count rejected 409 |
| `created_at` / `updated_at` | timestamps, required | `updated_at` = optimistic-lock version | no | updated on every edit |

### `Loan` (`library:loan`, table `library_loans`)

| Field | Type / nullability | Scope / index | Sensitive / encrypted | Lifecycle and validation |
|---|---|---|---|---|
| `id` | UUID, required | primary key | no | immutable |
| `tenant_id` / `organization_id` | UUID, required | composite scope indexes | no | trusted context only |
| `book_id` | UUID, required | FK → `library_books`, index | no | must exist in same scope |
| `borrower_customer_id` | UUID, required | index | no | ID reference to `customers:customer_entity`; existence validated in scope at checkout |
| `borrower_display_name` / `borrower_email` | string, required / nullable | — | snapshot, not encrypted (same data class as the customer record itself) | snapshot at checkout; never synced back |
| `loaned_at` | timestamp, required | index | no | set by command |
| `due_at` | timestamp, required | index | no | must be after `loaned_at` |
| `returned_at` | timestamp, nullable | partial index (active loans) | no | set exactly once by return command |
| `notes` | text, nullable | — | no | staff notes |
| `created_at` / `updated_at` | timestamps, required | `updated_at` = optimistic-lock version | no | updated on every edit |

Migrations are generated fresh with `yarn db:generate` (never copied from `example`), reviewed, and applied only after user confirmation per project rules. No cross-module ORM relations; customer linkage is ID + snapshot only.

## API, Command, and Error Contracts

| Method / command | Path / ID | Auth and feature gate | Input | Success response / event | Errors and concurrency | Requirement IDs |
|---|---|---|---|---|---|---|
| `GET` | `/api/library/books` | auth + `library.view` | query schema (search, sort, page) | `{ items, totalCount }` (incl. computed availability) | 400/401/403 | REQ-001 |
| `POST` | `/api/library/books` | auth + `library.books.manage` | book create schema | 201 + `library.book.created` | 400/403/409 (ISBN) | REQ-001 |
| `PUT` | `/api/library/books/[id]` | auth + `library.books.manage` | book update schema + version | 200 + `library.book.updated` | 400/403/404/409 | REQ-001 |
| `DELETE` | `/api/library/books/[id]` | auth + `library.books.manage` | version | 200 + `library.book.deleted` | 403/404/409 (version, loan history) | REQ-001 |
| `GET` | `/api/library/loans` | auth + `library.view` | query schema (status, search, page) | `{ items, totalCount }` with derived status | 400/401/403 | REQ-002 |
| `GET` | `/api/library/books/options` | auth + `library.view` | query schema (search) | `[{ value, label, availability }]` for the checkout select | 400/401/403 | REQ-002 |
| `POST` | `/api/library/loans` | auth + `library.loans.manage` | `{ bookId, customerId, dueAt, notes? }` | 201 + `library.loan.checked_out` | 400 (bad book/customer), 403, 409 (no copies) | REQ-002 |
| `POST` | `/api/library/loans/[id]/return` | auth + `library.loans.manage` | `{ version, notes? }` | 200 + `library.loan.returned` | 403/404/409 (already returned, version) | REQ-002 |

Books routes use the platform CRUD factory/query-engine pattern (reference: `src/modules/example/api/todos/route.ts`); loan mutations are command routes (checkout/return are not CRUD-shaped). Every route carries per-method `metadata` + OpenAPI schemas (reference: `src/modules/example/api/openapi.ts`), derives scope from session, and is idempotent-safe: return of an already-returned loan yields 409, checkout conflicts are explicit. Custom update/delete clients send `updated_at` as the version and surface 409s.

## Events, Jobs, Notifications, and Cross-Module Flows

| Trigger | Producer | Consumer | Side effect | Retry / idempotency / audit behavior |
|---|---|---|---|---|
| `library.book.created/updated/deleted` | `library` commands | (none in v1) | emitted post-commit | standard event contract |
| `library.loan.checked_out` | `library.loans.checkout` | (none in v1) | emitted post-commit | standard event contract |
| `library.loan.returned` | `library.loans.return` | (none in v1) | emitted post-commit | standard event contract |

No jobs, schedulers, notifications, or cross-module subscribers in v1; overdue is derived at read time. The customers read at checkout is a same-request scoped lookup by ID; if the customers module were unavailable the checkout fails closed with a localized error.

## Security, Privacy, and Compliance

- **Authorization:«redacted:authorization» feature gates (`library.view`, `library.books.manage`, `library.loans.manage`); never role-name checks.
- **Tenant isolation:** every query and mutation filters by trusted `tenantId`/`organizationId`; missing scope fails closed; TEST-002 proves cross-tenant denial.
- **Sensitive data:** borrower snapshot is the minimum needed for list rendering (name + email); it is a historical record, deliberately never synced back — a customer edit/delete leaves the snapshot stale by design (see Risks); no encryption map additions (same data class as its source); no free-text-about-people fields beyond staff `notes`.
- **Abuse and failure modes:** ISBN enumeration is scoped per organization; checkout race handled transactionally; delete/return guarded; no secrets involved.

## Integration Coverage

| Test ID | Level | Setup / fixture | Actions | Assertions | Requirement IDs |
|---|---|---|---|---|---|
| TEST-001 | integration | tenant/org/user with `library.books.manage` | create/list/update/delete book via API | persisted state; events emitted; ISBN 409 on duplicate | REQ-001 |
| TEST-002 | security | second tenant + user without features | read/write books and loans across scope | fail closed 403/404; zero data leak | REQ-001, REQ-002 |
| TEST-003 | integration | book with `total_copies=1`, two customers | checkout, second checkout, return, re-checkout | second checkout 409; return stamps once; availability flips | REQ-002 |
| TEST-004 | UI | records + permissions | books/loans pages: loading, empty, error, conflict, keyboard flows in light/dark, narrow width | observable states per UI contract | REQ-001, REQ-002 |

## Implementation Phases

### Phase 1 — Books catalog vertical slice

- **Depends on:** none
- **Outcome:** staff can fully manage the book catalog in the backend.
- **Why this order / value delivered:** loans need books to reference; the catalog alone already replaces the spreadsheet for inventory.
- **Deliverables:** `src/modules/library/` scaffold — `index.ts`, `acl.ts`, `setup.ts`, `i18n/*` (en/de/es/ko/pl), `data/entities.ts` (`Book`), `data/validators.ts`, `commands/books.ts` (create/update/delete + undo, ISBN + copy-count guards), `events.ts`, `api/books/**` + `api/openapi.ts`, backend pages (`books` list/create/edit) + `components/BooksTable.tsx`, `BookForm.tsx`; generated migration (reviewed, applied after confirmation).
- **Independent slices / estimated commits:** (a) entities+validators+migration, (b) commands+API+events, (c) UI pages+i18n — slices (b) and (c) may run in parallel after (a).
- **Requirements closed:** REQ-001
- **Tests:** TEST-001, TEST-002 (books part)
- **Validation:** `yarn generate`, `yarn typecheck`, focused tests
- **Exit gate:** TEST-001/TEST-002 green; books pages exercised in light/dark + narrow with loading/empty/error/conflict states; `yarn generate` diff committed.

### Phase 2 — Loans / circulation vertical slice

- **Depends on:** Phase 1 exit gate
- **Outcome:** staff can check out and return copies; availability enforced; overdue visible.
- **Why this order / value delivered:** completes the lending loop — the primary business outcome.
- **Deliverables:** `Loan` entity + generated migration, `commands/loans.ts` (checkout with transactional availability check + customer lookup, return with version guard; undo where the platform supports it), `api/loans/**` routes, loans pages (`loans` list with status filter + return action, `loans/create` checkout form with customer picker), i18n additions, events.
- **Independent slices / estimated commits:** (a) entity+migration+commands, (b) API routes, (c) UI pages — (b) and (c) parallel after (a).
- **Requirements closed:** REQ-002
- **Tests:** TEST-002 (loans part), TEST-003, TEST-004
- **Validation:** `yarn generate`, `yarn typecheck`, focused integration tests
- **Exit gate:** TEST-003/TEST-004 green; concurrent-checkout race covered by TEST-003; loans UI states verified like Phase 1.

## Requirement Traceability

| Requirement | Journey / surface | Data/API/event contracts | Phase | Tests | Acceptance criterion |
|---|---|---|---|---|---|
| REQ-001 | J-001, `/backend/library/books*` | `library:book`, `/api/library/books*`, `library.book.*` | Phase 1 | TEST-001, TEST-002 | AC-001 |
| REQ-002 | J-002, `/backend/library/loans*` | `library:loan`, `/api/library/loans*`, `library.loan.*` | Phase 2 | TEST-002, TEST-003, TEST-004 | AC-002, AC-003 |

### Extension-surface traceability

| Surface | Requirement | Reference file (adapts) | Phase | Test | Classification |
|---|---|---|---|---|---|
| Module metadata `index.ts` | REQ-001 | `src/modules/example/index.ts` | 1 | TEST-001 | emitted-example |
| ACL features `acl.ts` | REQ-001 | `src/modules/example/acl.ts` | 1 | TEST-002 | emitted-example |
| Setup role grants `setup.ts` | REQ-001 | `src/modules/example/setup.ts` | 1 | TEST-002 | emitted-example |
| Entities `data/entities.ts` | REQ-001, REQ-002 | `src/modules/example/data/entities.ts` | 1, 2 | TEST-001, TEST-003 | emitted-example |
| Validators `data/validators.ts` | REQ-001, REQ-002 | `src/modules/example/data/validators.ts` | 1, 2 | TEST-001, TEST-003 | emitted-example |
| Migrations (generated fresh) | REQ-001, REQ-002 | `«redacted:high-entropy».ts` (shape only; `yarn db:generate` output) | 1, 2 | TEST-001, TEST-003 | emitted-example |
| Commands `commands/*.ts` | REQ-001, REQ-002 | `src/modules/example/commands/todos.ts` | 1, 2 | TEST-001, TEST-003 | emitted-example |
| Events `events.ts` | REQ-001, REQ-002 | `src/modules/example/events.ts` | 1, 2 | TEST-001, TEST-003 | emitted-example |
| CRUD API `api/books/route.ts` | REQ-001 | `src/modules/example/api/todos/route.ts` | 1 | TEST-001 | emitted-example |
| OpenAPI `api/openapi.ts` | REQ-001, REQ-002 | `src/modules/example/api/openapi.ts` | 1, 2 | TEST-001 | emitted-example |
| Option-source route `api/books/options/route.ts` | REQ-002 | `src/modules/example/api/tags/route.ts` | 2 | TEST-003 | emitted-example |
| Command routes `api/loans/**` | REQ-002 | `src/modules/example/api/organizations/route.ts` | 2 | TEST-003 | emitted-example |
| Books list page | REQ-001 | `src/modules/example/backend/todos/page.tsx` + `src/modules/example/backend/todos/page.meta.ts` | 1 | TEST-004 | emitted-example |
| Books table component | REQ-001 | `src/modules/example/components/TodosTable.tsx` | 1 | TEST-004 | emitted-example |
| Books create/edit pages + form | REQ-001 | `src/modules/example/backend/todos/create/page.tsx`, `src/modules/example/backend/todos/[id]/edit/page.tsx`, `src/modules/example/components/TodoForm.tsx` | 1 | TEST-004 | emitted-example |
| Loans pages + form/table | REQ-002 | `src/modules/example/backend/todos/page.tsx`, `src/modules/example/components/TodosTable.tsx`, `src/modules/example/components/TodoForm.tsx` | 2 | TEST-004 | emitted-example |
| i18n catalogs | REQ-001, REQ-002 | `src/modules/example/i18n/en.json` (+ de/es/pl; add ko) | 1, 2 | TEST-004 | emitted-example |

## Rollout, Migration, and Rollback

`yarn db:generate` produces scoped migrations for `library_books` then `library_loans`; each is reviewed and applied only with user confirmation (`yarn db:migrate` is never run to "validate"). Module registration in `src/modules.ts` plus `yarn generate` activates discovery. Rollback: remove the module from `src/modules.ts`, regenerate, and drop the two tables via a reverse migration — no other module references them, so blast radius is the module itself. No feature flags needed; the module is additive.

## Risks and Tradeoffs

| Risk / tradeoff | Impact | Mitigation / detection | Residual risk |
|---|---|---|---|
| Concurrent checkout of last copy | double-lending | transactional availability re-check; TEST-003 exercises the race | none known |
| Customer deleted while loans active | orphaned borrower ID | snapshot keeps loans readable; loan list renders from snapshot | accepted — historical record survives |
| Stale borrower PII in snapshots | customer updates/removes their record but loan rows keep the old name/email | snapshot is minimal (name + email) and treated as a historical record of who held the copy, not a sync target; retention of loan history governs it | accepted — documented data-protection decision, revisited if a privacy requirement appears |
| Accidental checkout (wrong customer/due date) | loan history polluted by "return to correct" | explicit non-goal for v1; staff notes field records the correction; dedicated cancel flow is a follow-up | residual day-one friction |
| `total_copies` lowered below active loans | availability goes negative | update guard rejects with 409 | none |
| Copy-count model can't do barcodes later | re-model cost | documented decision; additive `BookCopy` migration possible | accepted for v1 |
| Staff deletes wrong book | data loss | delete confirmation + command undo + loan-history guard | residual human error |
| Migration applied prematurely | drift | project rule: generate, review, ask before applying | process guard |

## Acceptance Criteria

- [ ] **AC-001** — A staff user with `library.books.manage` can create, edit (with conflict handling), list, and delete books in their organization; duplicate ISBN is rejected; another tenant/organization sees none of it.
- [ ] **AC-002** — A staff user can check out an available copy to a customer and return it; checkout of an unavailable copy fails with 409; overdue loans are visually distinguishable without any job running.
- [ ] **AC-003** — No UUID is ever typed or displayed in the UI: book and customer references are searchable selection controls showing display names, and the loans table renders book titles and borrower names.
- [ ] Every listed backend surface matches its recorded Open Mercato reference and uses the canonical shell/components, shared API helpers, semantic tokens, and complete loading, empty, error, conflict, keyboard, accessibility, responsive, light-mode, and dark-mode states.
- [ ] Every affected API and UI path has self-contained integration coverage and the configured validation gate passes.

## Final Compliance Report

| Check | Status | Evidence / resolution |
|---|---|---|
| Applicable `AGENTS.md` files and routed guides/skills reviewed | pass | root `AGENTS.md`, `.ai/guides/spec-delivery.md`, `om-spec-writing`, `.ai/guides/modules/customers.md`, `src/modules/example/README.md` + surface inventory |
| Data models, APIs, events, UI, and tests are internally consistent | pass | traceability rows cover REQ-001/002 end to end |
| Every workflow completes end to end without a catch-all integration phase | pass | J-001 closes in Phase 1, J-002 in Phase 2 |
| Platform-native reuse and extension points were chosen before custom code | pass | DataTable/CrudForm/commands/CRUD factory; borrower reuse of `customers` |
| UI contracts identify references, canonical components, and theme/state coverage | pass | UI section + mockups + states |
| Every phase has dependencies, bounded slices, tests, value, and an observable exit gate | pass | Phases 1–2 |

Verdict: `Blocked — awaiting user approval of this draft` (status flips to `Ready for implementation` on approval).

## Open Questions

| ID | Question | Owner | Blocking? | Resolution / decision date |
|---|---|---|---|---|
| Q1 | Core capability | user | yes | Resolved 2026-08-13: catalog + lending, one spec |
| Q2 | Audience | user | yes | Resolved 2026-08-13: backend staff only |
| Q3 | Borrower representation | user | yes | Resolved 2026-08-13: link to `customers` via ID + snapshot |
| Q4 | Integrations | user | no | Resolved 2026-08-13: all deferred |

## Changelog

| Date | Change |
|---|---|
| 2026-08-13 | Initial draft (skeleton + gate answers applied) |
| 2026-08-13 | Scope-cohesion review fixes: loan-correction non-goal + risk, stale-snapshot PII risk |
| 2026-08-13 | Reference display rule: selection controls show names, never UUIDs; added books option-source route + AC-003 |
