# Agreement Signing Module

**Date**: 2026-08-10
**Status**: Draft

## Implementation Status

Phase 1 implementation is complete for the approved scope. The specification remains Draft because production readiness still requires Polish legal/compliance review; the implementation does not claim qualified or advanced electronic-signature status.

| Phase | State | Acceptance criteria | Exit gate |
|---|---|---|---|
| Phase 1 — Agreement authoring, immutable versions, and rich-text signing | complete | AC-001, AC-002, AC-003, AC-004, AC-005, AC-007, AC-008 | Generated discovery, typecheck, focused tests, and code review pass |
| Phase 2 — PDF field placement and evidence output | pending | AC-006, AC-009, AC-010 | Phase 1 complete plus PDF rendering/field tests |
| Phase 3 — Verification, reminders, and operational hardening | pending | AC-011, AC-012, AC-013 | Phase 2 complete plus delivery/verification tests |

### Phase 1 progress

- [x] Module registration, scoped entities, ACL, encryption map, and discovery generation
- [x] Agreement CRUD, immutable publishing, envelope creation, and signer commands
- [x] Admin authoring UI and public signing ceremony
- [x] Focused regression coverage and validation gate

## TLDR

Build an app-owned `agreements` module that lets staff manage agreement templates and immutable published versions, prepare signing requests for multiple signers, and generate signer-specific frontend links. Signers can review the exact published content, optionally verify their email, explicitly consent to electronic records, and sign using a typed or drawn signature; uploaded PDFs additionally support positioned signature, initials, date, and text fields. The module stores a tamper-evident audit trail and produces a completed document plus certificate of completion, while clearly distinguishing this ordinary electronic signature workflow from a qualified electronic signature.

The smallest coherent outcome is one module with an admin CRUD surface, a public signer ceremony, PDF field placement, sequential or parallel multi-signer routing, and durable evidence. It reuses the platform’s module discovery, `DataTable`, `CrudForm`, command, scope, ACL, storage, notification, and translation primitives.

## Problem Statement

Administrators need one place to prepare agreements, publish a specific version, share signer-specific links, see signing progress, and retrieve evidence of who signed what and when. Signers need a clear Polish-language frontend experience that presents the exact agreement version, captures explicit intent, and confirms completion without requiring an account.

The current workflow has no agreement source model, signer routing, link security, PDF field placement, or audit evidence. A naive “click a button and save a signature image” implementation would not provide the chain of custody expected from established e-signature products and would be misleading for Polish legal use cases.

## Overview and Success Measures

- **Primary outcome:** At least 95% of test agreement requests can be created, sent, signed by all assigned signers, and downloaded with a completed document and evidence certificate without administrator intervention.
- **Leading indicators:** Agreement publish success rate, time from draft to sent, signer ceremony completion rate, email-verification success rate when enabled, and evidence-generation retry rate.
- **Baseline:** unknown — measure the current manual workflow during rollout discovery.
- **Market / product reference:** DocuSign’s public eSignature materials were used as the product benchmark for recipient-specific fields, ordered recipients, consent/disclosure, audit history, certificate of completion, timestamps, IP/device evidence, and tamper-evident completed documents. The design adopts those evidence patterns but does not claim DocuSign-level PKI or qualified-signature status in v1. [DocuSign eSignature features](https://www.docusign.com/products/electronic-signature/features), [DocuSign transaction data and Certificate of Completion](https://www.docusign.com/trust/security/transaction-data-use).

## Goals

- **REQ-001** — Staff can list, create, view, edit, archive, and publish agreements from the admin panel.
- **REQ-002** — Staff can author rich text, upload a PDF, or include both in one published signing package.
- **REQ-003** — Every sent signing request references one immutable agreement version and produces one unique signer link per signer.
- **REQ-004** — A request supports multiple signers with either sequential or parallel routing, refusal, expiry, resend, and progress states.
- **REQ-005** — A signer can sign without an application account; the request may optionally require one-time email verification.
- **REQ-006** — An uploaded PDF supports positioned signature, initials, date, and text fields assigned to particular signers.
- **REQ-007** — The system stores append-only signature and audit evidence and generates a completed document and certificate of completion after all required signers finish.
- **REQ-008** — The product is Polish-first, scoped to the owning tenant and organization, accessible, and explicit about the legal limits of ordinary electronic signatures.

## Non-goals

- Qualified, advanced, or certificate-based electronic signatures; PAdES; eIDAS trust-service-provider integration; mObywatel, e-dowód, Profil Zaufany, or other government identity integration.
- Notarization, witnesses, video identity proofing, government-ID checks, knowledge-based authentication, or biometric identity proofing.
- A general-purpose document editor, word processor, OCR engine, PDF form designer beyond the required fields, or arbitrary document conversion service.
- Replacing installed customer/auth records. Signers are app-owned participants with optional scalar references to an installed user/customer record only when an existing contract supplies one.
- Automatic legal classification of an agreement or a guarantee that a particular agreement satisfies Polish formal requirements. Each organization must obtain legal approval for its use case.
- External provider integration in v1. A provider-neutral seam may be reserved for a future qualified-signature adapter.

## Proposed Solution

The module has two related but distinct records:

1. An **Agreement** is the staff-managed template/record. Draft content can change. Publishing creates an immutable **AgreementVersion** with normalized source artifacts and a content hash.
2. A **SigningEnvelope** is a signing transaction against exactly one published version. It owns signers, routing, field assignments, links, signatures, audit events, and final evidence artifacts.

Rich text is sanitized, frozen at publish time, and rendered into a canonical PDF artifact for signing and evidence. An uploaded PDF is normalized and stored as a scoped artifact. If both sources are supplied, the rendered rich-text document is the first document and the uploaded PDF is an included appendix in the same signing package; all included artifacts are hashed and shown before signing.

For rich text or a PDF without positioned fields, the module appends a generated signature page containing each signer’s mark, name, signing date, and initials where applicable. For positioned PDF fields, the signer ceremony renders the uploaded PDF and collects each assigned required field. The final package contains the original document(s), visible signature marks/field values, and a separate certificate of completion.

The signing ceremony is bearer-link based by default: the raw token is only in the generated URL, its hash is stored, and the token is never returned in ordinary list/detail responses or logs. An envelope can enable email OTP verification per signer. OTP verification adds assurance but remains identity verification of mailbox control, not a qualified signature.

### Design Decisions and Alternatives

| Decision | Rationale | Alternative considered | Why rejected / deferred |
|---|---|---|---|
| App-owned signing ceremony with evidence | Keeps the core domain available without a vendor and satisfies the requested built-in workflow. | DocuSign/Dropbox Sign integration | Deferred; would add provider credentials, contracts, cost, and external data residency. |
| Ordinary electronic signature, typed/drawn mark, explicit consent, audit trail | Matches the requested friction level and provides evidence without pretending to be a qualified signature. | Qualified/advanced signature now | Requires certified trust services, identity proofing, key management, and legal/provider integration. |
| Immutable published versions and envelopes | Prevents a signer from signing content that later changes. | Edit the agreement in place | Rejected because it breaks document integrity and auditability. |
| One unique link per signer | Allows individual routing, status, and evidence. | One shared agreement link | Rejected because it cannot reliably attribute access/signing to a participant. |
| Optional email OTP per signer | Adds a reversible security step for higher-risk agreements without requiring accounts. | Mandatory login or government identity | Conflicts with the requested no-account flow and increases scope. |
| PDF coordinates normalized to page dimensions | Makes field placement stable across responsive rendering and devices. | Pixel coordinates | Rejected because zoom and viewport size would change field locations. |
| Server-generated final PDF and certificate | Gives every completed envelope a downloadable, reproducible evidence package. | Store only database rows and a signature image | Rejected because signers need the signed document and administrators need portable evidence. |
| Hashes plus an approved server-side signing/key-management seam | Makes content and audit tampering detectable without hand-rolled cryptography. | Claim a PKI-sealed PDF | Rejected in v1; no qualified/PAdES seal is available without a trust-service integration. |

## Domain Vocabulary and Business Rules

| Term / invariant | Precise meaning or rule | Source of truth | Failure behavior |
|---|---|---|---|
| Agreement | Staff-owned editable record representing a reusable agreement template. | `agreements:agreement` | Scope every read/write; archive rather than hard-delete when referenced. |
| Agreement version | Immutable snapshot of all source content and metadata used by a request. | `agreements:agreement_version` | Reject edits; create a new draft/version. |
| Signing envelope | One transaction to obtain all required signatures for one published version. | `agreements:envelope` | Void and recreate instead of changing signed content or participants. |
| Signer | A named participant assigned to an envelope; not automatically an app account. | `agreements:signer` | Reject duplicate active signer email within the envelope and invalid routing order. |
| Signing mode | `sequential` or `parallel`. Sequential makes the next order available only after the previous order completes; parallel makes all signers available when sent. | Envelope | Reject a send with missing order or no required signer. |
| Published content | A sanitized rich-text snapshot and/or normalized PDF artifact, each with SHA-256 content hash. | Agreement version | Do not send until every required source artifact is available and hashable. |
| Signature field | A required or optional field assigned to one signer. Types are `signature`, `initials`, `date`, or `text`; positioned fields are supported for uploaded PDFs. | Envelope field set | Reject out-of-bounds, overlapping-invalid, unassigned, or unsupported fields before send. |
| Signer link | Opaque bearer token bound to exactly one signer and envelope. Store only a slow hash/token digest. | Signer token hash | Return generic not-found/expired responses; never reveal whether another token exists. |
| Email verification | Optional OTP sent to the signer’s supplied email. OTP is short-lived, single-use, rate-limited, and hashed at rest. | Signer verification state | Keep signer pending and show retry/support guidance; never expose OTP in logs or API responses. |
| Signature intent | The signer has reviewed the exact package, accepted the electronic-record/signature disclosure, confirmed intent to sign, and submitted a signature mark or required field set. | Append-only audit event + signature | Do not create a signature if disclosure or required fields are incomplete. |
| Completion | All required signers and required fields are complete; final artifact generation may still be pending. | Envelope state machine | Keep a visible `finalizing` state and retry idempotently if artifact generation fails. |
| Evidence certificate | A generated PDF containing envelope ID, version/artifact hashes, participants, events, signature method, consent/disclosure version, timestamps, and configured network/device evidence. | Evidence artifact | Never call the process “qualified” or “PKI-sealed”; expose generation failure to staff and retry. |
| Polish legal posture | Ordinary electronic signing evidence is not equivalent to a qualified signature. Under eIDAS Article 25 an electronic signature cannot be denied legal effect solely because it is electronic, while Polish Civil Code Article 78¹ connects electronic form equivalent to written form with a qualified electronic signature. | Legal review / organization policy | Show a Polish warning and require legal approval before production use for agreements needing a particular formal type. Sources: [eIDAS Article 25](https://eur-lex.europa.eu/eli/reg/2014/910/oj), [Polish Civil Code Article 78¹](https://eli.gov.pl/api/acts/DU/2023/1610/text.html), [PIP explanation](https://www.pip.gov.pl/dla-pracodawcow/pytania-i-odpowiedzi/czy-umowe-o-prace-mozna-zawrzec-w-formie-elektronicznej-z-wykorzystaniem-kwalifikowanego-podpisu-elektronicznego-w-tym-za-posrednictwem-aplikacji-mobywatel?tmpl=pdf). |

State transitions:

```text
Agreement: draft -> published -> archived
Version:   draft -> published -> superseded
Envelope:  draft -> sent -> in_progress -> finalizing -> completed
                              |             |          \
                              v             v           v
                           declined       expired      voided
Signer:    pending -> invited -> viewed -> ready -> signed
                                      |        \
                                      v         v
                                   declined   expired
```

Rules:

- A draft Agreement can be edited. Once a version is published, its source, signer disclosure text, signer list, field set, and hashes are immutable for any envelope using it.
- A sent envelope can be resent, voided, or allowed to expire; it cannot have its content, signer identity, routing, or fields changed. Resending rotates the affected bearer token and records the rotation.
- A signer may revisit a link after signing to download the final package only if the envelope is completed and the signer’s access policy allows it; a signed signer cannot submit a second signature.
- A refusal stops sequential routing and marks the envelope `declined`; administrators may void it and create a new envelope from the same published version.
- Dates are stored in UTC and displayed in the organization/signer locale. The evidence certificate records both canonical UTC time and displayed timezone.
- A link is not an identity guarantee. The signer-facing disclosure must state whether email verification is enabled and that a bearer link without verification should be shared only with the intended signer.

## Users, Permissions, and Scope

| Actor | Allowed outcomes | Scope rule | Required feature IDs |
|---|---|---|---|
| Staff agreement manager | View/create/edit/archive agreements; upload sources; publish versions; configure signers/fields; send/resend/void; view evidence | Authenticated staff context; trusted `tenantId` plus selected `organizationId` | `agreements.view`, `agreements.manage` |
| Staff read-only user | View agreement status, signer progress, and evidence if granted | Same tenant and selected organization; no mutation | `agreements.view` |
| Signer | View only the linked envelope; optionally verify email; sign or decline; download completed evidence when allowed | Scope is derived from the token’s signer row; never from URL payload or request body | No staff feature; token authorization plus signer state |
| Background worker | Render/normalize artifacts, send configured notifications, finalize evidence, expire/remind | Carries the envelope’s stored tenant/org scope and re-checks it before every mutation | Worker-owned internal capability, no UI bypass |

Every admin query and mutation derives scope from authenticated runtime context and fails closed when `tenantId` or required organization scope is absent. A public token route resolves the token hash to a signer and then uses the signer’s stored tenant/org scope; the request cannot choose either value. No system-scope operation is required. Cross-module identity references are scalar IDs/snapshots, never ORM relations.

## Reuse and Ownership Map

| Capability | Reuse / extend / app-own | Existing module or new module | Integration seam | Why |
|---|---|---|---|---|
| Agreement, version, envelope, signer, field, signature, audit, and evidence metadata | App-own | New `agreements` module | Module entities, commands, APIs, events | These invariants do not belong to auth, customers, notifications, or communication channels. |
| Staff authentication and ACL | Reuse | Installed `auth` | Auth context and feature grants | Staff identity and RBAC remain installed sources of truth. |
| Optional signer/customer/user reference | Reuse when available | Installed host module, otherwise none | Scalar ID and immutable display snapshot | Avoids duplicating customer or user records and avoids cross-module ORM relations. |
| Artifact storage | Reuse host contract | Configured storage/media provider | Scoped object key, authorization, signed access, cleanup | PDFs, signature marks, and evidence are files; raw blobs do not belong in domain rows. |
| Transactional email for OTP/reminders | Reuse optional capability | Configured transactional email/notification service | DI/service seam; post-commit event | The module must work with copied links when email delivery is absent; it must not invent a mailbox integration. |
| Staff list/create/edit/detail UI | App-own | `agreements` | `DataTable`, `CrudForm`, shared page shell | New visible product surface. |
| Public signing ceremony | App-own | `agreements` | Public frontend route and guarded token APIs | Signer experience is unique to the module. |
| Future qualified signature | Reserved only | Future provider module | Provider-neutral signature-method interface | Keeps v1 honest and allows a later certified provider without changing the core envelope model. |

## Architecture and Data Flow

```text
Staff -> /backend/agreements -> scoped CRUD API -> Agreement + AgreementVersion
                                      |                    |
                                      | publish/send       v
                                      +---------------> SigningEnvelope
                                                          |
Signer link -> public token API -> Signer + Envelope -> signature command
                                                          |
                                      post-commit events  v
                              notification / artifact workers
                                                          |
                                  final PDF + evidence certificate
```

- **Module boundaries:** `agreements` owns every signing invariant and never directly mutates installed auth/customer/notification records. Optional installed capabilities are called through typed DI/events and degrade safely.
- **Artifact pipeline:** validate upload type/size; scan and normalize PDFs in a sandboxed worker; store artifacts under tenant/org/envelope-scoped keys; hash bytes; issue signed downloads only after authorization. Rich text is sanitized before persistence and rendered to a canonical PDF at publish.
- **Signing ceremony:** load only the signer’s envelope projection; record `viewed`, `disclosure_accepted`, `verification_completed`, `field_completed`, `signed`, `declined`, and download events. The final signature command atomically checks signer state, envelope state, routing, version hash, required fields, consent, and expected version before appending the signature.
- **Evidence integrity:** use the platform-approved cryptographic/hash and key-management service. Hash each source/final artifact, chain audit-event hashes, and sign or anchor the completion evidence when the installed service supports it. Never implement cryptography inline or call the result a qualified digital signature.
- **Side effects:** enqueue notifications, reminders, PDF rendering, and final certificate generation only after transaction commit. Each job uses a stable scoped idempotency key and is safe to retry.
- **Compatibility:** new routes, entities, events, feature IDs, page IDs, and injection spots are additive. The implementation must read `.ai/guides/upstream/BACKWARD_COMPATIBILITY.md` before introducing them and must keep IDs stable after release.

### Extension-surface traceability

| Requirement | Reference capability and exact source adapted | Phase | Self-contained integration test | Mechanism classification |
|---|---|---|---|---|
| REQ-001/REQ-002 | CRUD list shell: `src/modules/example/components/TodosTable.tsx` | Phase 1 | `agreements-admin-list.integration.test.ts` | emitted-example |
| REQ-001/REQ-002 | CRUD form shell: `src/modules/example/components/TodoForm.tsx` | Phase 1 | `agreements-admin-crud.integration.test.ts` | emitted-example |
| REQ-001 | Backend list route: `src/modules/example/backend/todos/page.tsx` | Phase 1 | `agreements-admin-routes.integration.test.ts` | emitted-example |
| REQ-002 | Domain entities/validators: `src/modules/example/data/entities.ts` | Phase 1 | `agreements-scope-and-validation.integration.test.ts` | emitted-example |
| REQ-001/REQ-002 | CRUD route: `src/modules/example/api/todos/route.ts` | Phase 1 | `agreements-admin-api.integration.test.ts` | emitted-example |
| REQ-001/REQ-007 | Command lifecycle/locking: `src/modules/example/commands/todos.ts` | Phase 1 | `agreements-command-integrity.integration.test.ts` | emitted-example |
| REQ-003/REQ-004 | Public frontend route shell: `src/modules/example/frontend/blog/[id]/page.tsx` | Phase 1 | `agreements-public-signing.integration.test.ts` | emitted-example |
| REQ-006 | Custom PDF field-placement surface based on the module-owned frontend/page contract; no reference module contributes a PDF editor | Phase 2 | `agreements-pdf-fields.integration.test.ts` | catalog-only |
| REQ-007 | Post-commit event declaration: `src/modules/example/events.ts` | Phase 2 | `agreements-evidence-events.integration.test.ts` | emitted-example |
| REQ-005/REQ-007 | Worker/discovery registration based on `src/modules/example/index.ts` | Phase 3 | `agreements-notification-and-finalization.integration.test.ts` | framework-only |

## User Journeys

### Journey J-001 — Create and publish an agreement

1. A staff user opens `/backend/agreements` and selects **Add agreement**.
2. The `CrudForm` captures title, internal description, rich text, optional PDF, Polish disclosure text/version, and archive/publish controls. The form validates source presence and shows the source preview.
3. Save creates a draft. Edit reloads the current version and sends `updatedAt`; a stale update returns 409 with reload/reapply guidance.
4. Publish freezes the source snapshot, generates/normalizes required artifacts, records hashes, and creates a publish audit event. If artifact generation fails, the draft remains editable and no signing request can be sent.

### Journey J-002 — Configure and send a multi-signer request

1. Staff opens the published agreement detail and chooses **New signing request**.
2. Staff adds two or more signers with name, email, role, order, and optional existing scalar identity reference; chooses sequential or parallel routing, expiry, and optional email verification.
3. For a PDF, staff opens the field-placement editor, assigns signature/initial/date/text fields to signers, and validates required fields. For rich text, the module will generate the signature page automatically.
4. Send atomically locks the request configuration, creates one hashed link per signer, and returns each generated frontend link once for copying. Notification delivery is a post-commit effect and cannot make the request appear sent twice.

### Journey J-003 — Sign from a frontend link

1. The signer opens their link on desktop or mobile and sees the agreement title, source preview, signer identity label, expiry, and Polish electronic-record disclosure.
2. The signer reviews the entire package. If configured, they request and enter an email OTP; rate limits and expiry are visible without revealing whether a different email exists.
3. The signer completes assigned fields, accepts the disclosure and intent checkbox, chooses typed or drawn signature, and submits once.
4. The server rechecks the current envelope/version/routing state, appends the signature and audit events atomically, and shows the next-step status. A second submission is idempotently rejected or returns the already-signed state.

### Journey J-004 — Complete, refuse, expire, or recover

1. When the final required signer submits, the envelope enters `finalizing` and a post-commit job renders the final package and certificate.
2. When generation succeeds, all signers and authorized staff can download the completed document and certificate; completion notifications are sent if configured.
3. A signer can decline with a required reason; sequential routing stops and staff can view the reason.
4. An expired/voided link shows a non-enumerating explanation and a safe contact action. Staff can resend by rotating a token or void and create a new envelope without altering the published version.

## UI and Interaction Contracts

The closest installed reference is the `example` module’s `DataTable`/`CrudForm` flow: `src/modules/example/components/TodosTable.tsx`, `src/modules/example/components/TodoForm.tsx`, `src/modules/example/backend/todos/page.tsx`, and `src/modules/example/backend/todos/[id]/edit/page.tsx`. Implementation must invoke `om-backend-ui-design`, use `.ai/guides/backend-ui.md`, and use the public/frontend design-system rules for the signer ceremony. All user-facing strings, including legal disclosures and errors, are translated; Polish is the default product locale for this module.

| Surface / route | Purpose and primary actions | Data source / mutations | Closest installed reference | Canonical shell / components | Required states | Requirement IDs |
|---|---|---|---|---|---|---|
| `/backend/agreements` | List/search/filter; add; open detail/edit; archive | Shared API helpers; `GET /api/agreements`; archive command | `src/modules/example/components/TodosTable.tsx` | `Page`, `PageBody`, `DataTable`, `RowActions`, `StatusBadge` | loading, empty, error, denied, success, archive confirmation | REQ-001 |
| `/backend/agreements/create` | Create draft with rich text/PDF source | `CrudForm`; `POST /api/agreements` | `src/modules/example/components/TodoForm.tsx` | `Page`, `PageBody`, `CrudForm`, translated custom editor/uploader group | validation, upload progress/error, duplicate submit, success | REQ-001/REQ-002 |
| `/backend/agreements/[id]/edit` | Edit draft; publish when valid; delete/archive | `CrudForm`; `PATCH /api/agreements/:id`; publish command | `src/modules/example/backend/todos/[id]/edit/page.tsx` | `Page`, `PageBody`, `CrudForm`, `Alert`, conflict dialog | loading, not-found, validation, 409 conflict, upload failure | REQ-001/REQ-002 |
| `/backend/agreements/[id]` | Version/source preview, signer progress, request actions, evidence downloads | Scoped detail API; send/void/resend commands | Example detail sections and page shell | `Page`, sections, `StatusBadge`, `DataTable` for envelopes, dialogs | loading, empty requests, denied, failed evidence, finalizing | REQ-001/REQ-003/REQ-007 |
| `/backend/agreements/[id]/requests/new` | Add multiple signers, routing, expiry, optional email verification, PDF fields | Draft envelope command; field validation; send command | Example custom CrudForm group | `CrudForm`, shared inputs, custom field-placement region, `Button`, `Alert` | signer validation, field assignment errors, upload/render failure, send success | REQ-003/REQ-004/REQ-005/REQ-006 |
| `/agreements/sign/[token]` | Public review and signing ceremony; decline; submit signature | Token-scoped public APIs | `src/modules/example/frontend/blog/[id]/page.tsx` | server-first public page, responsive document viewer, shared `Button`, `Checkbox`, `Alert`, signature dialog | loading, invalid/expired/voided, OTP, not-yet-your-turn, validation, success, keyboard/a11y | REQ-003/REQ-004/REQ-005/REQ-006/REQ-008 |
| `/agreements/sign/[token]/complete` | Completion status and authorized downloads | Token-scoped read API and signed artifact URLs | Same public page contract | Public shell, `StatusBadge`, download actions | finalizing, completed, artifact failure/retry, no access | REQ-007/REQ-008 |

### UI architecture

| Role | Navigation groups in order | Dashboard / injected widgets | Login-to-primary-task flow |
|---|---|---|---|
| Staff agreement manager | Agreements → Agreements | None required for v1 | Backend login → Agreements → Add or open agreement → publish/send |
| Staff read-only user | Agreements → Agreements | None required for v1 | Backend login → Agreements → open detail → evidence |
| Signer | No staff navigation; public one-task route | None | Generated link → review → optional verify → sign → confirmation/download |

| Surface / widget | Empty state guidance and action | Responsive behavior | Keyboard / focus behavior |
|---|---|---|---|
| Agreement list | Explain that no agreements exist; localized **Add agreement** action | Table becomes compact cards/stacked rows on narrow widths | Table headers, row actions, filters, and add action have logical tab order |
| Agreement form | Explain required source and accepted PDF limits | Rich-text editor and source preview stack; no fixed-width editor | First invalid field receives focus; Cmd/Ctrl+Enter saves; Escape cancels dialogs |
| Request builder | Explain that every required signer needs a unique email/link | Signer rows stack; field editor uses touch-safe controls and zoom | Add/remove/reorder controls labelled; field selection announced |
| Signer ceremony | Explain invalid/expired links and provide safe support action | Document viewer and sticky action bar adapt to mobile; no horizontal page overflow | Keyboard navigation through fields; focus moves to first incomplete field; async status announced |

### `/backend/agreements` — Agreement list

```text
┌────────────────────────────────────────────────────────────┐
│ Agreements                                  [Add agreement]│
│ [Search] [Status] [Updated]                               │
├────────────────────────────────────────────────────────────┤
│ Title | Status | Version | Signing progress | Updated | ⋯ │
│ ...                                                        │
├────────────────────────────────────────────────────────────┤
│ Pagination / table state                                   │
└────────────────────────────────────────────────────────────┘
```

- **Behavior:** server-side search/filter/pagination; linked row opens detail/edit; archive is confirmed and never destroys evidence; status uses `StatusBadge`; actions are feature-gated server-side.
- **Responsive and accessibility:** narrow table layout follows `DataTable` behavior; all icon actions have translated labels; empty/error/denied states are distinct; focus returns to the triggering action after dialogs.
- **Localization:** namespace `agreements.*`; Polish titles, validation, disclosure, status, and evidence labels ship with the module; no hard-coded strings.
- **Design-system and theming:** shared page/table/form primitives, semantic tokens, light/dark contrast, reduced motion, long Polish copy, and no hard-coded status colors.

### `/agreements/sign/[token]` — Signer ceremony

```text
┌────────────────────────────────────────────────────────────┐
│ Agreement title                              [Language]     │
│ Signer: Anna Kowalska · Expires: 10 Aug 2026              │
├────────────────────────────────────────────────────────────┤
│ Electronic-record disclosure / security notice             │
│                                                            │
│             Document/PDF viewer                            │
│       [signature / initials / date fields]                 │
│                                                            │
│ [ ] I agree to use electronic records and intend to sign   │
│ [Draw or type signature]                    [Sign]          │
└────────────────────────────────────────────────────────────┘
```

- The first render is deterministic and does not leak the raw token into client state or analytics. The server loads a minimal signer-scoped projection, and the client submits only field values plus a server-issued ceremony nonce.
- A sticky progress indicator shows completed/remaining fields and, for sequential mode, whether the signer is waiting for an earlier signer. It never reveals other signers’ private details beyond configured display names.
- An email-verification dialog has request, retry, expiry, attempt-limit, and success states. It does not reveal whether an email address is registered elsewhere.
- A signature dialog supports typed full name or drawn mark and initials. Signature images are treated as sensitive artifacts, not as proof of qualified identity. The signer must explicitly accept the disclosure before submission.
- The public route is accessible without staff login but is independently protected by token validation, rate limiting, expiry, state checks, and scoped artifact authorization.

## Data Models

All entities live in `src/modules/agreements/data/entities.ts` and validators in `src/modules/agreements/data/validators.ts`. All records use UUIDs, `tenant_id`, `organization_id`, `created_at`, and `updated_at` unless explicitly append-only. App-owned records must not define ORM relations to installed auth/customer entities.

### `Agreement` — `agreements:agreement`

| Field | Type / nullability | Scope / index | Sensitive / encrypted | Lifecycle and validation |
|---|---|---|---|---|
| `id` | UUID, required | primary key | no | immutable |
| `tenant_id`, `organization_id` | UUID, required | composite scope indexes | no | derived from trusted context |
| `title` | localized-safe text, required | scoped search index | no | non-empty, bounded length |
| `description` | text, nullable | scope | possibly | internal description only |
| `status` | `draft\|published\|archived` | scope/status index | no | command-controlled transitions |
| `current_version_id` | UUID, nullable | scoped index | no | points to same-module version only |
| `created_by_user_id` | scalar UUID, nullable | scope | no | snapshot/reference, never ORM relation |
| `updated_at` | timestamp, required | optimistic-lock version | no | changed on editable update |

### `AgreementVersion` — `agreements:agreement_version`

| Field | Type / nullability | Scope / index | Sensitive / encrypted | Lifecycle and validation |
|---|---|---|---|---|
| `id`, `agreement_id` | UUID, required | scoped composite indexes | no | same-module scalar IDs |
| `version_number` | integer, required | unique within agreement scope | no | monotonic |
| `source_mode` | `rich_text\|pdf\|both` | scope | no | derived from supplied sources |
| `rich_text_html` | text, nullable | no search | yes, if persisted | sanitized allowlist; immutable after publish |
| `rich_text_artifact_id` | UUID, nullable | scoped index | no | rendered canonical PDF |
| `uploaded_pdf_artifact_id` | UUID, nullable | scoped index | no | normalized source/appendix |
| `content_hash` | fixed-length digest, required | unique per scoped version | no | hash of ordered source manifest |
| `disclosure_text` / `disclosure_version` | text / string, required | no search | yes where free text | copied into evidence and immutable |
| `published_at` / `published_by_user_id` | timestamp / scalar UUID, nullable | scope | no | set once by publish command |

### `Artifact` — `agreements:artifact`

| Field | Type / nullability | Scope / index | Sensitive / encrypted | Lifecycle and validation |
|---|---|---|---|---|
| `id` | UUID, required | primary key | no | immutable metadata |
| `kind` | source/rendered/signature/final/certificate | scoped index | no | enum-controlled |
| `object_key` | provider key, required | unique scoped key | yes metadata | never returned as a public raw URL |
| `content_type`, `byte_size`, `content_hash` | required | scope/hash | no | allowlisted type, bounded size |
| `retention_until` | timestamp, nullable | cleanup index | no | policy-controlled; evidence retention cannot be shorter than legal policy |

Storage uses the configured storage/media contract with scoped keys, signed access, encrypted metadata, object authorization, and cleanup. Uploaded PDFs are validated for MIME/content consistency, size, malformed structure, active content, archive/path traversal, and parser safety before they are usable in a published version.

### `SigningEnvelope` — `agreements:envelope`

| Field | Type / nullability | Scope / index | Sensitive / encrypted | Lifecycle and validation |
|---|---|---|---|---|
| `id`, `agreement_version_id` | UUID, required | scoped indexes | no | version is immutable after send |
| `status` | draft/sent/in_progress/finalizing/completed/declined/expired/voided | scope/status | no | command-controlled state machine |
| `signing_mode` | sequential/parallel | scope | no | required on send |
| `require_email_verification` | boolean | scope | no | captured in evidence |
| `expires_at` | timestamp, nullable | expiry index | no | must be future at send |
| `sent_at`, `completed_at`, `voided_at` | timestamps, nullable | scope | no | append-only transition evidence |
| `final_artifact_id`, `certificate_artifact_id` | UUID, nullable | scoped indexes | no | populated by idempotent finalizer |
| `updated_at` | timestamp, required | optimistic-lock version | no | guarded admin mutations |

### `Signer` — `agreements:signer`

| Field | Type / nullability | Scope / index | Sensitive / encrypted | Lifecycle and validation |
|---|---|---|---|---|
| `id`, `envelope_id` | UUID, required | scoped composite indexes | no | immutable after send |
| `display_name`, `email` | text, required | email lookup hash | yes | normalize; encrypt value and store keyed lookup hash |
| `external_user_id` | UUID, nullable | scoped index | no | scalar snapshot only, optional |
| `role`, `routing_order` | text / integer | scoped order index | no | order unique in sequential mode |
| `status` | pending/invited/viewed/ready/signed/declined/expired | scoped status | no | command-controlled |
| `token_hash` | fixed-length digest, required | unique scoped index | secret derivative | never log or return after initial link response |
| `verification_required`, `verified_at` | boolean / timestamp | scope | no | OTP state |
| `signed_at`, `declined_at`, `decline_reason` | nullable | scope | reason possibly sensitive | append evidence; decline reason bounded |

### `EnvelopeField` — `agreements:envelope_field`

| Field | Type / nullability | Scope / index | Sensitive / encrypted | Lifecycle and validation |
|---|---|---|---|---|
| `id`, `envelope_id`, `signer_id` | UUID, required | scoped indexes | no | same-module scalar IDs |
| `document_artifact_id` | UUID, required for PDF fields | scoped index | no | must belong to envelope version |
| `field_type` | signature/initials/date/text | scope | no | allowlist |
| `page_number` | integer, required | scope | no | 1-based, in range |
| `x`, `y`, `width`, `height` | normalized decimals, required | scope | no | each in [0,1], positive dimensions |
| `required` | boolean | scope | no | signer cannot finish missing required fields |
| `label` | localized-safe text, nullable | no search | no | accessible label |

### `Signature` — `agreements:signature`

| Field | Type / nullability | Scope / index | Sensitive / encrypted | Lifecycle and validation |
|---|---|---|---|---|
| `id`, `envelope_id`, `signer_id`, `field_id` | UUID, required | unique scoped signer/field | no | append-only; no replacement |
| `method` | typed/drawn/automatic_date/typed_text | scope | no | controlled enum |
| `value_artifact_id` | UUID, nullable | scoped index | yes | signature mark stored as restricted artifact |
| `value_text` | text, nullable | no search | yes | only for typed/text fields |
| `document_hash` | digest, required | scope | no | hash at ceremony completion |
| `disclosure_hash` | digest, required | scope | no | exact disclosure accepted |
| `signed_at` | timestamp, required | scope | no | server time |
| `ip_address`, `user_agent`, `locale` | encrypted text/text/string | scope | yes | evidence and abuse detection; retention policy applies |

### `AuditEvent` — `agreements:audit_event`

Append-only rows for sent, viewed, downloaded, OTP requested/verified/failed, disclosure accepted, field completed, signed, declined, resent, voided, expired, artifact generated, and evidence downloaded. Each row stores event type, envelope/signer IDs, server UTC time, actor kind, sanitized metadata, previous event digest, current digest, and optional key-anchor reference. No update/delete route is exposed.

Retention, encryption maps, artifact lifecycle, and key rotation must be reviewed before migration generation. The implementation must run `yarn db:generate`, review scoped SQL/snapshot, and ask before applying any migration.

## API, Command, and Error Contracts

Admin CRUD routes use `makeCrudRoute` where the installed contract supports the standard operation; publish, envelope, PDF-field, signing, refusal, and evidence actions use custom guarded command routes. Every method has its own `metadata` and `openApi` schema. All mutations are commands, scope-derived, idempotency-aware where retried, and return `updatedAt` for editable records.

| Method / command | Path / ID | Auth and feature gate | Input | Success response / event | Errors and concurrency | Requirement IDs |
|---|---|---|---|---|---|---|
| `GET` | `/api/agreements` | staff auth + `agreements.view` | scoped filters/search/pagination | `{ items, totalCount }` | 400/401/403; invalid filters cannot widen scope | REQ-001 |
| `POST` | `/api/agreements` | staff auth + `agreements.manage` | title, description, source metadata, sanitized rich text/artifact upload reference | 201 `{ id, updatedAt }` + `agreements.agreement.created` | 400/403/413/415; atomic source metadata | REQ-001/REQ-002 |
| `GET` | `/api/agreements/:id` | staff auth + `agreements.view` | path ID | scoped detail/version/envelope summary | 404 for out-of-scope/not found | REQ-001 |
| `PATCH` | `/api/agreements/:id` | staff auth + `agreements.manage` | editable fields + `updatedAt` | `{ id, updatedAt }` + updated event | 400/403/404/409 stale version | REQ-001/REQ-002 |
| `POST` | `/api/agreements/:id/publish` | staff auth + `agreements.manage` | draft version ID + idempotency key | version hash/status + `agreements.version.published` | 409 if invalid/changed; artifact failure leaves draft | REQ-002/REQ-003 |
| `POST` | `/api/agreements/:id/archive` | staff auth + `agreements.manage` | `updatedAt` | archived status + event | 409; cannot destroy evidence | REQ-001 |
| `POST` | `/api/agreements/:id/envelopes` | staff auth + `agreements.manage` | version, signers, routing, expiry, verification flag, fields | envelope summary + one-time signer links + sent event | validation, duplicate idempotency, 409 lock | REQ-003/REQ-004/REQ-005/REQ-006 |
| `GET` | `/api/agreements/:id/envelopes/:envelopeId` | staff auth + `agreements.view` | path IDs | progress, safe signer projection, artifact status | 404/403; no raw tokens | REQ-003/REQ-007 |
| `POST` | `/api/agreements/:id/envelopes/:envelopeId/resend` | staff auth + `agreements.manage` | signer ID(s), reason, idempotency key | rotated link/notification status + event | 409 signed/voided; rate limit | REQ-004/REQ-005 |
| `POST` | `/api/agreements/:id/envelopes/:envelopeId/void` | staff auth + `agreements.manage` | reason + envelope version | voided + event | 409 completed; audit preserved | REQ-004/REQ-007 |
| `GET` | `/api/public/agreement-signing/:token` | token authorization | no scope fields | signer-scoped content projection and ceremony state | generic 404/410/429; no enumeration | REQ-003/REQ-005/REQ-006 |
| `POST` | `/api/public/agreement-signing/:token/open` | token authorization + ceremony nonce | nonce | viewed event; current state | idempotent; expired/voided/not-yet-turn | REQ-003/REQ-004/REQ-007 |
| `POST` | `/api/public/agreement-signing/:token/verification/request` | token authorization | ceremony nonce | `{ retryAfter }` and post-commit email job | 429/410; never returns OTP | REQ-005 |
| `POST` | `/api/public/agreement-signing/:token/verification/confirm` | token + nonce | OTP | verified state + event | wrong/expired/locked OTP | REQ-005 |
| `POST` | `/api/public/agreement-signing/:token/sign` | token + ceremony nonce | disclosure acceptance, signature method/mark, field values, client metadata | signed state + next-step status/event | 400/409/410; duplicate submit safe; state rechecked in command | REQ-004/REQ-005/REQ-006/REQ-007 |
| `POST` | `/api/public/agreement-signing/:token/decline` | token + ceremony nonce | reason | declined + event | 400/409/410; idempotent | REQ-004/REQ-007 |
| `GET` | `/api/public/agreement-signing/:token/evidence` | completed envelope + signer access | no scope fields | short-lived signed artifact URLs | 404/410/403; no raw storage key | REQ-007 |

Public requests must not accept `tenantId`, `organizationId`, signer ID, envelope ID, or feature grants as authorization input. Rate limit link loading, OTP requests, OTP attempts, signing submissions, and download generation per token/IP/device with safe tenant-aware boundaries. Stable command IDs are `agreements.agreements.create|update|archive`, `agreements.versions.publish`, `agreements.envelopes.send|resend|void`, `agreements.signers.verify|sign|decline`, and `agreements.evidence.finalize`; exact IDs must be reviewed before implementation and then treated as frozen.

## Events, Jobs, Notifications, and Cross-Module Flows

| Trigger | Producer | Consumer | Side effect | Retry / idempotency / audit behavior |
|---|---|---|---|---|
| `agreements.agreement.created/updated/archived` | agreements | own index/cache subscribers | refresh admin list/detail | post-commit; event IDs stable; scoped payload |
| `agreements.version.published` | agreements | artifact/index subscriber | publish searchable metadata and source hash | idempotent by version ID; no source content in logs |
| `agreements.envelope.sent` | agreements | notification worker | send optional signer notification or expose copied links | idempotency key `(envelope, signer, delivery attempt)`; failure visible and retryable |
| `agreements.signer.viewed/verified/signed/declined` | agreements | audit/evidence subscriber | append audit evidence; update progress | append-only; duplicate event handling does not duplicate signature |
| `agreements.envelope.all_signed` | agreements | finalization worker | render final package and certificate | unique finalization key; retry after crash; `finalizing` until complete |
| `agreements.envelope.expiry_due` | scheduler/worker | agreements | expire pending envelope/signers and notify staff | compare-and-swap state transition; rerun safe |
| `agreements.evidence.ready` | finalization worker | notification worker | notify signers/staff and expose downloads | idempotent by certificate artifact ID; delivery failure does not undo completion |

Reminders are optional and bounded: no more than the configured count, no reminders after signed/declined/expired/voided, and each delivery is auditable. If no transactional email capability is configured, copying links and signing still works; email-specific actions show a translated unavailable/retry state.

## Security, Privacy, and Compliance

- **Authorization:«redacted:authorization» API authorization is independent of UI visibility. Staff uses `agreements.view`/`agreements.manage`; public access uses a hash-validated, expiring signer token and signer state. No role-name checks.
- **Tenant isolation:** Every entity query, artifact authorization, cache key, job payload, event payload, idempotency key, and download lookup contains trusted tenant/org scope. Missing scope fails closed.
- **Link security:** Generate cryptographically random opaque tokens, store only a digest, use HTTPS, set short-lived ceremony nonce/cookie protections, rotate on resend, redact referers/analytics, and never log full URLs. Generic not-found responses prevent token enumeration.
- **Email verification:** Store OTP digests, expiry, attempt count, and lock state; use a bounded rate limiter; do not reveal OTP or whether a mailbox is known. Verification proves mailbox control only.
- **Content security:** Sanitize rich text with an allowlist; reject active PDF content and malformed/encrypted PDFs unless the approved parser safely normalizes them; cap size/pages; scan uploads; never render untrusted HTML outside the sanitizer contract.
- **Sensitive data:** Encrypt signer emails, IP addresses, user agents, free-text decline reasons, rich text where persisted, and signature mark artifacts using the platform encryption/storage services. Use decryption-aware scoped reads. Never place document content, signatures, tokens, OTPs, or raw request metadata in logs.
- **Evidence integrity:** Hash every source and completed artifact, chain audit events, and use the platform-approved key/anchor service where available. The certificate must state “ordinary electronic signature evidence” and the authentication method; it must not claim “qualified,” “advanced,” “PAdES,” “PKI-sealed,” or handwritten-equivalent status.
- **Consent and disclosures:** Version the Polish electronic-record/signature disclosure and store the exact disclosure hash accepted by each signer. Include explicit intent, signer name, time, method, and link/authentication evidence.
- **Retention and GDPR:** Define retention and deletion roles with legal counsel. Evidence/audit records must not be silently deleted from an active retention period; document exports and data-subject requests need a policy-aware path that does not invalidate retained evidence. Data residency follows the configured storage provider.
- **Abuse:** Rate limit public endpoints, bound PDF/text lengths, prevent replay and duplicate signing, deny cross-scope artifact URLs, and protect against CSRF/session fixation where browser state is used.
- **Polish compliance gate:** Before production, legal counsel must approve the disclosure, retention, consent wording, supported agreement categories, and when a qualified signature/provider is required. The module’s product copy must not imply that a typed/drawn mark satisfies a statutory written-form requirement.

## Integration Coverage

Tests must use self-contained fixtures, real API routes/commands, and the configured ephemeral integration environment. Every test creates two tenants and two organizations where relevant, cleans artifacts in `finally`, and asserts persisted state and observable UI/API behavior.

| Test ID | Level | Setup / fixture | Actions | Assertions | Requirement IDs |
|---|---|---|---|---|---|
| TEST-001 | integration | Two scoped staff users; draft rich-text agreement | Create, reload, edit, clear optional field, stale update | Correct round trip, 409 conflict, no cross-scope read/write | REQ-001/REQ-008 |
| TEST-002 | integration | Rich-text and PDF source fixtures, malformed/oversized/active-content PDFs | Upload, publish, retry artifact generation | Sanitization/validation, immutable version hash, unsafe files rejected | REQ-002/REQ-003 |
| TEST-003 | integration | Published version, three signers, sequential mode | Send, open links in order, sign, attempt out-of-order/duplicate | Unique signer links, routing, idempotent signature, progress events | REQ-003/REQ-004/REQ-007 |
| TEST-004 | integration/security | Parallel envelope and two tenant tokens | Access with wrong/expired/voided/cross-tenant tokens | Generic denial, no leakage, correct scope | REQ-003/REQ-008 |
| TEST-005 | security | Envelope with email verification | Request OTP, wrong/expired/replayed OTP, correct OTP | Hash-only OTP, rate limits, no OTP/log/link leakage | REQ-005/REQ-008 |
| TEST-006 | integration/UI | PDF with signature/initial/date/text fields across pages | Place fields, assign signers, sign on narrow and wide viewport | Normalized coordinates, required fields, rendered marks and values | REQ-006/REQ-008 |
| TEST-007 | integration | Two-signature envelope; injected failure after last signature | Complete final signer, fail finalizer, retry worker | No partial evidence, exactly one final package/certificate, final hash matches | REQ-007 |
| TEST-008 | integration | Declined, expired, voided, resent envelopes | Exercise each transition and retry delivery | State machine rejects invalid transitions; audit is append-only | REQ-004/REQ-007 |
| TEST-009 | UI/accessibility | Empty, loading, validation, server error, conflict, denied fixtures | Keyboard-only admin and signer flows; light/dark/narrow/Polish locale | Focus, labels, announcements, responsive layout, semantic states | REQ-001/REQ-005/REQ-008 |
| TEST-010 | security/privacy | Evidence with PII and signature artifacts | Inspect logs/API/list/detail/export | No secrets/content leakage; authorized artifact only; retention metadata present | REQ-007/REQ-008 |

## Implementation Phases

Phases are dependency ordered and each closes a complete vertical slice. Implementation must use `om-module-scaffold`, `om-data-model-design`, and `om-backend-ui-design`; storage/email work must follow the routed integration guidance. The phase plan is not authorization to apply migrations or add dependencies without approval.

### Phase 1 — Agreement authoring, immutable versions, and rich-text signing

- **Depends on:** none
- **Outcome:** Staff can manage agreements, publish a rich-text version, create a multi-signer request, generate individual links, and complete a sequential or parallel ordinary-signature ceremony.
- **Why this order / value delivered:** Establishes the core invariant that every signer signs one immutable, scoped version before PDF-specific complexity is added.
- **Deliverables:** `agreements` module activation; entities/validators; ACL/setup; scoped CRUD commands/routes; admin list/create/edit/detail; sanitized rich-text preview; publish/hash flow; envelope/signer state machine; public token route; typed/drawn signature flow; consent/disclosure; audit events; Polish translations.
- **Independent slices / estimated commits:** domain/schema and commands; admin CRUD; public ceremony; each with its own tests inside the phase.
- **Requirements closed:** REQ-001, REQ-003, REQ-004, REQ-005, REQ-007, REQ-008
- **Tests:** TEST-001, TEST-003, TEST-004, TEST-005, TEST-008, TEST-009
- **Validation:** `yarn generate`, focused module tests, `yarn typecheck`, `yarn lint`, `yarn test`
- **Exit gate:** A scoped test tenant can create/publish a rich-text agreement, send three signers in both routing modes, sign through the public link, reject duplicate/out-of-order attempts, and see append-only audit records and a finalization status. Admin and public pages pass loading/empty/error/conflict/keyboard, light/dark, narrow-width, and Polish checks.

### Phase 2 — PDF upload, field placement, and completed document rendering

- **Depends on:** Phase 1 exit gate
- **Outcome:** Staff can add a safe PDF source, position fields for named signers, and receive a final document with visible field values and signature marks.
- **Why this order / value delivered:** Adds the requested DocuSign-like PDF workflow on top of a proven signing state machine.
- **Deliverables:** scoped artifact metadata; PDF validation/normalization worker; upload/preview; custom field-placement editor; normalized coordinate model; PDF signing render; appended signature page where no positioned fields exist; final package artifact; download authorization.
- **Independent slices / estimated commits:** artifact pipeline; field editor and validation; final PDF renderer; each with a self-contained integration path.
- **Requirements closed:** REQ-002, REQ-006, REQ-007
- **Tests:** TEST-002, TEST-006, TEST-007, TEST-010
- **Validation:** `yarn generate`, focused integration tests, `yarn typecheck`, `yarn lint`, `yarn test`
- **Exit gate:** A multi-page PDF with signature, initials, date, and text fields can be configured, completed by multiple signers on desktop/mobile widths, and downloaded with matching source/final hashes; unsafe or malformed PDFs never enter a published version.

### Phase 3 — Optional email verification, notifications, expiry, and evidence certificate

- **Depends on:** Phase 2 exit gate
- **Outcome:** Higher-assurance optional verification and operational lifecycle controls are available without changing the core signing contract.
- **Why this order / value delivered:** Adds security and operational polish only after the core ceremony and final artifacts are reliable.
- **Deliverables:** transactional-email/notification seam; OTP request/confirm; resend rotation; expiry/reminder worker; completed certificate PDF; evidence download UI; delivery/finalization retry controls; retention configuration and operational diagnostics.
- **Independent slices / estimated commits:** OTP flow; notification/reminder/expiry; certificate and retention; each must preserve safe absent-provider behavior.
- **Requirements closed:** REQ-005, REQ-007, REQ-008
- **Tests:** TEST-005, TEST-007, TEST-008, TEST-010
- **Validation:** `yarn generate`, mock email/storage integration tests, `yarn typecheck`, `yarn lint`, `yarn test`, `yarn test:integration:ephemeral`
- **Exit gate:** With email enabled, OTP and notifications are retry-safe and redacted; with email absent, copied-link signing still works and the UI explains the unavailable capability. Completed envelopes have a certificate containing hashes, signer actions, consent/disclosure, timestamps, and configured authentication evidence.

## Requirement Traceability

| Requirement | Journey / surface | Data/API/event contracts | Phase | Tests | Acceptance criterion |
|---|---|---|---|---|---|
| REQ-001 | J-001; `/backend/agreements`; admin CRUD | Agreement; CRUD routes; create/update/archive commands | Phase 1 | TEST-001, TEST-009 | AC-001 |
| REQ-002 | J-001; create/edit; PDF upload | AgreementVersion; artifact pipeline; publish route | Phase 1-2 | TEST-002 | AC-002 |
| REQ-003 | J-002/J-003; signer links | Envelope/Signer; send/public read routes | Phase 1 | TEST-003, TEST-004 | AC-003 |
| REQ-004 | J-002/J-004; request builder/ceremony | Envelope/Signer state machine; send/sign/decline/void events | Phase 1 | TEST-003, TEST-008 | AC-004 |
| REQ-005 | J-003; OTP dialog | Signer verification state; OTP routes; notification job | Phase 1/3 | TEST-005 | AC-005 |
| REQ-006 | J-002/J-003; PDF field editor/ceremony | EnvelopeField; field validation and sign route | Phase 2 | TEST-006 | AC-006 |
| REQ-007 | J-004; detail/evidence downloads | Signature/AuditEvent/Artifact; finalizer; evidence route | Phase 1-3 | TEST-007, TEST-010 | AC-007 |
| REQ-008 | All journeys | Scope, ACL, encryption, translations, UX quality states | Phase 1-3 | TEST-004, TEST-009, TEST-010 | AC-008 |

## Rollout, Migration, and Rollback

- Register the new module additively in `src/modules.ts`; run `yarn generate` after discovery files, routes, pages, events, workers, and module registration change.
- Add new tables and indexes only through generated, reviewed migrations. Run `yarn db:generate`, inspect scoped SQL/snapshot, and ask before applying. Never edit a shipped migration.
- Start behind an `agreements.enabled` feature gate for staff and a separate `agreements.public_signing` gate for the ceremony. Existing tenants receive no records or routes until explicitly enabled.
- Rollout order: internal test tenant → pilot Polish organization with legal-approved disclosure/retention → broader enablement. Observe publish failures, token abuse/rate limits, finalizer retries, notification failures, and artifact download denials.
- Rollback before signed traffic: disable module/public gate; leave additive tables and records intact. Rollback after signed traffic: disable new sends but keep read-only evidence access and retention; do not delete or rewrite signatures/audit events.
- If a future contract must change, add a versioned route/event and bridge old IDs rather than renaming a released route, event, ACL feature, or entity ID.

## Risks and Tradeoffs

| Risk / tradeoff | Impact | Mitigation / detection | Residual risk |
|---|---|---|---|
| Ordinary e-signature is mistaken for qualified signature | Agreement may fail a required Polish form | Persistent Polish disclosure, certificate wording, legal approval gate, future provider seam | Organization must classify each agreement correctly |
| Bearer link is forwarded or stolen | Unauthorized access/signature | HTTPS, random digest-only tokens, optional OTP, rate limits, resend rotation, audit trail | No-account flow cannot prove civil identity by itself |
| PDF parser/rendering vulnerability | Security or incorrect evidence | Sandboxed parser, type/size/page limits, normalization, malicious fixtures, dependency review | Parser dependency remains an attack surface |
| Rich text changes after a signer views it | Disputed content | Publish hash, immutable versions, source/final hash in certificate | Legal interpretation of evidence remains external |
| Finalizer fails after last signature | Completed signer state without downloadable evidence | `finalizing` state, durable idempotency, retries, staff diagnostics, no completion notification before artifact ready | Extended outage delays evidence availability |
| Email delivery fails or provider is absent | OTP/reminders unavailable | Copied-link path remains functional; explicit unavailable state; retry/redacted diagnostics | Operators must choose whether to require verification |
| Audit trail contains PII | Privacy/retention burden | Encryption, role-gated access, configurable retention, redacted logs, legal review | Evidence may require retaining sensitive data |
| Multiple signers race or submit twice | Duplicate/inconsistent signatures | Transactional state checks, unique constraints, optimistic locking, idempotency keys | High concurrency needs load testing |
| Storage object is mis-authorized | Document leak | Scoped object keys, signed short-lived URLs, artifact authorization tests | Storage provider configuration remains operationally important |

## Acceptance Criteria

- [ ] **AC-001** — A staff user with the correct feature can create, edit, list, inspect, and archive an agreement; a stale edit receives a 409 and preserves the user’s entered values for recovery.
- [ ] **AC-002** — Rich text is sanitized and frozen into a hashed published version; uploaded PDFs are validated/normalized; when both are present, the defined ordered package is presented to every signer.
- [ ] **AC-003** — Sending creates one unique signer-specific frontend link per signer, stores no raw token, and never authorizes a signer from client-supplied tenant/org/envelope IDs.
- [ ] **AC-004** — Sequential and parallel multi-signer flows enforce routing, prevent duplicate signatures, support decline/expiry/void/resend, and preserve an append-only audit history.
- [ ] **AC-005** — Optional email OTP is single-use, short-lived, rate-limited, hashed, redacted, and clearly described as mailbox verification rather than qualified identity proof.
- [ ] **AC-006** — PDF signature, initials, date, and text fields retain normalized positions across viewport sizes and cannot be completed by the wrong signer or with missing required values.
- [ ] **AC-007** — After all required signatures, an idempotent finalizer creates a completed document and certificate containing source/final hashes, participant actions, consent/disclosure, timestamps, and configured authentication/network evidence.
- [ ] **AC-008** — All affected admin/public routes use canonical components, translated strings, semantic tokens, complete «redacted:high-entropy» states, strict tenant/org scope, encrypted sensitive data, and no claim of qualified-signature equivalence.
- [ ] Every listed runtime/discovery surface has the traceability row and self-contained integration test required by the repository delivery guide.
- [ ] Legal counsel approves Polish disclosure, retention, supported agreement categories, and production wording before status changes to `Ready for implementation`.

## Final Compliance Report

| Check | Status | Evidence / resolution |
|---|---|---|
| Applicable `AGENTS.md` files and routed guides/skills reviewed | pass | Root rules; `om-spec-writing`; `om-module-scaffold`; `om-data-model-design`; `om-backend-ui-design`; integration/storage guidance; auth, communication, notifications, and events facts |
| Data models, APIs, events, UI, and tests are internally consistent | pass | Requirements, entities, routes, events, journeys, phases, and traceability tables align |
| Every workflow completes end to end without a catch-all integration phase | pass | Three dependency-ordered vertical phases with explicit exit gates |
| Platform-native reuse and extension points were chosen before custom code | pass | CRUD, commands, scope, storage, notifications, events, and translated UI reuse documented; PDF editor is the only explicit custom surface |
| UI contracts identify references, canonical components, and theme/state coverage | pass | Admin and public route inventory, exact example references, mockups, and state requirements included |
| Every phase has dependencies, bounded slices, tests, value, and an observable exit gate | pass | Phase 1-3 sections and TEST mappings |

Verdict: **Blocked — legal/compliance approval of the Polish disclosure, retention policy, supported agreement categories, and cryptographic/key-management seam is required before implementation readiness.**

## Open Questions

The original product questions are resolved as follows. These are no longer architecture blockers, but the legal/operational approval gate remains open.

| ID | Question | Owner | Blocking? | Resolution / decision date |
|---|---|---|---|---|
| Q-001 | What assurance level is required for v1? | Product / Legal | resolved | Built-in ordinary electronic signature with evidence; no external/qualified provider in v1 — 2026-08-10 |
| Q-002 | How is signer identity established? | Product / Security | resolved | No account required; optional per-envelope email OTP — 2026-08-10 |
| Q-003 | Are positioned fields required? | Product | resolved | Required for uploaded PDFs; rich text uses generated signature page and does not require manual placement — 2026-08-10 |
| Q-004 | One or multiple signers? | Product | resolved | Multiple signers with sequential and parallel routing — 2026-08-10 |
| Q-005 | Which jurisdiction applies? | Legal / Compliance | resolved for design | Poland; exact legal categories, retention, and disclosure wording still require counsel approval — 2026-08-10 |

## Changelog

| Date | Change |
|---|---|
| 2026-08-10 | Initial skeleton and blocking questions |
| 2026-08-10 | Resolved product questions; added Polish legal posture, architecture, data/API/UI contracts, security, tests, phasing, and traceability |
